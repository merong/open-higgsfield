### Task 3: 스타일시트 1:1 이식과 parity 테스트

**Files:**
- Create: `design/test/lib/flatten.ts`, `design/test/lib/flatten.test.ts`, `design/test/parity.test.ts`
- Create: `design/src/styles/base/_reset.scss`, `design/src/styles/base/_keyframes.scss`, `design/src/styles/studio/_*.scss`(19개), `design/src/styles/index.scss`
- Modify: `design/src/index.ts`

**Interfaces:**
- Consumes: Task 2의 `tokens/_emit.scss`.
- Produces: `flatten(css): Decl[]`, `resolveVars(decls): Decl[]`, `normalize(value): string`(`test/lib/flatten.ts`); `src/styles/index.scss`가 스튜디오 전체 CSS를 내놓는다; `dist/ohf.css`에 스튜디오 규칙 포함.

원본 섹션 경계(줄 번호는 `grep -n "^/\* ---------- " openhiggsfield.css`로 확인한 값):

| 파셜 | 원본 줄 |
| --- | --- |
| `base/_reset.scss` | 1–136 (토큰 블록 8–43은 제외하고 손으로 작성) |
| `base/_keyframes.scss` | 137–340 |
| `studio/_shell.scss` | 341–349 |
| `studio/_topbar.scss` | 350–387 |
| `studio/_tabs.scss` | 388–462 |
| `studio/_lamp.scss` | 463–518 |
| `studio/_main.scss` | 519–527 |
| `studio/_gallery.scss` | 528–708 |
| `studio/_picking.scss` | 709–1062 |
| `studio/_empty.scss` | 1063–1176 |
| `studio/_composer.scss` | 1177–1288 |
| `studio/_attached.scss` | 1289–1424 (`.ohf-composer { --ctl-r: 10px }`는 1399–1417, 이 파셜에 있다) |
| `studio/_dock.scss` | 1425–2011 |
| `studio/_tooltips.scss` | 2012–2083 |
| `studio/_popovers.scss` | 2084–2609 |
| `studio/_asset-picker.scss` | 2610–2894 |
| `studio/_dialogs.scss` | 2895–2990 |
| `studio/_viewer.scss` | 2991–3472 |
| `studio/_entrance.scss` | 3473–3486 |
| `studio/_responsive.scss` | 3487–3710 |
| `studio/_reduced-motion.scss` | 3711–3736 |

- [ ] **Step 1: 평탄화 도우미의 실패하는 테스트**

`design/test/lib/flatten.test.ts`:

```ts
import { describe, expect, it } from "vitest";

import { flatten, normalize, resolveVars, stripComments } from "./flatten";

describe("stripComments", () => {
  it("removes block comments but not comment-like text inside strings", () => {
    const css = `a { content: "/* keep */"; /* drop */ color: red; }`;
    expect(stripComments(css)).toBe(`a { content: "/* keep */";  color: red; }`);
  });
});

describe("flatten", () => {
  it("keeps declarations in order with their selector as context", () => {
    expect(flatten(`.a { color: red; margin: 0 }\n.b { color: blue; }`)).toEqual([
      { ctx: ".a", prop: "color", value: "red" },
      { ctx: ".a", prop: "margin", value: "0" },
      { ctx: ".b", prop: "color", value: "blue" },
    ]);
  });

  it("nests at-rules into the context", () => {
    expect(flatten(`@media (max-width: 900px) { .a { gap: 4px; } }`)).toEqual([
      { ctx: "@media (max-width: 900px) > .a", prop: "gap", value: "4px" },
    ]);
  });

  it("drops statements outside any block", () => {
    expect(flatten(`@charset "UTF-8"; .a { x: 1; }`)).toEqual([{ ctx: ".a", prop: "x", value: "1" }]);
  });

  it("does not split on braces or semicolons inside strings", () => {
    const css = `.a { background: url("data:image/svg+xml,%3Csvg%3E{;}%3C/svg%3E"); }`;
    expect(flatten(css)).toEqual([
      { ctx: ".a", prop: "background", value: `url("data:image/svg+xml,%3Csvg%3E{;}%3C/svg%3E")` },
    ]);
  });
});

describe("resolveVars", () => {
  it("substitutes var() from custom properties declared anywhere in the sheet, transitively", () => {
    const decls = flatten(`.ohf { --radius-ctl: 10px; } .c { --ctl-r: var(--radius-ctl); } .d { border-radius: var(--ctl-r); }`);
    const resolved = resolveVars(decls);
    expect(resolved.at(-1)?.value).toBe("10px");
    expect(resolved[1]?.value).toBe("10px");
  });

  it("leaves names the sheet never declares alone, fallback included", () => {
    const [d] = resolveVars(flatten(`.a { left: var(--ohf-pop-x, calc(100% + 10px)); }`));
    expect(d?.value).toBe("var(--ohf-pop-x, calc(100% + 10px))");
  });
});

describe("normalize", () => {
  it("ignores whitespace around separators and letter case", () => {
    expect(normalize("rgba(255, 255, 255, 0.06)")).toBe("rgba(255,255,255,0.06)");
    expect(normalize("4 / 3")).toBe("4/3");
    expect(normalize("#EDEFEF")).toBe("#edefef");
  });
});
```

- [ ] **Step 2: 실패 확인**

Run: `corepack pnpm test test/lib/flatten.test.ts`
Expected: FAIL — `./flatten` 모듈 없음.

- [ ] **Step 3: 평탄화 도우미 작성**

`design/test/lib/flatten.ts`:

```ts
export interface Decl {
  ctx: string;
  prop: string;
  value: string;
}

const squash = (s: string) => s.replace(/\s+/g, " ").trim();

/* Removes block comments while leaving quoted strings intact: a "/*" inside a
   data: URL must not open a comment. */
export function stripComments(css: string): string {
  let out = "";
  let i = 0;
  while (i < css.length) {
    const ch = css[i]!;
    if (ch === '"' || ch === "'") {
      let j = i + 1;
      while (j < css.length && css[j] !== ch) {
        if (css[j] === "\\") j++;
        j++;
      }
      out += css.slice(i, j + 1);
      i = j + 1;
    } else if (ch === "/" && css[i + 1] === "*") {
      const end = css.indexOf("*/", i + 2);
      i = end < 0 ? css.length : end + 2;
    } else {
      out += ch;
      i++;
    }
  }
  return out;
}

/* Walks the braces once. Every "prop: value" becomes a triple whose context is
   the chain of enclosing selectors and at-rules, so the same declaration under
   two media queries stays two entries. Statements outside any block, such as
   @charset, are dropped. */
export function flatten(css: string): Decl[] {
  const out: Decl[] = [];
  const stack: string[] = [];
  let buf = "";
  const push = () => {
    const text = squash(buf);
    buf = "";
    if (!text || stack.length === 0) return;
    const colon = text.indexOf(":");
    if (colon < 0) return;
    out.push({
      ctx: stack.join(" > "),
      prop: text.slice(0, colon).trim(),
      value: text.slice(colon + 1).trim(),
    });
  };
  const src = stripComments(css);
  let i = 0;
  while (i < src.length) {
    const ch = src[i]!;
    if (ch === '"' || ch === "'") {
      let j = i + 1;
      while (j < src.length && src[j] !== ch) {
        if (src[j] === "\\") j++;
        j++;
      }
      buf += src.slice(i, j + 1);
      i = j + 1;
    } else if (ch === "{") {
      stack.push(squash(buf));
      buf = "";
      i++;
    } else if (ch === "}") {
      push();
      stack.pop();
      i++;
    } else if (ch === ";") {
      push();
      i++;
    } else {
      buf += ch;
      i++;
    }
  }
  return out;
}

const VAR = /var\(\s*(--[\w-]+)\s*(?:,\s*((?:[^()]|\([^()]*\))*))?\)/g;

/* Substitutes var() with the value declared for that name anywhere in the same
   sheet (first declaration wins) until nothing changes. Names the sheet never
   declares — the ones JS sets inline, like --thumb-x — stay as written. */
export function resolveVars(decls: Decl[]): Decl[] {
  const table = new Map<string, string>();
  for (const d of decls) {
    if (d.prop.startsWith("--") && !table.has(d.prop)) table.set(d.prop, d.value);
  }
  const resolve = (value: string) => {
    let v = value;
    for (let n = 0; n < 20; n++) {
      const next = v.replace(VAR, (m, name: string) => table.get(name) ?? m);
      if (next === v) break;
      v = next;
    }
    return v;
  };
  return decls.map((d) => ({ ...d, value: resolve(d.value) }));
}

export function normalize(value: string): string {
  return squash(value)
    .replace(/\s*([,/()])\s*/g, "$1")
    .toLowerCase();
}
```

Run: `corepack pnpm test test/lib/flatten.test.ts`
Expected: PASS (8 tests).

- [ ] **Step 4: 실패하는 parity 테스트 작성**

`design/test/parity.test.ts`:

```ts
import { existsSync, readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";

import * as sass from "sass-embedded";
import { describe, expect, it } from "vitest";

import { flatten, normalize, resolveVars, type Decl } from "./lib/flatten";

const ORIGINAL = fileURLToPath(
  new URL("../../open-higgsfield/src/openhiggsfield/openhiggsfield.css", import.meta.url),
);
const ENTRY = fileURLToPath(new URL("../src/styles/index.scss", import.meta.url));

const isCustom = (d: Decl) => d.prop.startsWith("--");
const line = (d: Decl) => `${d.ctx} | ${d.prop}: ${normalize(d.value)}`;

/* Both sheets go through Dart Sass, so its own formatting (number and colour
   serialisation, list spacing) cancels out and only real differences remain. */
function sheets() {
  const ours = sass.compile(ENTRY, { style: "expanded", logger: sass.Logger.silent }).css;
  const theirs = sass.compileString(readFileSync(ORIGINAL, "utf8"), {
    syntax: "css",
    style: "expanded",
    logger: sass.Logger.silent,
  }).css;
  return { ours: resolveVars(flatten(ours)), theirs: resolveVars(flatten(theirs)) };
}

function firstMismatch(a: string[], b: string[]): string | null {
  const n = Math.max(a.length, b.length);
  for (let i = 0; i < n; i++) {
    if (a[i] === b[i]) continue;
    const ctx = (list: string[]) => list.slice(Math.max(0, i - 2), i + 3).join("\n    ");
    return `first difference at #${i} (ours ${a.length} vs original ${b.length} declarations)\n  ours:\n    ${ctx(a)}\n  original:\n    ${ctx(b)}`;
  }
  return null;
}

describe("parity with openhiggsfield.css", () => {
  it("has the original stylesheet to compare against", () => {
    expect(existsSync(ORIGINAL), `missing ${ORIGINAL}`).toBe(true);
  });

  it("emits every declaration of the original, in order, with the same resolved value", () => {
    const { ours, theirs } = sheets();
    const diff = firstMismatch(ours.filter((d) => !isCustom(d)).map(line), theirs.filter((d) => !isCustom(d)).map(line));
    expect(diff, diff ?? "").toBeNull();
  });

  it("keeps every custom property the original declares, resolving to the same value", () => {
    const { ours, theirs } = sheets();
    const mine = ours.filter(isCustom);
    for (const d of theirs.filter(isCustom)) {
      const match = mine.find((m) => m.ctx === d.ctx && m.prop === d.prop);
      expect(match, `${d.ctx} { ${d.prop} } is missing`).toBeDefined();
      expect(normalize(match!.value), `${d.ctx} { ${d.prop} }`).toBe(normalize(d.value));
    }
  });
});
```

Run: `corepack pnpm test test/parity.test.ts`
Expected: FAIL — `src/styles/index.scss` 없음(첫 테스트는 통과).

- [ ] **Step 5: 베이스 파셜을 손으로 작성**

`design/src/styles/base/_reset.scss`(원본 1–136줄에서 토큰 블록 8–43줄만 뺀 것. 나머지 선언과 주석은 원본 그대로):

```scss
/* OpenHiggsfield AI — scoped design system.
   Identity: near-black studio, one lime accent reserved for selection,
   primary action and liveness. Structure = hairline borders; elevation =
   offset shadows. One face throughout: Inter, with tabular numerals where the
   type carries measurement. Tokens are emitted from tokens/_emit.scss. */

.ohf {
  font-family: var(--font-ui);
  font-size: 14px;
  line-height: 1.45;
  color: var(--tx);
  background: var(--bg);
  color-scheme: dark;
  caret-color: var(--accent);
  accent-color: var(--accent);
  -webkit-font-smoothing: antialiased;
}

.ohf *,
.ohf *::before,
.ohf *::after {
  box-sizing: border-box;
}

/* Element defaults are zeroed rather than overridden one rule at a time: every
   size, weight and gap in this file is stated by the component that owns it,
   so a leftover UA margin only ever fights it. :where() keeps the whole reset
   at zero specificity, so those component rules win without qualification. */
:where(.ohf *, .ohf *::before, .ohf *::after) {
  margin: 0;
  padding: 0;
}
:where(.ohf :is(h1, h2, h3, h4, h5, h6)) {
  font-size: inherit;
  font-weight: inherit;
}
:where(.ohf :is(ul, ol)) {
  list-style: none;
}
:where(.ohf :is(img, svg, video)) {
  display: block;
}
:where(.ohf :is(img, video)) {
  max-width: 100%;
  height: auto;
}

.ohf ::selection {
  background: rgba(209, 254, 23, 0.28);
  color: #fbfef1;
}

/* :where() keeps the reset at zero extra specificity so component classes win. */
.ohf :where(button) {
  font-family: inherit;
  border: 0;
  background: none;
  color: inherit;
  padding: 0;
  cursor: pointer;
}
.ohf :where(button:disabled) {
  cursor: default;
}
.ohf input,
.ohf textarea {
  font-family: inherit;
  color: inherit;
}
.ohf :focus-visible {
  outline: 2px solid var(--accent-32);
  outline-offset: 2px;
  border-radius: 6px;
}

/* Themed browser scroll surfaces */
.ohf ::-webkit-scrollbar {
  width: 8px;
  height: 8px;
}
.ohf ::-webkit-scrollbar-thumb {
  background: var(--s3);
  border-radius: 8px;
  border: 2px solid transparent;
  background-clip: padding-box;
}
.ohf ::-webkit-scrollbar-thumb:hover {
  background: var(--s4);
  background-clip: padding-box;
  border: 2px solid transparent;
}
.ohf ::-webkit-scrollbar-track {
  background: transparent;
}
.ohf .ohf-scroll {
  scrollbar-width: thin;
  scrollbar-color: var(--s3) transparent;
}
```

- [ ] **Step 6: 나머지 파셜을 줄 범위로 잘라 내기**

Run (한 번에):

```bash
cd /Users/brian/works/agent/openhigsfield/design
SRC=../open-higgsfield/src/openhiggsfield/openhiggsfield.css
mkdir -p src/styles/base src/styles/studio
sed -n '137,340p'  "$SRC" > src/styles/base/_keyframes.scss
sed -n '341,349p'  "$SRC" > src/styles/studio/_shell.scss
sed -n '350,387p'  "$SRC" > src/styles/studio/_topbar.scss
sed -n '388,462p'  "$SRC" > src/styles/studio/_tabs.scss
sed -n '463,518p'  "$SRC" > src/styles/studio/_lamp.scss
sed -n '519,527p'  "$SRC" > src/styles/studio/_main.scss
sed -n '528,708p'  "$SRC" > src/styles/studio/_gallery.scss
sed -n '709,1062p' "$SRC" > src/styles/studio/_picking.scss
sed -n '1063,1176p' "$SRC" > src/styles/studio/_empty.scss
sed -n '1177,1288p' "$SRC" > src/styles/studio/_composer.scss
sed -n '1289,1424p' "$SRC" > src/styles/studio/_attached.scss
sed -n '1425,2011p' "$SRC" > src/styles/studio/_dock.scss
sed -n '2012,2083p' "$SRC" > src/styles/studio/_tooltips.scss
sed -n '2084,2609p' "$SRC" > src/styles/studio/_popovers.scss
sed -n '2610,2894p' "$SRC" > src/styles/studio/_asset-picker.scss
sed -n '2895,2990p' "$SRC" > src/styles/studio/_dialogs.scss
sed -n '2991,3472p' "$SRC" > src/styles/studio/_viewer.scss
sed -n '3473,3486p' "$SRC" > src/styles/studio/_entrance.scss
sed -n '3487,3710p' "$SRC" > src/styles/studio/_responsive.scss
sed -n '3711,3736p' "$SRC" > src/styles/studio/_reduced-motion.scss
wc -l src/styles/base/*.scss src/styles/studio/*.scss | tail -1
```

Expected: 마지막 줄 합계가 `3600 + _reset 줄 수` 근처(원본 3,736 − 토큰 블록 36 = 3,700 안팎). 각 파일의 첫 줄이 `/* ---------- <이름> ---------- */`인지 `head -1 src/styles/studio/*.scss`로 확인한다.

`design/src/styles/index.scss`:

```scss
// Order matters: tokens first, then the reset, then the studio in its original
// section order. Component and slide SCSS are imported by their own .tsx.
@use "tokens/emit";
@use "base/reset";
@use "base/keyframes";
@use "studio/shell";
@use "studio/topbar";
@use "studio/tabs";
@use "studio/lamp";
@use "studio/main";
@use "studio/gallery";
@use "studio/picking";
@use "studio/empty";
@use "studio/composer";
@use "studio/attached";
@use "studio/dock";
@use "studio/tooltips";
@use "studio/popovers";
@use "studio/asset-picker";
@use "studio/dialogs";
@use "studio/viewer";
@use "studio/entrance";
@use "studio/responsive";
@use "studio/reduced-motion";
```

- [ ] **Step 7: parity 통과시키기**

Run: `corepack pnpm test test/parity.test.ts`
Expected: PASS (3 tests). 실패하면 메시지의 `first difference at #N`을 보고 해당 파셜을 고친다. 알려진 함정과 처방:
- Sass 컴파일 오류: SCSS 문법에서 잘못 해석되는 원본 구문(예: 문자열 밖의 `//`). 해당 줄만 SCSS가 받아들이는 형태로 고친다. 값은 바꾸지 않는다.
- 값 차이가 `a / b` 꼴이면 SCSS가 나눗셈으로 계산한 것. 그 자리를 `#{"a / b"}`로 감싼다.
- `calc()`/`min()` 값이 계산된 형태로 나오면 같은 방식으로 `#{"…"}` 처리.
- 선언 수가 다르면 `sed` 범위 실수(줄 누락·중복). 표의 줄 번호와 대조한다.

- [ ] **Step 8: 진입점 연결과 빌드**

`design/src/index.ts`:

```ts
import "./styles/index.scss";

export { cssVar, tokens } from "./tokens";
export type { Token } from "./tokens";
```

Run: `corepack pnpm build && grep -c "ohf-generate" dist/ohf.css`
Expected: `dist ok`, 그다음 1 이상의 숫자.

- [ ] **Step 9: 마무리 검증**

Run: `corepack pnpm test && corepack pnpm typecheck`
Expected: 둘 다 통과.

---

