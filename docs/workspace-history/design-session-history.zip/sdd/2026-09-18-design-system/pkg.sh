#!/usr/bin/env bash
# 리뷰 패키지: 스냅샷 BASE 대 현재(또는 스냅샷 HEAD)의 파일 목록 + -U10 diff.
# Usage: pkg.sh BASE_LABEL HEAD_LABEL [EXCLUDE_GLOB ...]   (EXCLUDE는 diff 본문에서만 뺀다)
set -euo pipefail
ws=$(cd "$(dirname "$0")" && pwd)
a="$ws/snap/$1"; b="$ws/snap/$2"; shift 2
[ -d "$a" ] && [ -d "$b" ] || { echo "no such snapshot" >&2; exit 2; }
out="$ws/review-$(basename "$a")..$(basename "$b").diff"
ex=(); for g in "$@"; do ex+=(--exclude="$g"); done
cd "$ws/snap"
{
  echo "# Review package: $(basename "$a")..$(basename "$b") (git 없음 — 스냅샷 diff)"
  echo; echo "## Files changed"
  diff -rqN "$(basename "$a")" "$(basename "$b")" | sed -E 's/^Files (.*) and (.*) differ$/M \2/' || true
  if [ ${#ex[@]} -gt 0 ]; then echo; echo "## Diff 본문에서 뺀 경로(파일 목록에는 있음): $*"; fi
  echo; echo "## Diff"
  diff -ruN -U10 ${ex[@]+"${ex[@]}"} "$(basename "$a")" "$(basename "$b")" || true
} > "$out"
echo "wrote $out: $(wc -c < "$out" | tr -d ' ') bytes, $(wc -l < "$out" | tr -d ' ') lines"
