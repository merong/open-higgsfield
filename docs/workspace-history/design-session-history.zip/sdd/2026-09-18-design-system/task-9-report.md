# Task 9 report — 슬라이드 층 (SlideFrame, 4 style presets, 5 templates)

## 구현 내용

브리프에 주어진 코드를 축자적으로 사용해 다음 파일을 생성했다:

- `design/src/slides/styles.ts` — `SlidePreset`, `SlideStyle`, `SLIDE_STYLES`(basic/editorial/impact/soft 4개 프리셋, 색·폰트 값 그대로), `SLIDE_PRESETS`.
- `design/src/slides/SlideFrame.tsx` — `.ohf-slide[data-preset]`을 렌더링하는 프레임. `ratioToCss`로 `aspect-ratio`를, 프리셋 값으로 `--sl-*` 커스텀 프로퍼티를 인라인 세팅. 이미지가 있으면 텍스트 색을 항상 흰색으로 강제하고 `dim`(숫자=고정 스크림, `"grad"`=하단 그라디언트)을 렌더링. `position`(`start`/`mid`/`end`, 기본 `end`)을 프레임이 소유.
- `design/src/slides/templates.tsx` — `CoverSlide`, `BodySlide`, `ListSlide`, `QuoteSlide`, `CtaSlide`. 문구 없이 전부 props로 받는다.
- `design/src/slides/slides.scss` — `cqw`(1080px 원판 기준) 단위로만 크기를 잡고, 색은 전부 `var(--sl-*)`. 앱 토큰·앱 색상 리터럴 없음.
- `design/src/slides/index.ts` — `SlideFrame`/`styles`/`templates` 재노출.
- `design/src/slides/slides.test.tsx` — 브리프의 테스트 코드 그대로.

## 변경 파일

- `design/src/index.ts` — `export * from "./slides";` 한 줄 추가 (`UndoBar` export와 `cx` export 사이).
- `design/README.md` — "슬라이드" 절 추가. 기획서는 `position`을 템플릿 props로 두었지만, 세로 정렬은 프레임의 레이아웃 책임이므로 `SlideFrame`이 갖는다는 점을 명시(브리프 Interfaces 섹션이 README에 적으라고 명시적으로 요구한 사항).

## 브리프 텍스트로부터의 편차

없음. 모든 코드는 브리프에 주어진 그대로 사용했고, tsc/Sass 관련 알려진 함정(ReactNode를 `cx(...)`의 불리언 표현식에 쓰는 경우, `style`의 커스텀 프로퍼티 캐스팅)은 브리프 코드에 해당 패턴이 없어 추가 수정이 필요 없었다. README에 `position` 소유권을 적으라는 지시는 브리프 문구 그대로 따랐다(코드 변경 아님, 문서 추가).

## 테스트 (RED → GREEN)

**Step 1 — RED** (`corepack pnpm test src/slides`, 테스트 파일만 작성한 상태):
```
FAIL  src/slides/slides.test.tsx [ src/slides/slides.test.tsx ]
Error: Failed to resolve import "./SlideFrame" from "src/slides/slides.test.tsx". Does the file exist?
 Test Files  1 failed (1)
      Tests  no tests
```
모듈 없음으로 실패 — 기대한 대로.

**Step 2/3 구현 후 — GREEN** (`corepack pnpm test src/slides`):
```
 Test Files  1 passed (1)
      Tests  4 passed (4)
```

## 검증 명령 (전체)

```
corepack pnpm test
```
```
 Test Files  34 passed (34)
      Tests  71 passed (71)
```
(`test/token-rules.test.ts`의 "slides reference only --sl-* custom properties and no app colours" 검사가 `src/slides`가 처음 생기면서 실제로 실행되었고 통과했다. `scssFiles("src/slides")`가 더 이상 빈 배열이 아니므로 `it.skipIf`가 skip에서 run으로 전환되었다.)

```
corepack pnpm typecheck
```
출력 없음(에러 없음) — strict tsc(`noUnusedLocals`/`noUnusedParameters` 포함) 통과.

```
corepack pnpm build
```
```
✓ 76 modules transformed.
dist/ohf.css   68.42 kB │ gzip: 12.71 kB
dist/index.js  35.88 kB │ gzip:  8.55 kB │ map: 81.38 kB
✓ built in 1.28s
dist ok
```
`dist ok`는 `scripts/check-dist.mjs`가 dist 3파일 존재, `dist/index.js`에 react-dom 없음, `d.ts`에 `@/` 없음을 모두 확인했다는 뜻이며, 동시에 `cqw` 컨테이너 쿼리 단위가 Sass 컴파일을 그대로 통과함을 확인했다(Sass 문법 오류 없음).

세 명령을 순서대로 다시 한 번 이어서 실행해도(`corepack pnpm test && corepack pnpm typecheck && corepack pnpm build`) 동일하게 전부 통과했다.

## 파일 목록

생성:
- `design/src/slides/styles.ts`
- `design/src/slides/SlideFrame.tsx`
- `design/src/slides/templates.tsx`
- `design/src/slides/slides.scss`
- `design/src/slides/index.ts`
- `design/src/slides/slides.test.tsx`

수정:
- `design/src/index.ts`
- `design/README.md`

## 자체 리뷰

- **완결성**: 브리프의 Files 목록 6개 파일 전부 생성, `src/index.ts` 수정 완료. Step 1~4를 순서대로 수행하고 각 단계의 기대 출력을 확인했다.
- **품질**: 이름·구조 브리프와 동일. `grep`으로 `console.*`/`TODO`/`FIXME`/`debugger` 잔재 없음을 확인. 테스트 출력 pristine(경고 없음, jsdom 성능 안내 메시지는 vitest 자체의 일반 안내이며 이 작업과 무관).
- **규율**: 브리프가 지정한 파일 외에는 건드리지 않았다. 다른 컴포넌트/composites 파일 미변경.
- **테스트**: 브리프의 테스트 코드를 그대로 사용했고, RED(모듈 없음) → GREEN(4/4) 전환을 직접 확인했다. `dist`에 `react-dom` 없음과 `d.ts`에 `@/` 없음을 별도 grep으로도 재확인.
- **token-rules 검증**: `slideViolations` 로직을 수동으로 대조해, `slides.scss`의 모든 리터럴 색상 값(rgba 스크림/그라디언트)이 `tokens.json`의 앱 색상·그림자 토큰 문자열과 부분 일치하지 않고, 모든 `var(--...)` 참조가 `--sl-`로 시작함을 확인했다(테스트도 실제로 이를 통과로 확인).

## 이슈/우려사항

없음.

**Status:** DONE
