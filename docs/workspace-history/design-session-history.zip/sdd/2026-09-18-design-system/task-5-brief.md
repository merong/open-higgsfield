### Task 5: 아이콘 42개

**Files:**
- Create: `design/src/icons/index.tsx`, `design/src/icons/icons.test.tsx`
- Modify: `design/src/index.ts`

**Interfaces:**
- Produces: 기존 30개(`ImageIcon`, `VideoIcon`, `AudioIcon`, `AssetsIcon`, `KeyIcon`, `CaretDownIcon`, `CloseIcon`, `CheckIcon`, `SearchIcon`, `ShuffleIcon`, `RetryIcon`, `WarningIcon`, `ArrowRightIcon`, `PlusIcon`, `MinusIcon`, `GemIcon`, `ClockIcon`, `FormatIcon`, `PlayIcon`, `PlayBadgeIcon`, `DownloadIcon`, `OpenOutIcon`, `UploadIcon`, `CopyIcon`, `SlidersIcon`, `ArrowUpIcon`, `HeartIcon`, `TrashIcon`, `UndoIcon`, `WaveBadgeIcon`) + 신규 12개(`SparkleIcon`, `PaletteIcon`, `GripIcon`, `UserIcon`, `FilmIcon`, `LayoutIcon`, `LayersIcon`, `PhoneIcon`, `TextIcon`, `WalletIcon`, `ChevronLeftIcon`, `ChevronRightIcon`). 모두 `({ size?: number }) => JSX`, `HeartIcon`만 `filled?` 추가. `export type { IconProps }`.

- [ ] **Step 1: 실패하는 테스트 작성**

`design/src/icons/icons.test.tsx`:

```tsx
import { render } from "@testing-library/react";
import { describe, expect, it } from "vitest";

import * as icons from "./index";

const NEW = [
  "SparkleIcon", "PaletteIcon", "GripIcon", "UserIcon", "FilmIcon", "LayoutIcon",
  "LayersIcon", "PhoneIcon", "TextIcon", "WalletIcon", "ChevronLeftIcon", "ChevronRightIcon",
];

describe("icons", () => {
  const names = Object.keys(icons).filter((k) => k.endsWith("Icon"));

  it("exports 30 studio icons plus 12 new ones", () => {
    expect(names).toHaveLength(42);
    for (const n of NEW) expect(names).toContain(n);
  });

  it("draws every icon on the 16 grid, stroked in currentColor, hidden from readers", () => {
    for (const name of names) {
      const Icon = icons[name as keyof typeof icons] as (p: { size?: number }) => React.JSX.Element;
      const { container, unmount } = render(<Icon size={20} />);
      const svg = container.querySelector("svg");
      expect(svg, name).not.toBeNull();
      expect(svg).toHaveAttribute("viewBox", "0 0 16 16");
      expect(svg).toHaveAttribute("aria-hidden", "true");
      expect(svg).toHaveAttribute("width", "20");
      unmount();
    }
  });
});
```

- [ ] **Step 2: 실패 확인**

Run: `corepack pnpm test src/icons`
Expected: FAIL — `./index` 없음.

- [ ] **Step 3: 기존 30개를 옮기고 12개를 추가**

Run: `cd /Users/brian/works/agent/openhigsfield/design && mkdir -p src/icons && cp ../open-higgsfield/src/openhiggsfield/icons.tsx src/icons/index.tsx`

그다음 `src/icons/index.tsx`를 열어:
1. 4번째 줄 `interface IconProps {`를 `export interface IconProps {`로 바꾼다.
2. 파일 끝에 아래를 덧붙인다(같은 16격자, 1.5px 획, `base(size)` 재사용):

```tsx

/* ---- content studio additions. Same grid, same stroke, same caps. ---- */

/* A four-point star for "write this again": the LLM's mark, never the
   generator's. */
export function SparkleIcon({ size = 14 }: IconProps) {
  return (
    <svg {...base(size)}>
      <path d="M8 2.2 9.4 6.6 13.8 8 9.4 9.4 8 13.8 6.6 9.4 2.2 8 6.6 6.6Z" />
      <path d="M12.6 2.2v2.2M11.5 3.3h2.2" />
    </svg>
  );
}

export function PaletteIcon({ size = 15 }: IconProps) {
  return (
    <svg {...base(size)}>
      <path d="M8 2.2a5.8 5.8 0 1 0 0 11.6c.8 0 1.3-.6 1.3-1.3 0-.4-.2-.7-.4-1-.2-.3-.3-.6-.3-.9 0-.7.6-1.2 1.3-1.2h1a2.9 2.9 0 0 0 2.9-2.9c0-2.5-2.6-4.3-5.8-4.3Z" />
      <circle cx="5.2" cy="7.6" r="0.7" fill="currentColor" stroke="none" />
      <circle cx="6.8" cy="5" r="0.7" fill="currentColor" stroke="none" />
      <circle cx="9.8" cy="5" r="0.7" fill="currentColor" stroke="none" />
    </svg>
  );
}

/* Six dots, not three bars: a handle you drag, not a menu you open. */
export function GripIcon({ size = 14 }: IconProps) {
  return (
    <svg {...base(size)}>
      {[4, 8, 12].map((y) => (
        <g key={y}>
          <circle cx="6" cy={y} r="0.9" fill="currentColor" stroke="none" />
          <circle cx="10" cy={y} r="0.9" fill="currentColor" stroke="none" />
        </g>
      ))}
    </svg>
  );
}

export function UserIcon({ size = 14 }: IconProps) {
  return (
    <svg {...base(size)}>
      <circle cx="8" cy="5.4" r="2.6" />
      <path d="M2.9 13.6c.4-2.6 2.5-4.1 5.1-4.1s4.7 1.5 5.1 4.1" />
    </svg>
  );
}

export function FilmIcon({ size = 14 }: IconProps) {
  return (
    <svg {...base(size)}>
      <rect x="1.75" y="2.4" width="12.5" height="11.2" rx="2.2" />
      <path d="M1.75 5.8h12.5M1.75 10.2h12.5M5.4 2.4v11.2M10.6 2.4v11.2" />
    </svg>
  );
}

export function LayoutIcon({ size = 14 }: IconProps) {
  return (
    <svg {...base(size)}>
      <rect x="1.75" y="2.4" width="12.5" height="11.2" rx="2.2" />
      <path d="M1.75 6.4h12.5M6.4 6.4v7.2" />
    </svg>
  );
}

export function LayersIcon({ size = 14 }: IconProps) {
  return (
    <svg {...base(size)}>
      <path d="M8 2.4 13.8 5.3 8 8.2 2.2 5.3Z" />
      <path d="M2.2 8.3 8 11.2l5.8-2.9M2.2 11.1 8 14l5.8-2.9" />
    </svg>
  );
}

export function PhoneIcon({ size = 14 }: IconProps) {
  return (
    <svg {...base(size)}>
      <rect x="4.4" y="1.75" width="7.2" height="12.5" rx="1.8" />
      <path d="M7.2 11.8h1.6" />
    </svg>
  );
}

export function TextIcon({ size = 14 }: IconProps) {
  return (
    <svg {...base(size)}>
      <path d="M3.2 3.6h9.6M8 3.6v9M5.6 12.6h4.8" />
    </svg>
  );
}

export function WalletIcon({ size = 14 }: IconProps) {
  return (
    <svg {...base(size)}>
      <rect x="1.75" y="3.6" width="12.5" height="9.2" rx="2" />
      <path d="M1.75 6.6h12.5M10.4 9.6h1.6" />
    </svg>
  );
}

export function ChevronLeftIcon({ size = 14 }: IconProps) {
  return (
    <svg {...base(size)}>
      <path d="M9.8 3.4 5.4 8l4.4 4.6" />
    </svg>
  );
}

export function ChevronRightIcon({ size = 14 }: IconProps) {
  return (
    <svg {...base(size)}>
      <path d="M6.2 3.4 10.6 8l-4.4 4.6" />
    </svg>
  );
}
```

`design/src/index.ts`에 한 줄 추가:

```ts
export * from "./icons";
```

- [ ] **Step 4: 통과 확인**

Run: `corepack pnpm test src/icons`
Expected: PASS (2 tests).

Run: `corepack pnpm test && corepack pnpm typecheck`
Expected: 둘 다 통과. `tsc`가 `React` 네임스페이스를 못 찾으면 테스트 파일 상단에 `import type { JSX } from "react";`를 넣고 `React.JSX.Element`를 `JSX.Element`로 바꾼다.

---

