### Task 7: 기본 요소 2묶음 — Field, Input, Textarea, Stepper, Switch, Slider, OptionList, Avatar, CreditBadge

**Files:**
- Create: `design/src/components/{Field,Input,Textarea,Stepper,Switch,Slider,OptionList,Avatar,CreditBadge}/…`
- Modify: `design/src/index.ts`

**Interfaces:**
- Consumes: `cx`, `ratioBox`, 아이콘 `CheckIcon`, `MinusIcon`, `PlusIcon`, `GemIcon`.
- Produces:
  - `Field({ label, hint?, required?: ReactNode, optional?: ReactNode, counter?: {value,max}, error?, value?, htmlFor?, children })` → `.ohf-field(.ohf-field--error)`
  - `Input({ invalid?, ...input })` → `.ohf-input[aria-invalid]`; `Textarea({ invalid?, ...textarea })` → `.ohf-input.ohf-input--area`
  - `Stepper({ value, min, max, onChange, suffix?, decrementLabel, incrementLabel })` → `.ohf-batch`
  - `Switch({ checked, onChange, "aria-label", disabled? })` → `[role=switch].ohf-switch`
  - `Slider({ min, max, step?, value, onChange, "aria-label" })` → `.ohf-slider`(원본 `ui.tsx`)
  - `OptionList({ options, value, onChange, ratio? })` → `.ohf-opts`(원본 `ui.tsx`)
  - `Avatar({ initials?, src?, alt?, size?: 28|32|44 })` → `.ohf-avatar`
  - `CreditBadge({ amount, unit?, icon?, locale? })` → `.ohf-credit`

- [ ] **Step 1: 실패하는 테스트 작성(9개 파일)**

`design/src/components/Field/Field.test.tsx`:

```tsx
import { render, screen } from "@testing-library/react";
import { expect, it } from "vitest";

import { Field } from "./Field";

it("labels its control and shows marks, counter and hint", () => {
  render(
    <Field label="주제" htmlFor="t" required="필수" counter={{ value: 16, max: 120 }} hint="한 줄이면 됩니다">
      <input id="t" />
    </Field>,
  );
  expect(screen.getByLabelText(/주제/)).toHaveAttribute("id", "t");
  expect(screen.getByText("필수")).toHaveClass("ohf-field-mark--req");
  expect(screen.getByText("16 / 120")).toHaveClass("ohf-field-counter");
  expect(screen.getByText("한 줄이면 됩니다")).toHaveClass("ohf-field-hint");
});

it("turns red past the limit and on error", () => {
  const { container, rerender } = render(
    <Field label="본문" counter={{ value: 96, max: 90 }}>
      <textarea />
    </Field>,
  );
  expect(container.firstChild).toHaveClass("ohf-field--error");
  expect(screen.getByText("96 / 90")).toHaveClass("ohf-field-counter--over");
  rerender(
    <Field label="본문" error="90자를 넘었습니다">
      <textarea />
    </Field>,
  );
  expect(screen.getByRole("alert")).toHaveTextContent("90자를 넘었습니다");
});
```

`design/src/components/Input/Input.test.tsx`:

```tsx
import { render, screen } from "@testing-library/react";
import { expect, it } from "vitest";

import { Input } from "./Input";

it("is a native input with the studio class and an invalid state", () => {
  render(<Input aria-label="대상 독자" invalid />);
  const el = screen.getByRole("textbox", { name: "대상 독자" });
  expect(el).toHaveClass("ohf-input");
  expect(el).toHaveAttribute("aria-invalid", "true");
});
```

`design/src/components/Textarea/Textarea.test.tsx`:

```tsx
import { render, screen } from "@testing-library/react";
import { expect, it } from "vitest";

import { Textarea } from "./Textarea";

it("is a native textarea wearing the input face", () => {
  render(<Textarea aria-label="꼭 넣을 내용" rows={3} />);
  const el = screen.getByRole("textbox", { name: "꼭 넣을 내용" });
  expect(el.tagName).toBe("TEXTAREA");
  expect(el).toHaveClass("ohf-input", "ohf-input--area");
});
```

`design/src/components/Stepper/Stepper.test.tsx`:

```tsx
import { fireEvent, render, screen } from "@testing-library/react";
import { expect, it, vi } from "vitest";

import { Stepper } from "./Stepper";

it("steps within bounds and disables the edge buttons", () => {
  const onChange = vi.fn();
  render(<Stepper value={10} min={4} max={10} onChange={onChange} suffix="장" decrementLabel="한 장 줄이기" incrementLabel="한 장 늘리기" />);
  expect(screen.getByRole("button", { name: "한 장 늘리기" })).toBeDisabled();
  fireEvent.click(screen.getByRole("button", { name: "한 장 줄이기" }));
  expect(onChange).toHaveBeenCalledWith(9);
  expect(screen.getByText("10")).toHaveClass("ohf-batch-value");
  expect(screen.getByText("장")).toHaveClass("ohf-batch-max");
});
```

`design/src/components/Switch/Switch.test.tsx`:

```tsx
import { fireEvent, render, screen } from "@testing-library/react";
import { expect, it, vi } from "vitest";

import { Switch } from "./Switch";

it("is a switch that flips on click", () => {
  const onChange = vi.fn();
  render(<Switch checked={false} onChange={onChange} aria-label="쪽 번호 표시" />);
  const el = screen.getByRole("switch", { name: "쪽 번호 표시" });
  expect(el).toHaveAttribute("aria-checked", "false");
  fireEvent.click(el);
  expect(onChange).toHaveBeenCalledWith(true);
});
```

`design/src/components/Slider/Slider.test.tsx`:

```tsx
import { fireEvent, render, screen } from "@testing-library/react";
import { expect, it, vi } from "vitest";

import { Slider } from "./Slider";

it("is a range input whose fill follows the value", () => {
  const onChange = vi.fn();
  render(<Slider min={0} max={100} value={40} onChange={onChange} aria-label="어둡게" />);
  const el = screen.getByRole("slider", { name: "어둡게" });
  expect(el).toHaveClass("ohf-slider");
  expect(el.style.getPropertyValue("--fill")).toBe("40.0%");
  fireEvent.change(el, { target: { value: "75" } });
  expect(onChange).toHaveBeenCalledWith(75);
});
```

`design/src/components/OptionList/OptionList.test.tsx`:

```tsx
import { fireEvent, render, screen } from "@testing-library/react";
import { expect, it, vi } from "vitest";

import { OptionList } from "./OptionList";

const options = [
  { value: "auto", label: "Auto" },
  { value: "4:5", label: "4:5" },
];

it("lists options as pressed buttons and reports a pick", () => {
  const onChange = vi.fn();
  render(<OptionList options={options} value="4:5" onChange={onChange} ratio />);
  expect(screen.getByRole("button", { name: "4:5", pressed: true })).toHaveClass("ohf-opt");
  fireEvent.click(screen.getByRole("button", { name: "Auto" }));
  expect(onChange).toHaveBeenCalledWith("auto");
  expect(document.querySelector(".ohf-opt-box--auto")).not.toBeNull();
});
```

`design/src/components/Avatar/Avatar.test.tsx`:

```tsx
import { render, screen } from "@testing-library/react";
import { expect, it } from "vitest";

import { Avatar } from "./Avatar";

it("shows initials or a picture at a fixed size", () => {
  const { container, rerender } = render(<Avatar initials="BK" size={44} />);
  expect(container.firstChild).toHaveClass("ohf-avatar", "ohf-avatar--44");
  expect(screen.getByText("BK")).toBeInTheDocument();
  rerender(<Avatar src="/me.png" alt="내 사진" />);
  expect(screen.getByRole("img", { name: "내 사진" })).toHaveClass("ohf-avatar-img");
});
```

`design/src/components/CreditBadge/CreditBadge.test.tsx`:

```tsx
import { render, screen } from "@testing-library/react";
import { expect, it } from "vitest";

import { CreditBadge } from "./CreditBadge";

it("formats the amount with thousands separators and takes a unit", () => {
  const { container } = render(<CreditBadge amount={1240} unit="크레딧" />);
  expect(container.firstChild).toHaveClass("ohf-credit");
  expect(screen.getByText("1,240")).toHaveClass("ohf-credit-amount");
  expect(screen.getByText("크레딧")).toHaveClass("ohf-credit-unit");
});
```

Run: `corepack pnpm test src/components`
Expected: 새 9개 파일 모두 FAIL(모듈 없음).

- [ ] **Step 2: Field, Input, Textarea 구현**

`design/src/components/Field/Field.tsx`:

```tsx
import type { ReactNode } from "react";

import { cx } from "@/lib/cx";

import "./Field.scss";

export interface FieldProps {
  label: ReactNode;
  hint?: ReactNode;
  /* Marks are copy, so they arrive as nodes ("필수", "선택"), never booleans. */
  required?: ReactNode;
  optional?: ReactNode;
  counter?: { value: number; max: number };
  error?: ReactNode;
  /* A value shown on the label's row, as the studio's setting popovers do. */
  value?: ReactNode;
  htmlFor?: string;
  children: ReactNode;
  className?: string;
}

export function Field({ label, hint, required, optional, counter, error, value, htmlFor, children, className }: FieldProps) {
  const over = counter !== undefined && counter.value > counter.max;
  return (
    <div className={cx("ohf-field", (error || over) && "ohf-field--error", className)}>
      <div className="ohf-field-row">
        <label className="ohf-field-label" htmlFor={htmlFor}>
          {label}
          {required && <span className="ohf-field-mark ohf-field-mark--req">{required}</span>}
          {optional && <span className="ohf-field-mark">{optional}</span>}
        </label>
        {value !== undefined && <span className="ohf-field-value">{value}</span>}
        {counter && (
          <span className={cx("ohf-field-counter", over && "ohf-field-counter--over")}>
            {counter.value} / {counter.max}
          </span>
        )}
      </div>
      {children}
      {hint !== undefined && !error && <div className="ohf-field-hint">{hint}</div>}
      {error !== undefined && (
        <div className="ohf-field-error" role="alert">
          {error}
        </div>
      )}
    </div>
  );
}
```

`design/src/components/Field/Field.scss`:

```scss
@use "@/styles/mixins" as m;

.ohf-field-mark {
  margin-left: 6px;
  font-size: 11px;
  font-weight: var(--fw-medium);
  color: var(--tx4);
  &--req {
    color: var(--accent);
  }
}
.ohf-field-counter {
  font-size: var(--fs-xs);
  color: var(--tx4);
  @include m.tabular;
  &--over {
    color: var(--danger);
  }
}
.ohf-field-hint,
.ohf-field-error {
  font-size: var(--fs-xs);
  line-height: 1.45;
  color: var(--tx4);
}
.ohf-field-error {
  color: var(--danger);
}
.ohf-field--error .ohf-input {
  border-color: var(--danger-line);
}
```

`design/src/components/Field/index.ts`: `export * from "./Field";`

`design/src/components/Input/Input.tsx`:

```tsx
import type { InputHTMLAttributes, Ref } from "react";

import { cx } from "@/lib/cx";

import "./Input.scss";

export interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  invalid?: boolean;
  ref?: Ref<HTMLInputElement>;
}

export function Input({ invalid = false, className, ...rest }: InputProps) {
  return <input className={cx("ohf-input", className)} aria-invalid={invalid || undefined} {...rest} />;
}
```

`design/src/components/Input/Input.scss`(Textarea도 이 파일을 쓴다):

```scss
.ohf-input {
  color: var(--tx);
  &::placeholder {
    color: var(--tx4);
  }
  &[data-state="focus"] {
    border-color: var(--accent-32);
    box-shadow: 0 0 0 3px var(--accent-08);
  }
  &[aria-invalid="true"] {
    border-color: var(--danger-line);
    &:focus {
      box-shadow: 0 0 0 3px var(--danger-bg);
    }
  }
  &:disabled {
    color: var(--tx-off);
    background: transparent;
    border-color: var(--line);
  }
}
.ohf-input--area {
  resize: none;
  min-height: 72px;
  padding: 10px 12px;
  line-height: 1.5;
}
```

`design/src/components/Input/index.ts`: `export * from "./Input";`

`design/src/components/Textarea/Textarea.tsx`:

```tsx
import type { Ref, TextareaHTMLAttributes } from "react";

import { cx } from "@/lib/cx";

import "../Input/Input.scss";

export interface TextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  invalid?: boolean;
  ref?: Ref<HTMLTextAreaElement>;
}

export function Textarea({ invalid = false, className, ...rest }: TextareaProps) {
  return <textarea className={cx("ohf-input", "ohf-input--area", className)} aria-invalid={invalid || undefined} {...rest} />;
}
```

`design/src/components/Textarea/index.ts`: `export * from "./Textarea";`

- [ ] **Step 3: Stepper, Switch 구현**

`design/src/components/Stepper/Stepper.tsx`:

```tsx
import type { ReactNode } from "react";

import { MinusIcon, PlusIcon } from "@/icons";
import { cx } from "@/lib/cx";

import "./Stepper.scss";

export interface StepperProps {
  value: number;
  min: number;
  max: number;
  onChange: (next: number) => void;
  suffix?: ReactNode;
  decrementLabel: string;
  incrementLabel: string;
  className?: string;
}

export function Stepper({ value, min, max, onChange, suffix, decrementLabel, incrementLabel, className }: StepperProps) {
  return (
    <div className={cx("ohf-batch", className)} role="group">
      <button
        type="button"
        className="ohf-batch-step"
        aria-label={decrementLabel}
        disabled={value <= min}
        onClick={() => onChange(Math.max(min, value - 1))}
      >
        <MinusIcon />
      </button>
      <span className="ohf-batch-value" aria-live="polite">
        {value}
        {suffix !== undefined && <span className="ohf-batch-max">{suffix}</span>}
      </span>
      <button
        type="button"
        className="ohf-batch-step"
        aria-label={incrementLabel}
        disabled={value >= max}
        onClick={() => onChange(Math.min(max, value + 1))}
      >
        <PlusIcon />
      </button>
    </div>
  );
}
```

`design/src/components/Stepper/Stepper.scss`:

```scss
.ohf-batch[data-state="hover"] {
  background: var(--s3);
}
.ohf-batch-step[data-state="hover"] {
  background: var(--s4);
  color: var(--tx);
}
.ohf-batch-step[data-state="active"] {
  transform: scale(0.9);
}
.ohf-batch-max {
  margin-left: 2px;
}
```

`design/src/components/Stepper/index.ts`: `export * from "./Stepper";`

`design/src/components/Switch/Switch.tsx`:

```tsx
import { cx } from "@/lib/cx";

import "./Switch.scss";

export interface SwitchProps {
  checked: boolean;
  onChange: (next: boolean) => void;
  "aria-label": string;
  disabled?: boolean;
  className?: string;
}

export function Switch({ checked, onChange, disabled = false, className, "aria-label": ariaLabel }: SwitchProps) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={ariaLabel}
      disabled={disabled}
      className={cx("ohf-switch", className)}
      onClick={() => onChange(!checked)}
    >
      <span className="ohf-switch-knob" aria-hidden="true" />
    </button>
  );
}
```

`design/src/components/Switch/Switch.scss`:

```scss
.ohf-switch {
  position: relative;
  width: 36px;
  height: 20px;
  flex-shrink: 0;
  border-radius: var(--radius-pill);
  background: var(--s4);
  transition: background var(--dur-base) ease;

  /* On is a state, so it is the one place this control takes the accent. */
  &[aria-checked="true"] {
    background: var(--accent);
  }
  &:disabled {
    opacity: 0.45;
    cursor: default;
  }
}
.ohf-switch-knob {
  position: absolute;
  top: 2px;
  left: 2px;
  width: 16px;
  height: 16px;
  border-radius: 50%;
  background: var(--tx);
  box-shadow: var(--shadow-1);
  transition:
    translate var(--dur-slow) var(--ease),
    background var(--dur-base) ease;
}
.ohf-switch[aria-checked="true"] .ohf-switch-knob {
  translate: 16px 0;
  background: var(--bg);
}
```

`design/src/components/Switch/index.ts`: `export * from "./Switch";`

- [ ] **Step 4: Slider, OptionList 구현(원본 `ui.tsx` 이식)**

`design/src/components/Slider/Slider.tsx`:

```tsx
import type { CSSProperties } from "react";

import { cx } from "@/lib/cx";

export interface SliderProps {
  min: number;
  max: number;
  step?: number;
  value: number;
  onChange: (next: number) => void;
  "aria-label": string;
  className?: string;
}

export function Slider({ min, max, step = 1, value, onChange, className, "aria-label": ariaLabel }: SliderProps) {
  const fill = `${(((value - min) / (max - min || 1)) * 100).toFixed(1)}%`;
  return (
    <input
      type="range"
      className={cx("ohf-slider", className)}
      min={min}
      max={max}
      step={step}
      value={value}
      aria-label={ariaLabel}
      style={{ "--fill": fill } as CSSProperties}
      onChange={(event) => onChange(Number(event.target.value))}
    />
  );
}
```

`design/src/components/Slider/index.ts`: `export * from "./Slider";`

`design/src/components/OptionList/OptionList.tsx`:

```tsx
import { useLayoutEffect, useRef } from "react";

import { CheckIcon } from "@/icons";
import { ratioBox } from "@/lib/ratio";

/** One value of an enum, on its own line: the frame the ratio is about to
    make on the left, the mark of the value in force on the right. */
function Option({
  value,
  label,
  active,
  onSelect,
  ratio,
}: {
  value: string;
  label: string;
  active: boolean;
  onSelect: () => void;
  ratio?: boolean;
}) {
  const box = ratio ? ratioBox(value) : null;
  return (
    <button type="button" className="ohf-opt" aria-pressed={active} onClick={onSelect}>
      {/* Every line of a ratio list reserves the glyph box, so the labels of
          "Auto" and "16:9" sit on the same rail. */}
      {ratio && (
        <span className="ohf-opt-ratio" aria-hidden>
          <span className={`ohf-opt-box${box ? "" : " ohf-opt-box--auto"}`} style={box ?? undefined} />
        </span>
      )}
      <span className="ohf-opt-label">{label}</span>
      {active && (
        <span className="ohf-opt-check" aria-hidden>
          <CheckIcon size={12} />
        </span>
      )}
    </button>
  );
}

export interface OptionListProps {
  options: readonly { value: string; label: string }[];
  value: string;
  onChange: (next: string) => void;
  ratio?: boolean;
}

/** The values of one enum, listed down a single column. */
export function OptionList({ options, value, onChange, ratio }: OptionListProps) {
  const listRef = useRef<HTMLDivElement>(null);

  /* A long list opens scrolled to the top, so the value in force is carried
     into view before the panel is painted. */
  useLayoutEffect(() => {
    const list = listRef.current;
    const current = list?.querySelector<HTMLElement>('[aria-pressed="true"]');
    if (!list || !current) return;
    list.scrollTop = Math.max(0, current.offsetTop - (list.clientHeight - current.offsetHeight) / 2);
  }, []);

  return (
    <div className="ohf-opts ohf-scroll" role="group" ref={listRef}>
      {options.map((option) => (
        <Option
          key={option.value}
          value={option.value}
          label={option.label}
          active={option.value === value}
          ratio={ratio}
          onSelect={() => onChange(option.value)}
        />
      ))}
    </div>
  );
}
```

`design/src/components/OptionList/index.ts`: `export * from "./OptionList";`

- [ ] **Step 5: Avatar, CreditBadge 구현**

`design/src/components/Avatar/Avatar.tsx`:

```tsx
import type { HTMLAttributes } from "react";

import { cx } from "@/lib/cx";

import "./Avatar.scss";

export interface AvatarProps extends HTMLAttributes<HTMLSpanElement> {
  initials?: string;
  src?: string;
  alt?: string;
  size?: 28 | 32 | 44;
}

export function Avatar({ initials, src, alt = "", size = 32, className, ...rest }: AvatarProps) {
  return (
    <span className={cx("ohf-avatar", `ohf-avatar--${size}`, className)} {...rest}>
      {src ? <img className="ohf-avatar-img" src={src} alt={alt} /> : initials}
    </span>
  );
}
```

`design/src/components/Avatar/Avatar.scss`:

```scss
.ohf-avatar {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  overflow: hidden;
  border-radius: 50%;
  background: var(--s3);
  border: 1px solid var(--line-2);
  color: var(--tx2);
  font-size: 11px;
  font-weight: var(--fw-bold);
  letter-spacing: 0.02em;
  text-transform: uppercase;

  &--28 {
    width: var(--h-xs);
    height: var(--h-xs);
    font-size: 10px;
  }
  &--32 {
    width: var(--h-sm);
    height: var(--h-sm);
  }
  &--44 {
    width: 44px;
    height: 44px;
    font-size: var(--fs-base);
  }
}
.ohf-avatar-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
```

`design/src/components/Avatar/index.ts`: `export * from "./Avatar";`

`design/src/components/CreditBadge/CreditBadge.tsx`:

```tsx
import type { HTMLAttributes, ReactNode } from "react";

import { GemIcon } from "@/icons";
import { cx } from "@/lib/cx";

import "./CreditBadge.scss";

export interface CreditBadgeProps extends HTMLAttributes<HTMLSpanElement> {
  amount: number;
  unit?: ReactNode;
  icon?: ReactNode;
  locale?: string;
}

export function CreditBadge({ amount, unit, icon, locale = "ko-KR", className, ...rest }: CreditBadgeProps) {
  return (
    <span className={cx("ohf-credit", className)} {...rest}>
      <span className="ohf-credit-icon">{icon ?? <GemIcon />}</span>
      <span className="ohf-credit-amount">{amount.toLocaleString(locale)}</span>
      {unit !== undefined && <span className="ohf-credit-unit">{unit}</span>}
    </span>
  );
}
```

`design/src/components/CreditBadge/CreditBadge.scss`:

```scss
@use "@/styles/mixins" as m;

.ohf-credit {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  height: var(--h-sm);
  padding: 0 11px;
  border-radius: var(--radius-md);
  background: var(--s1);
  border: 1px solid var(--line);
  color: var(--tx2);
  font-size: 12px;
  white-space: nowrap;
  @include m.tabular;
}
.ohf-credit-icon {
  display: flex;
  color: var(--tx3);
}
.ohf-credit-amount {
  font-weight: var(--fw-bold);
  color: var(--tx);
}
```

`design/src/components/CreditBadge/index.ts`: `export * from "./CreditBadge";`

- [ ] **Step 6: 공개 API와 검증**

`design/src/index.ts`에 추가:

```ts
export * from "./components/Avatar";
export * from "./components/CreditBadge";
export * from "./components/Field";
export * from "./components/Input";
export * from "./components/OptionList";
export * from "./components/Slider";
export * from "./components/Stepper";
export * from "./components/Switch";
export * from "./components/Textarea";
```

Run: `corepack pnpm test && corepack pnpm typecheck && corepack pnpm build`
Expected: 전부 통과, `dist ok`.

---

