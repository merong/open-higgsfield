# @openhiggsfield/design

OpenHiggsfield 스튜디오의 디자인 시스템. React + Vite, SCSS → `ohf.css`.

- `corepack pnpm dev` — 쇼케이스
- `corepack pnpm build` — `dist/index.js`, `dist/index.d.ts`, `dist/ohf.css`
- `corepack pnpm test && corepack pnpm typecheck`
