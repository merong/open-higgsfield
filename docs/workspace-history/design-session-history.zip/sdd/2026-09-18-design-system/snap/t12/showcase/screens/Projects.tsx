import { Button, Chip, Pill, ProjectCard, Thumb } from "@/index";
import { ClockIcon, PlusIcon } from "@/index";

import { PHOTOS, PROJECTS } from "../data";
import { AppBar, Screen } from "./shell";

export function Projects() {
  return (
    <Screen width={1440} height={900}>
      <AppBar />
      <main className="sc-page" style={{ width: 1200 }}>
        <div className="sc-page-head">
          <h1 className="sc-page-title">프로젝트</h1>
          <span className="sc-page-count">{PROJECTS.length}개</span>
          <span className="sc-spacer" />
          <Button variant="primary" size="lg" icon={<PlusIcon />}>새 프로젝트</Button>
        </div>
        <div className="sc-toolbar" style={{ marginBottom: 0 }}>
          <Chip pressed>전체</Chip>
          <Chip pressed={false}>카드뉴스</Chip>
          <Chip disabled>릴스 · 준비 중</Chip>
          <Chip disabled>랜딩 페이지 · 준비 중</Chip>
          <span className="sc-spacer" />
          <Pill glyph={<ClockIcon />} label="정렬" value="최근 수정" />
        </div>
        <div className="sc-cards">
          <a className="sc-new-card" href="#screens/new">
            <span className="sc-new-card-plus"><PlusIcon size={18} /></span>
            <span className="sc-new-card-title">새 프로젝트</span>
            <span className="sc-muted">주제 한 줄로 시작합니다</span>
          </a>
          {PROJECTS.map((p) => (
            <ProjectCard
              key={p.title}
              href="#screens/editor-generating"
              title={p.title}
              meta={p.meta}
              status={p.status}
              statusTone={p.tone}
              deck={p.deck.map((d, i) => (
                <Thumb key={i} size={80} state={d.state} src={d.photo ? PHOTOS[d.photo] : undefined} />
              ))}
            />
          ))}
        </div>
      </main>
    </Screen>
  );
}
