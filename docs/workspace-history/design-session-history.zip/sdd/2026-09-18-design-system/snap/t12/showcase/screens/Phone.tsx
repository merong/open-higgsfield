import { Avatar, HeartIcon, PhoneIcon } from "@/index";

import { DECK } from "../data";
import { renderSlide } from "../lib/slide";
import { Screen } from "./shell";

export function Phone() {
  return (
    <Screen width={390} height={844}>
      <div className="sc-phone-head">
        <Avatar initials="S" size={32} />
        <div style={{ display: "flex", flexDirection: "column" }}>
          <span style={{ fontWeight: 600 }}>sunny.skin.lab</span>
          <span className="sc-muted" style={{ fontSize: 11 }}>협찬 아님 · 원본 오디오</span>
        </div>
      </div>
      <div style={{ position: "relative", flexShrink: 0 }}>
        {renderSlide(DECK[0]!, 1, "basic", "4:5", true, { style: { borderRadius: 0 } })}
        <span className="sc-badge">1/8</span>
      </div>
      <div className="sc-phone-actions">
        <HeartIcon size={22} />
        <div className="sc-dots">{DECK.map((_, i) => <i key={i} />)}</div>
      </div>
      <div className="sc-phone-caption">
        <span style={{ fontWeight: 600 }}>좋아요 1,284개</span>
        <span><b style={{ fontWeight: 600 }}>sunny.skin.lab</b> SPF 50이면 하루 종일 안심일까요? 숫자보다 중요한 건 덧바르는 습관이에요… <span className="sc-muted">더 보기</span></span>
        <span className="sc-muted">댓글 36개 모두 보기</span>
      </div>
      <span className="sc-spacer" />
      <div className="sc-phone-foot">
        <span className="ohf-credit"><PhoneIcon size={13} />휴대폰 미리보기 · 인스타그램 피드</span>
        <span className="sc-muted">옆으로 넘겨 보세요</span>
      </div>
    </Screen>
  );
}
