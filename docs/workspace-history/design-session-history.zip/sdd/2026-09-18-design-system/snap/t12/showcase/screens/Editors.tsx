import { ActionStrip, Button, Chip, Dialog, Field, IconButton, Input, Popover, StyleCard, Switch, Textarea, Thumb, SLIDE_PRESETS, SLIDE_STYLES, type ThumbState } from "@/index";
import { CaretDownIcon, CheckIcon, CloseIcon, CopyIcon, DownloadIcon, ImageIcon, PlusIcon, SparkleIcon } from "@/index";

import { DECK, PHOTOS } from "../data";
import { renderSlide } from "../lib/slide";
import { canvas, storyRows } from "./editor";
import { EditorShell } from "./shell";

const OPTIONS: [string, string][] = [["위치", "아래"], ["제목", "크게"], ["어둡게", "40%"]];
const PRESET_NAMES = { basic: ["기본 고딕", "Pretendard · 남색과 노랑"], editorial: ["에디토리얼", "Noto Serif KR 제목 · 크림과 벽돌색"], impact: ["임팩트", "Black Han Sans 제목 · 검정과 주홍"], soft: ["부드럽게", "Gowun Dodum · 세이지와 초록"] } as const;

export function EditorOutline() {
  const states = DECK.map((s): ThumbState => (s.kind === "cta" ? "flat" : "empty"));
  return (
    <EditorShell
      rows={storyRows(states, 0, 4)}
      strip={
        <ActionStrip
          status={<><ImageIcon size={15} />이미지가 없는 슬라이드 <b>7장</b> · 문구를 확정한 뒤 생성하세요</>}
          actions={<><Button icon={<PlusIcon />}>슬라이드 추가</Button><Button variant="primary" size="lg" icon={<SparkleIcon />}>7장 생성 · 28 크레딧</Button></>}
        />
      }
      panel={canvas({ index: 1, template: "표지", options: OPTIONS, hint: "이미지가 없는 동안에는 스타일의 단색 배경 위에 글만 얹어 보여 줍니다", withImage: false })}
    />
  );
}

export function EditorGenerating() {
  const states: ThumbState[] = ["image", "image", "image", "pending", "failed", "empty", "empty", "flat"];
  return (
    <EditorShell
      rows={storyRows(states, 0)}
      strip={
        <ActionStrip
          status={<><span className="sc-lamp" /><b>1장</b> 생성 중 · 문구는 계속 고칠 수 있습니다</>}
          actions={<><Button icon={<PlusIcon />}>슬라이드 추가</Button><Button variant="primary" size="lg" icon={<SparkleIcon />}>남은 3장 생성 · 12 크레딧</Button></>}
        />
      }
      panel={canvas({ index: 1, template: "표지", options: OPTIONS, hint: "캔버스에서 배경을 끌어 잘릴 위치를 맞춥니다 · ⌘Enter로 남은 슬라이드를 생성합니다" })}
    />
  );
}

function StylePanel() {
  return (
    <div className="sc-overlay-pop">
      <Popover variant="setting" placement="static" style={{ width: 400, maxHeight: "none", padding: 18, display: "flex", flexDirection: "column", gap: 16 }} role="dialog" aria-label="스타일">
        <div className="sc-cell">
          <span style={{ fontSize: 14, fontWeight: 620 }}>스타일</span>
          <span className="sc-muted">덱 전체에 적용됩니다</span>
          <span className="sc-spacer" />
          <IconButton ghost size={28} icon={<CloseIcon />} aria-label="닫기" />
        </div>
        <div className="sc-style-grid">
          {SLIDE_PRESETS.map((p) => (
            <StyleCard
              key={p}
              pressed={p === "basic"}
              name={PRESET_NAMES[p][0]}
              description={PRESET_NAMES[p][1]}
              preview={
                <>
                  {renderSlide(DECK[0]!, 1, p, "4:5", true, { showFooter: false })}
                  {renderSlide(DECK[7]!, 8, p, "4:5", false, { showFooter: false })}
                </>
              }
            />
          ))}
        </div>
        <div className="sc-stack" style={{ gap: 8 }}>
          <span className="sc-label">색</span>
          <div className="sc-cell" style={{ gap: 6 }}>
            {([["배경", SLIDE_STYLES.basic.bg], ["글자", SLIDE_STYLES.basic.tx], ["강조", SLIDE_STYLES.basic.acc]] as const).map(([n, c]) => (
              <button key={n} type="button" className="sc-swatch-btn" aria-label={`${n} 색 바꾸기`}>
                <i style={{ background: c }} />
                <span className="sc-muted">{n}</span>
                <span className="sc-spacer" />
                <span style={{ color: "var(--tx)" }}>{c.toUpperCase()}</span>
              </button>
            ))}
          </div>
        </div>
        <div className="sc-row-2" style={{ gridTemplateColumns: "1fr auto", alignItems: "end", gap: 12 }}>
          <Field label="계정 핸들" htmlFor="st-handle"><Input id="st-handle" defaultValue="@sunny.skin.lab" /></Field>
          <Field label="쪽 번호"><div style={{ height: 34, display: "flex", alignItems: "center" }}><Switch checked onChange={() => {}} aria-label="쪽 번호 표시" /></div></Field>
        </div>
        <Field label="이미지 스타일" htmlFor="st-img" hint="모든 슬라이드의 프롬프트 뒤에 붙습니다"><Textarea id="st-img" rows={2} defaultValue="따뜻한 필름 톤, 자연광, 여백 많은 구도" /></Field>
        <Field label="이미지 모델">
          <Button variant="model" icon={<span className="sc-cell" style={{ width: 18, height: 18, borderRadius: 5, background: "#e8e8ec", color: "#111", fontSize: 9, fontWeight: 800, justifyContent: "center" }}>F2</span>} style={{ justifyContent: "flex-start" }}>
            Flux 2 <span className="sc-muted">4 크레딧 / 장</span>
            <span className="sc-spacer" />
            <CaretDownIcon />
          </Button>
        </Field>
      </Popover>
    </div>
  );
}

export function EditorStyle() {
  const states: ThumbState[] = [...Array<ThumbState>(7).fill("image"), "flat"];
  return (
    <EditorShell
      rows={storyRows(states, 0)}
      strip={
        <ActionStrip
          status={<><CheckIcon size={15} />8장 모두 완성 · 내보낼 준비가 됐습니다</>}
          actions={<><Button icon={<PlusIcon />}>슬라이드 추가</Button><Button variant="primary" size="lg" icon={<SparkleIcon />} disabled>남은 슬라이드 없음</Button></>}
        />
      }
      panel={canvas({ index: 1, template: "표지", options: OPTIONS, hint: "스타일을 바꾸면 여덟 장이 모두 다시 그려집니다 · 이미지는 그대로입니다" })}
      exportPrimary
      styleOpen
      overlay={<StylePanel />}
    />
  );
}

function ExportDialog() {
  const caption = "SPF 50이면 하루 종일 안심일까요? 숫자보다 중요한 건 덧바르는 습관이에요. 출퇴근·야외·물놀이 상황별로 어떤 지수를 고르면 되는지, 성분표에서 무엇을 봐야 하는지 8장에 정리했어요. 저장해 두고 여름 내내 꺼내 보세요.";
  const tags = ["자외선차단제", "선크림추천", "여름피부관리", "스킨케어팁", "SPF", "PA등급", "덧바르기"].map((t) => `#${t}`).join(" ");
  return (
    <div className="sc-scrim">
      <Dialog open inline title="내보내기" onClose={() => {}} closeLabel="닫기" width={600} head={<span className="sc-muted">8장 · 1080×1350 · 크레딧을 쓰지 않습니다</span>}>
        <div className="sc-cell" style={{ gap: 6 }}>
          {DECK.map((s, i) => (
            <Thumb key={i} size={52} state={s.photo ? "image" : "flat"} src={s.photo ? PHOTOS[s.photo] : undefined} />
          ))}
        </div>
        <div className="sc-cell" style={{ gap: 6 }}>
          <span className="sc-label" style={{ width: 44 }}>형식</span>
          <Chip pressed>PNG</Chip>
          <Chip pressed={false}>JPG</Chip>
          <span className="sc-muted" style={{ marginLeft: 6 }}>01.png ~ 08.png와 caption.txt를 ZIP으로 묶습니다</span>
        </div>
        <Field label="캡션" htmlFor="ex-cap" counter={{ value: caption.length, max: 400 }}>
          <Textarea id="ex-cap" rows={3} defaultValue={caption} />
          <div className="sc-hashtags">{tags}</div>
        </Field>
        <div className="sc-cell">
          <Button size="lg" icon={<CopyIcon />} style={{ flex: 1 }}>캡션 복사</Button>
          <Button variant="primary" size="lg" icon={<DownloadIcon />} style={{ flex: 1 }}>ZIP 내려받기</Button>
        </div>
      </Dialog>
    </div>
  );
}

export function EditorExport() {
  const states: ThumbState[] = [...Array<ThumbState>(7).fill("image"), "flat"];
  return (
    <EditorShell
      rows={storyRows(states, 7)}
      strip={
        <ActionStrip
          status={<><CheckIcon size={15} />8장 모두 완성</>}
          actions={<><Button icon={<PlusIcon />}>슬라이드 추가</Button><Button variant="primary" size="lg" icon={<SparkleIcon />} disabled>남은 슬라이드 없음</Button></>}
        />
      }
      panel={canvas({ index: 8, template: "CTA", options: [["위치", "가운데"], ["어둡게", "60%"]], hint: "CTA는 기본이 단색 배경입니다 · 배경을 넣으려면 다시 생성을 누르세요" })}
      exportPrimary
      overlay={<ExportDialog />}
    />
  );
}
