import type { ReactNode } from "react";

import { Avatar, BriefBar, Button, Pill, ProjectHeader, Tag, TopBar } from "@/index";
import { CheckIcon, DownloadIcon, FilmIcon, PaletteIcon, SparkleIcon, TextIcon, UserIcon } from "@/index";

import { TOPIC } from "../data";

export function AppBar({ active = "projects" }: { active?: string }) {
  return (
    <TopBar
      brand="OpenHiggsfield"
      brandLabel="OpenHiggsfield 홈"
      brandHref="#screens/projects"
      nav={{
        items: [{ id: "studio", label: "Studio" }, { id: "projects", label: "Projects" }],
        value: active,
        onChange: () => {},
        "aria-label": "구역",
      }}
      credits={1240}
      creditsUnit="크레딧"
      topUp={<Button variant="ghost" size="sm">충전</Button>}
      avatar={<Avatar initials="BK" size={32} aria-label="계정 메뉴" />}
    />
  );
}

export function Screen({ width, height, children }: { width: number; height: number; children: ReactNode }) {
  return (
    <div className="sc-screen" style={{ width, height }}>
      {children}
    </div>
  );
}

export function EditorShell({
  rows,
  strip,
  panel,
  exportPrimary = false,
  styleOpen = false,
  overlay,
}: {
  rows: ReactNode;
  strip: ReactNode;
  panel: ReactNode;
  exportPrimary?: boolean;
  styleOpen?: boolean;
  overlay?: ReactNode;
}) {
  return (
    <Screen width={1440} height={960}>
      <AppBar />
      <ProjectHeader
        back={{ href: "#screens/projects", label: "프로젝트 목록으로" }}
        title={TOPIC}
        tags={
          <>
            <Tag>카드뉴스</Tag>
            <Tag>4:5 · 1080×1350</Tag>
          </>
        }
        status={
          <>
            <CheckIcon size={13} />
            저장됨
          </>
        }
        actions={
          <>
            <Button icon={<PaletteIcon />} aria-expanded={styleOpen}>
              스타일
            </Button>
            <Button variant={exportPrimary ? "primary" : "secondary"} icon={<DownloadIcon />}>
              내보내기
            </Button>
          </>
        }
      />
      <div className="sc-editor">
        <div className="sc-editor-left">
          <div className="sc-editor-brief">
            <BriefBar
              label="주제"
              topic={TOPIC}
              pills={
                <>
                  <Pill glyph={<FilmIcon />} label="장수" value="8" />
                  <Pill glyph={<TextIcon />} label="톤" value="친근하게" />
                  <Pill glyph={<UserIcon />} label="대상" value="20대 직장인" />
                </>
              }
              action={<Button icon={<SparkleIcon />}>구성안 다시 뽑기 · 1 크레딧</Button>}
            />
          </div>
          <div className="sc-editor-rows">{rows}</div>
          {strip}
        </div>
        {panel}
      </div>
      {overlay}
    </Screen>
  );
}
