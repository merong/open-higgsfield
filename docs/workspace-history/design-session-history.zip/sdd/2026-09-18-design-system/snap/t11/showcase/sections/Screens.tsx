export function Screens() {
  return <h1 className="sc-h1">화면</h1>;
}
