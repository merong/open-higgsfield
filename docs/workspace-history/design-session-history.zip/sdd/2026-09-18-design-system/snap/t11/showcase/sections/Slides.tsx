import { useState } from "react";

import { SLIDE_PRESETS, Segment, Switch, type SlideRatio } from "@/index";

import { DECK } from "../data";
import { renderSlide } from "../lib/slide";

const RATIOS: SlideRatio[] = ["4:5", "3:4", "1:1", "9:16"];
const DIMS = ["0", "40", "75"] as const;
/* One slide per template: cover, body, list, quote, cta. */
const SAMPLES = [0, 1, 2, 3, 7];

export function Slides() {
  const [ratio, setRatio] = useState<SlideRatio>("4:5");
  const [dim, setDim] = useState<(typeof DIMS)[number]>("40");
  const [photo, setPhoto] = useState(true);
  return (
    <>
      <h1 className="sc-h1">슬라이드</h1>
      <p className="sc-lead">템플릿 5 × 프리셋 4. 글자는 cqw로 잰다. 앱 토큰을 쓰지 않는다.</p>
      <div className="sc-toolbar">
        <Segment size="sm" plate items={RATIOS.map((r) => ({ id: r, label: r }))} value={ratio} onChange={(v) => setRatio(v as SlideRatio)} aria-label="비율" />
        <Segment size="sm" plate items={DIMS.map((d) => ({ id: d, label: `어둡게 ${d}` }))} value={dim} onChange={(v) => setDim(v as (typeof DIMS)[number])} aria-label="어둡게" />
        <span className="sc-cell">
          <Switch checked={photo} onChange={setPhoto} aria-label="사진 위" />
          <span className="sc-muted">사진 위</span>
        </span>
      </div>
      {SAMPLES.map((i) => (
        <section key={i} className="sc-section">
          <h2 className="sc-h2">{DECK[i]!.label}</h2>
          <div className="sc-slides">
            {SLIDE_PRESETS.map((preset) => (
              <div key={preset} className="sc-slide-col">
                {renderSlide(DECK[i]!, i + 1, preset, ratio, photo, { dim: photo ? Number(dim) / 100 : undefined })}
                <span>{preset}</span>
              </div>
            ))}
          </div>
        </section>
      ))}
    </>
  );
}
