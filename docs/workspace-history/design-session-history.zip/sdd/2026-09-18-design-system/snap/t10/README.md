# @openhiggsfield/design

OpenHiggsfield 스튜디오의 디자인 시스템. React + Vite, SCSS → `ohf.css`.

- `corepack pnpm dev` — 쇼케이스
- `corepack pnpm build` — `dist/index.js`, `dist/index.d.ts`, `dist/ohf.css`
- `corepack pnpm test && corepack pnpm typecheck`

## 슬라이드

기획서는 `position`(세로 정렬)을 슬라이드 템플릿의 props로 두었지만, 세로 정렬은
`SlideFrame`의 레이아웃 책임이므로 `SlideFrame`이 `position` prop을 갖고, 템플릿은
콘텐츠만 렌더링한다.
