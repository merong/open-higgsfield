import { createRoot } from "react-dom/client";

createRoot(document.getElementById("root")!).render(<div className="ohf">OpenHiggsfield Design</div>);
