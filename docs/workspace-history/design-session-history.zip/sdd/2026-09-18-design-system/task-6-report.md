# Task 6 report — 기본 요소 1묶음 (cx, ratio, Spinner, Kbd, Tag, Button, IconButton, Chip, Pill, Segment)

## Implemented

All 10 steps of `task-6-brief.md`, verbatim except the one deviation noted below.

- `src/lib/cx.ts` + `cx.test.ts`
- `src/lib/ratio.ts` + `ratio.test.ts`
- `src/components/Spinner/{Spinner.tsx, Spinner.test.tsx, index.ts}` — no `.scss` (no new rule needed, per plan-header convention)
- `src/components/Kbd/{Kbd.tsx, Kbd.test.tsx, index.ts}` — no `.scss`
- `src/components/Tag/{Tag.tsx, Tag.scss, Tag.test.tsx, index.ts}`
- `src/components/Button/{Button.tsx, Button.scss, Button.test.tsx, index.ts}`
- `src/components/IconButton/{IconButton.tsx, IconButton.scss, IconButton.test.tsx, index.ts}`
- `src/components/Chip/{Chip.tsx, Chip.scss, Chip.test.tsx, index.ts}`
- `src/components/Pill/{Pill.tsx, Pill.scss, Pill.test.tsx, index.ts}`
- `src/components/Segment/{Segment.tsx, Segment.scss, Segment.test.tsx, index.ts}`
- `src/index.ts` — added the 8 component export lines + `cx`/`ratioBox`/`ratioToCss`, exactly as the brief's Step 10 lists.

All file contents (tsx/scss/test) are copied verbatim from the brief — no code deviations there.

## Deviation: `test/setup.ts` needed an explicit `afterEach(cleanup)`

**What:** `vitest.config.ts` does not set `test.globals: true`, so `@testing-library/react`'s
own auto-cleanup check (`typeof afterEach === "function"` against the *global* namespace)
never fires, and DOM from one `it` in a file leaks into the next `it` in the same file.

**Why it blocked me:** every brief-provided test file for this task renders more than once
per file without manually unmounting (Button.test.tsx: 6 its across one file; Chip/Pill: 3 and
2 its; Segment: 3 its). Running `Button.test.tsx` verbatim failed 4 of 6 tests with
"multiple elements found" because leftover buttons from earlier `it`s were still in
`document.body` when a later `it` called `screen.getByRole("button")`. (Task 5's
`icons.test.tsx` avoided this by calling `unmount()` itself inside its loop — that pattern
isn't available here since the brief's tests use plain `render()`.)

**Fix (smallest, in the existing shared setup file, not touched by any other task):**

```ts
import { cleanup } from "@testing-library/react";
import { afterEach } from "vitest";

import "@testing-library/jest-dom/vitest";

afterEach(() => {
  cleanup();
});
```

Added to `design/test/setup.ts` (already wired via `vitest.config.ts` `setupFiles`, so no
other config file changed). Re-ran the *entire* suite afterward — all 13 pre-existing test
files still pass (17 files / 46 passed / 1 skipped total after this task's additions), so the
fix has no observed side effect on earlier tasks' tests.

No other deviations. Both "알려진 처방" items in the brief (the `@/styles/mixins` alias
fallback and the `pathsToAliases`/relative-import fallback for `.d.ts`) were not needed —
`@use "@/styles/mixins" as m;` resolved fine in every component `.scss`, and `dist/index.d.ts`
contains no `"@/` reference.

## Tests — RED/GREEN evidence

Step 1 (`corepack pnpm test src/lib`): GREEN — 2 files, 3 tests passed on first run (helpers copied straight from the brief, no RED step specified for this step).

Step 2 (`corepack pnpm test src/components`), before implementing Spinner/Kbd/Tag: RED —
3 test files failed with `Failed to resolve import "./Spinner"` / `"./Kbd"` / `"./Tag"` (module not found), as expected ("모듈 없음").

Step 3, after implementing: GREEN — `corepack pnpm test src/components` → 3 files / 4 tests passed.

Step 4 (`corepack pnpm test src/components/Button`), before implementing: RED — `Failed to resolve import "./Button"`.

Step 5, after implementing Button.tsx/.scss: initial run showed 4 of 6 failing with
"multiple elements found" (the setup.ts cleanup issue above); after the `test/setup.ts` fix,
GREEN — 6/6 passed.

Step 6 (`corepack pnpm test src/components`), before implementing IconButton/Chip/Pill: RED —
3 new test files failed to resolve their modules; 10 pre-existing tests in the same run still passed (isolated failure, as expected).

Step 7, after implementing: GREEN — 7 files / 17 tests passed.

Step 8 (`corepack pnpm test src/components/Segment`), before implementing: RED — `Failed to resolve import "./Segment"`.

Step 9, after implementing: GREEN — 1 file / 3 tests passed.

Step 10 final full run:

```
corepack pnpm test
 Test Files  17 passed (17)
      Tests  46 passed | 1 skipped (47)
```

(The 1 skip is `test/token-rules.test.ts`'s slide-file check, correctly still skipped —
`src/slides` doesn't exist until a later task. The **component** token-rules check, which was
previously skipped for lack of `src/components`, now runs for real and passes:
`✓ components and composites use tokens through var(), never their literal values`.)

```
corepack pnpm typecheck
> tsc --noEmit
(clean, no output)
```

```
corepack pnpm build
✓ 29 modules transformed.
dist/ohf.css   61.14 kB │ gzip: 11.34 kB
dist/index.js  19.90 kB │ gzip:  4.95 kB │ map: 40.40 kB
✓ built in ~1s
dist ok
```

Brief's own extra checks:

```
grep -c "ohf-btn--primary" dist/ohf.css   → 1
grep "@/" dist/index.d.ts                  → (no matches)
grep -c "react-dom" dist/index.js          → 0
```

## Files created

- `design/src/lib/cx.ts`, `design/src/lib/cx.test.ts`
- `design/src/lib/ratio.ts`, `design/src/lib/ratio.test.ts`
- `design/src/components/Spinner/{Spinner.tsx,Spinner.test.tsx,index.ts}`
- `design/src/components/Kbd/{Kbd.tsx,Kbd.test.tsx,index.ts}`
- `design/src/components/Tag/{Tag.tsx,Tag.scss,Tag.test.tsx,index.ts}`
- `design/src/components/Button/{Button.tsx,Button.scss,Button.test.tsx,index.ts}`
- `design/src/components/IconButton/{IconButton.tsx,IconButton.scss,IconButton.test.tsx,index.ts}`
- `design/src/components/Chip/{Chip.tsx,Chip.scss,Chip.test.tsx,index.ts}`
- `design/src/components/Pill/{Pill.tsx,Pill.scss,Pill.test.tsx,index.ts}`
- `design/src/components/Segment/{Segment.tsx,Segment.scss,Segment.test.tsx,index.ts}`

## Files changed

- `design/src/index.ts` — added the export lines from Step 10.
- `design/test/setup.ts` — added `afterEach(cleanup)` (deviation, see above).

## Self-review

- **Completeness:** all 10 steps done in order; every expected RED/GREEN output was seen
  before moving on; Step 10's grep check and full test/typecheck/build all pass.
- **Quality:** no debug leftovers (no stray `console.log`, no commented-out code); every
  component's SCSS confirmed against `test/token-rules.test.ts` — no literal values matching
  a token were introduced (checked by hand against `src/styles/tokens/_maps.scss` before
  writing, and confirmed green by the now-active component check).
- **Discipline:** touched only the files the brief names, plus the one shared test-setup fix
  (reported above) required to make the brief's own test files pass under this project's
  vitest config. No earlier task's component/style files were touched. No feature or prop
  was added beyond what the brief specifies.
- **Reuse verified:** confirmed by grep before writing SCSS that `.ohf-chip`, `.ohf-ctl`
  (+ `-glyph`/`-value`), `.ohf-icon-btn`, `.ohf-tabs`/`.ohf-tab`/`.ohf-thumb`, `.ohf-kbd`,
  `.ohf-spinner` already have their full base rules in the ported studio partials
  (`_popovers.scss`, `_dock.scss`, `_tabs.scss`), so this task's SCSS for those components
  only adds new modifiers/sizes/states, per the class-reuse rule in `plan-header.md`. `.ohf-btn`
  and `.ohf-tag` are confirmed new (not present anywhere in `src/styles/studio/*.scss`), so
  their SCSS defines the full component as the brief does.
- **Testing:** every test renders and asserts through role/class/attribute, matching the
  plan-header's testing convention; no test was weakened or skipped to make it pass — the
  only change was the shared cleanup wiring, which is infrastructure, not a test relaxation.
- **Concerns:** none outstanding. The `test/setup.ts` change is a natural candidate for a
  Task 1 fix in the plan header rather than a per-task workaround, since every later task's
  component tests will hit the same leak; flagging this so the controller can decide whether
  to fold it into the shared scaffolding note instead of re-discovering it per task.

## Fix round 1 (review finding: missing `[data-state="active"]` pin on Segment's tab)

**Finding:** `src/components/Segment/Segment.scss` added the `[data-state="hover"]` pin for
`.ohf-tab` but not the paired `[data-state="active"]` pin, even though the studio base
(`src/styles/studio/_tabs.scss:66`) defines `.ohf-tab:active { transform: scale(0.97); }` and
plan-header's "상태 고정" convention is binding: every interactive component pins both `:hover`
and `:active` to their `[data-state]` equivalents. Segment's sibling components in this same
task (Chip, Pill, IconButton) all did this correctly; only Segment.scss had the gap.

**Fix:** checked `_tabs.scss` first — `.ohf-tab:active` there is unconditional (no `:not()`
qualifier, unlike the hover rule which excludes the selected tab). Added the matching
unconditional pin right after the existing hover pin in `Segment.scss`:

```scss
/* Mirrors the studio's unconditional .ohf-tab:active (_tabs.scss) — no
   :not() qualifier there, so none here either. */
.ohf-tab[data-state="active"] {
  transform: scale(0.97);
}
```

Only `src/components/Segment/Segment.scss` was touched (Task 7's now-present components were
left untouched, as instructed).

**Verification:**

```
corepack pnpm test
 Test Files  26 passed (26)
      Tests  56 passed | 1 skipped (57)
```

(file/test counts are higher than the original report because Task 7's components are now in
the tree; `test/token-rules.test.ts` and `test/parity.test.ts` — the two the controller called
out — both pass: `✓ components and composites use tokens through var(), never their literal
values`, and both parity checks green.)

```
corepack pnpm typecheck
> tsc --noEmit
(clean, no output)
```

```
corepack pnpm build
✓ 53 modules transformed.
dist/ohf.css   63.79 kB │ gzip: 11.74 kB
dist/index.js  25.41 kB │ gzip:  6.22 kB │ map: 55.21 kB
✓ built in 1.22s
dist ok
```

Confirmed the compiled rule landed in `dist/ohf.css` (minified, so the attribute-selector
quotes are stripped by the minifier — grepping for the literal `"active"` with quotes finds
nothing, which is a minifier artifact, not a bug):

```
.ohf-tab[data-state=active]{transform:scale(.97)}
```
