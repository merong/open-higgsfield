# Task 11 report — 쇼케이스: 뼈대, 토큰·컴포넌트·슬라이드 섹션

## Summary

Implemented all 7 steps of the brief. `showcase/main.tsx` now boots the real
`App`, which hash-routes between 토큰/컴포넌트/슬라이드/화면. 화면 (Screens) is the
brief's Task-12 placeholder only. All content (Korean copy, sample data,
slide/contrast helpers) was taken verbatim from the brief.

## Files created / changed

Created:
- `design/showcase/App.tsx`
- `design/showcase/showcase.scss`
- `design/showcase/data.ts`
- `design/showcase/lib/contrast.ts`
- `design/showcase/lib/slide.tsx`
- `design/showcase/sections/Tokens.tsx`
- `design/showcase/sections/Components.tsx`
- `design/showcase/sections/Slides.tsx`
- `design/showcase/sections/Screens.tsx` (Task-12 placeholder, per brief)
- `design/test/contrast.test.ts`

Modified:
- `design/showcase/main.tsx` — replaced the temporary boot with the brief's
  version (imports Pretendard + showcase.scss, renders `<App />`).
- `design/src/components/Switch/Switch.tsx` — see deviation below. This is
  the only earlier-task file touched.

## Deviations from the brief's literal text

1. **Switch now forwards native attributes (controller ruling for this
   task).** The brief's Components.tsx (as written for the planned API)
   assumes every interactive control can take `{...st(state)}`, which
   includes a `data-state` attribute, and have it land on the real DOM
   button — true for Button/Chip/Pill/IconButton/Tag/Tooltip/etc. because
   they all spread `...rest` from a `ButtonHTMLAttributes`/`HTMLAttributes`
   base onto the native element. `Switch.tsx` was the one exception: its
   `SwitchProps` was a closed, hand-written interface with no rest spread,
   so `data-state="hover"`/`"active"` had nowhere to go — the switch's own
   SCSS already has `@include m.hover`/`@include m.active` (which expand to
   `&:hover, &[data-state="hover"]` etc., set up by an earlier task), but the
   component itself dropped the attribute on the floor. This blocked the
   controller-mandated Switch hover column (see below), so I extended
   `SwitchProps` to `extends Omit<ButtonHTMLAttributes<HTMLButtonElement>,
   "onClick" | "onChange" | "type" | "aria-label" | "children">` and added
   `...rest` to the rendered `<button>` — the same pattern already used by
   every sibling control (IconButton, Chip, Tag, …). No visual or behavioural
   change for existing callers; `Switch.test.tsx` still passes unmodified.
   This is a defect-fix to an earlier task's file, done under the ground
   rule that allows it when a verified defect blocks the current task,
   reported here explicitly as instructed.

2. **Components.tsx — Switch matrix gets a `hover` column** (controller
   ruling, not in the brief's literal text). Changed
   `cols={["off", "on", "disabled"]}` to `cols={["off", "on", "hover",
   "disabled"]}`, placed between `on` and `disabled` to match the state
   ordering used everywhere else (`STATES = ["default", "hover", "active",
   "disabled"]`). Extended the local `SwitchDemo` helper to accept an
   optional `state: State` and spread `{...st(state)}` onto `<Switch>`
   (previously it only took a plain `disabled?: boolean`) — the same `st(...)`
   helper the brief already defines and uses for every other matrix. The
   `on` boolean for the `hover` column is `true` (same value as the `on`
   column) so the pinned state is visibly distinguishable in the rendered
   grid (checked + hover-pinned).

No other deviations: everything else (data.ts, lib/contrast.ts, lib/slide.tsx,
main.tsx, App.tsx, showcase.scss, sections/Tokens.tsx, sections/Screens.tsx,
test/contrast.test.ts, and Components.tsx apart from the Switch matrix) is the
brief's code verbatim. All component/composite calls in Components.tsx and
Slides.tsx were checked one by one against the real implementations in
`src/components/*` and `src/slides/*` before writing — every prop name,
type, and export used by the brief (Button, Chip, Pill, Segment, Stepper,
Slider, OptionList, Field/Input/Textarea, Avatar, CreditBadge, Kbd, Spinner,
Skeleton, Thumb, Popover/Menu/MenuRow, Dialog, Alert, UndoBar, Tooltip,
SlideFrame/CoverSlide/BodySlide/ListSlide/QuoteSlide/CtaSlide, SLIDE_PRESETS,
SlideRatio/SlidePreset/SlidePosition, ThumbState, tokens/Token) matched the
implemented API exactly, so no other call-site adaptation was needed. (This
task's Screens.tsx is only a placeholder, so the FormatCard/StyleCard
`name: ReactNode` mismatch flagged as context for this task does not surface
here — it belongs to Task 12.)

## Tests

RED (Step 1, before `showcase/lib/contrast.ts` existed):
```
$ corepack pnpm test test/contrast.test.ts
 FAIL  test/contrast.test.ts [ test/contrast.test.ts ]
Error: Failed to resolve import "../showcase/lib/contrast" from "test/contrast.test.ts". Does the file exist?
 Test Files  1 failed (1)
```

GREEN (after writing `contrast.ts`):
```
$ corepack pnpm test test/contrast.test.ts
 Test Files  1 passed (1)
      Tests  2 passed (2)
```

Full suite after all steps:
```
$ corepack pnpm test
 Test Files  44 passed (44)
      Tests  88 passed (88)
```

Typecheck (one fix cycle: first attempt at the Switch extension hit
`TS2430` because `ButtonHTMLAttributes` also carries a DOM `onChange` that
collided with the component's own `onChange: (next: boolean) => void`; added
`"onChange"` to the `Omit` list and it cleared):
```
$ corepack pnpm typecheck
tsc --noEmit
(no output — clean)
```

Library build:
```
$ corepack pnpm build
dist/ohf.css   78.22 kB │ gzip: 13.94 kB
dist/index.js  45.21 kB │ gzip: 10.13 kB │ map: 103.31 kB
dist ok
```

Showcase build:
```
$ corepack pnpm build:showcase
dist-showcase/index.html                                    0.92 kB
dist-showcase/assets/PretendardVariable-CJuje-Rk.woff2  2,057.69 kB
dist-showcase/assets/index-w1ndAq3u.css                    87.80 kB │ gzip: 15.53 kB
dist-showcase/assets/index-CaRncZxK.js                    260.25 kB │ gzip: 81.73 kB
✓ built in 695ms
```

Chained final check (`test && typecheck && build && build:showcase`) run once
more after all edits — all four green, pristine output.

## Dev-server verification

Did not start or stop the already-running dev server (PID confirmed
unchanged before/after: `vite --host 127.0.0.1 --port 5173 --strictPort`).

`curl` checks (all HTTP 200, no `Internal server error` / `[plugin:` body):
`/`, `/showcase/main.tsx`, `/showcase/App.tsx`, `/showcase/showcase.scss`,
`/showcase/sections/Components.tsx`, `/showcase/sections/Tokens.tsx`,
`/showcase/sections/Slides.tsx`, `/showcase/sections/Screens.tsx`,
`/showcase/data.ts`, `/showcase/lib/contrast.ts`, `/showcase/lib/slide.tsx`.

Browser verification (via claude-in-chrome, screenshots + console read on
each hash route):
- `#tokens` — left nav + color/radius/height/etc. sections render, swatches
  show hex/rgba values and contrast ratios (e.g. `--tx` 17.15:1, `--tx4`
  5.20:1, `--accent` 16.87:1). No console errors.
- `#components` — all matrices render; Button/Chip/Pill/IconButton hover
  columns visibly pinned to the hover color; Switch matrix shows
  `off / on / hover / disabled` (4 columns, the new `hover` column verified
  both visually and via the forwarded `data-state="hover"` attribute chain).
  No console errors.
- `#slides` — toolbar (ratio segment, dim segment, photo switch) plus 5
  template sections (표지/본문/목록/인용/CTA) × 4 presets = 20 slide cards,
  each with handle/page footer and correctly styled per preset (basic /
  editorial / impact / soft). No console errors.
- `#screens` — placeholder `<h1>화면</h1>` renders, nav highlights the
  active section correctly. No console errors.
- Nav `aria-current="page"` switches correctly across all four routes.
- Closed the tab afterward; did not touch the dev server process.

## Self-review

- Completeness: all 7 steps done, including the extra controller-mandated
  Switch hover column.
- Quality: no debug leftovers; comments added (Switch.tsx, SwitchDemo) are
  `/* … */` "why" comments per convention.
- Discipline: touched only the files the brief named, plus the one
  earlier-task file (`Switch.tsx`) whose defect blocked this task's explicit
  extra requirement — reported above.
- Testing: `contrast.test.ts` is the brief's real RED→GREEN test; the rest of
  the showcase is exercised through the full `test`/`typecheck`/`build`/
  `build:showcase` chain plus live browser rendering with console checks,
  since the showcase itself has no unit tests per the brief.

## Concerns

None. No open questions; no further adaptation was needed beyond the one
reported Switch fix.
