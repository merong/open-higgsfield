# Task 11 Review — 쇼케이스: 뼈대, 토큰·컴포넌트·슬라이드 섹션

Reviewed in one pass (diff is ~1,400 lines, manageable directly). Every added/modified
file's content was extracted from the diff and byte-diffed programmatically against the
brief's own code blocks (`task-11-brief.md`) to catch any undisclosed drift, rather than
sampled by eye.

### Spec Compliance

✅ Spec compliant. All 10 files this task's brief lists exist with the exact content
specified — `showcase/App.tsx`, `showcase/data.ts`, `showcase/lib/contrast.ts`,
`showcase/lib/slide.tsx`, `showcase/main.tsx`, `showcase/sections/Tokens.tsx`,
`showcase/sections/Slides.tsx`, `showcase/sections/Screens.tsx` (placeholder),
`showcase/showcase.scss` (614 lines), `test/contrast.test.ts` — confirmed byte-for-byte
identical to the brief's code blocks for all of these (verified programmatically, not
sampled). `showcase/sections/Components.tsx` matches the brief except for the one
controller-mandated Switch hover-column addition, and `src/components/Switch/Switch.tsx`
is the one controller-sanctioned library fix — both exactly as the report discloses, no
more and no less.

- **Step 1** (contrast helper, RED→GREEN test): `test/contrast.test.ts` and
  `showcase/lib/contrast.ts` verbatim.
- **Step 2** (data + slide helper): `showcase/data.ts` and `showcase/lib/slide.tsx`
  verbatim.
- **Step 3** (app shell + styles): `showcase/main.tsx`, `showcase/App.tsx`,
  `showcase/showcase.scss`, `showcase/sections/Screens.tsx` placeholder — all verbatim.
- **Step 4** (tokens section): `showcase/sections/Tokens.tsx` verbatim.
- **Step 5** (components section): verbatim except the Switch matrix
  (`Components.tsx:97-103,197-203`), the controller's two-part ruling — (a)
  `Switch.tsx` now forwards native attributes so `data-state` reaches the root
  `<button>`, (b) the matrix gained a `hover` column. Both correctly implemented (see
  Strengths / Minor below).
- **Step 6** (slides section): `showcase/sections/Slides.tsx` verbatim.
- **Step 7** (verification): report shows RED→GREEN for the new unit test, a full green
  suite (44 files / 88 tests), clean `tsc --noEmit`, successful `build` and
  `build:showcase`, and a documented browser pass via claude-in-chrome across all four
  hash routes with no console errors — pristine, nothing here to distrust.

Cross-cutting risk checked directly (not assumed): every identifier
`Components.tsx`/`Tokens.tsx`/`Slides.tsx` imports from `@/index` — `Menu`, `MenuRow`,
`ButtonSize`, `ButtonVariant`, `ThumbState`, `SLIDE_PRESETS`, `SlideRatio`, `SlideFrame`,
`SlideFrameProps`, `SlidePreset`, `SlidePosition`, `CoverSlide`/`BodySlide`/`ListSlide`/
`QuoteSlide`/`CtaSlide`, all 7 icons, `tokens`/`Token` — resolves through `src/index.ts`'s
wildcard re-exports to a real export (`Popover.tsx` for `Menu`/`MenuRow`,
`Button.tsx`/`Thumb.tsx` for the two type aliases, `src/slides/index.ts` →
`SlideFrame.tsx`/`styles.ts`/`templates.tsx`, `src/icons/index.tsx`). None missing.

Also checked: the Switch fix's SCSS precondition. The report claims `Switch.scss`
already had `@include m.hover`/`@include m.active` wired to
`[data-state="hover"/"active"]` from an earlier task — confirmed at
`src/components/Switch/Switch.scss:14,19` and `src/styles/_mixins.scss:6-18`
(`&:hover:not(:disabled):not([aria-disabled="true"]), &[data-state="hover"]`, same for
active). True as claimed.

No ⚠️ items — everything the brief specifies is self-contained in this diff and directly
checkable.

### Strengths

- Near-total byte-for-byte fidelity to the brief across all 12 changed files, verified
  programmatically rather than sampled; the only real deviations are exactly the two the
  report discloses (plus one small undisclosed one, see Minor #3), with no other drift
  found anywhere.
- The `Switch.tsx` library fix (`extends Omit<ButtonHTMLAttributes<HTMLButtonElement>,
  "onClick" | "onChange" | "type" | "aria-label" | "children">` + `...rest`,
  `Switch.tsx:7,15,25`) is the smallest correct fix and matches the established sibling
  pattern exactly — `IconButton.tsx:9,19,25`, `Chip.tsx:8,17,20`, and `Pill.tsx:8,18,20`
  all use the identical `Omit<ButtonHTMLAttributes...> + ...rest` shape (confirmed by
  direct comparison, not assumed). The reported TS2430
  (`ButtonHTMLAttributes.onChange` colliding with the component's own
  boolean-callback `onChange`) is a real, correctly diagnosed collision, and adding
  `"onChange"` to the `Omit` list is the right, minimal fix.
- Cross-module API surface (17+ component/type/icon imports) was checked against the
  real implementations, not assumed compatible — confirmed independently here by
  resolving `src/index.ts`'s wildcard re-export chain to each identifier's actual
  definition.
- Thorough, credible test evidence: RED→GREEN for the new unit test, a full green suite,
  clean strict-mode `tsc`, two successful builds, and an actual browser pass
  (screenshots + console reads) across all four routes.

### Issues

#### Critical (Must Fix)
None.

#### Important (Should Fix)
None.

#### Minor (Nice to Have)

1. **`src/components/Switch/Switch.tsx:15,25`** — the new `...rest` forwarding has no
   test asserting it actually reaches the DOM node (e.g.
   `render(<Switch ... data-state="hover" />)` → `toHaveAttribute("data-state",
   "hover")`); `Switch.test.tsx` is untouched. This is the exact capability the
   controller's hover-column ruling depends on, so a one-line regression test would be
   cheap insurance against a future refactor silently dropping the spread. Not flagged
   higher because no sibling component's test (`IconButton.test.tsx`, `Chip.test.tsx`,
   `Tag.test.tsx`, `Pill.test.tsx`) verifies its own `...rest` forwarding either — this
   is a pre-existing, codebase-wide gap, not a regression introduced here, and the
   behavior was independently confirmed working via the reported live browser check.

2. **`src/components/Switch/Switch.tsx:7,19-20`** — the `Omit` list excludes
   `onClick`/`onChange`/`type`/`aria-label`/`children` but not `role` or
   `aria-checked`, both hardcoded and load-bearing for the switch's accessibility
   contract (`role="switch"`, `aria-checked={checked}`, lines 19-20). Since `{...rest}`
   is spread after these on the `<button>`, a future caller passing either prop would
   silently override them with no type error. No current caller does this
   (`Components.tsx`'s `st()` only ever supplies `data-state`/`disabled`), and this
   exact category of gap (an un-Omitted prop enabling a silent override via a trailing
   `{...rest}`) was rated Minor for `StoryboardRow`'s un-Omitted `onClick` in the Task
   10 review — same reasoning applies here. Worth excluding both for symmetry with the
   other exclusions already made.

3. **`showcase/sections/Components.tsx:202`** — the Switch matrix's `disabled` column
   now renders **unchecked** (`on={c === "on" || c === "hover"}` is `false` for
   `c === "disabled"`), whereas the brief's own code rendered it **checked+disabled**
   (`on={c !== "off"}` was `true` for `"disabled"`, `task-11-brief.md:1235`). This is an
   undisclosed change to the brief's literal demo content — the report's "Deviations"
   section only mentions the `SwitchDemo` signature change (`disabled?` → `state?`) and
   the new column, not this value flip. Purely cosmetic (which fixed demo state a reader
   sees), but worth calling out since the report claims `Components.tsx` is "verbatim …
   apart from the Switch matrix" without listing this as part of that matrix's change.
   Trivial fix: `on={c !== "off"}` preserves the original checked value across
   `on`/`hover`/`disabled` alike.

### Assessment

**Task quality:** Approved

**Reasoning:** All three findings are Minor, cosmetic-or-latent rather than functional,
and none contradict a binding Global Constraint or a Part-1 requirement; the
controller-sanctioned `Switch.tsx` change is minimal, correctly diagnosed, and matches
the codebase's own established pattern exactly, and every other file is a verified
verbatim match to the brief.
