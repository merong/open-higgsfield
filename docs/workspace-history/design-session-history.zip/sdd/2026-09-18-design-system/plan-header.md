# OpenHiggsfield 디자인 시스템 구현 계획

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 기존 스튜디오 CSS를 SCSS로 옮겨 토큰화하고, 그 위에 React 컴포넌트·조립 요소·슬라이드 층·쇼케이스를 갖춘 패키지 `@openhiggsfield/design`을 래퍼 루트 `design/`에 만든다.

**Architecture:** Vite 7 라이브러리 빌드(`dist/index.js` + `dist/index.d.ts` + `dist/ohf.css`)와 쇼케이스 앱을 한 패키지가 겸한다. 스타일은 SCSS 맵 → `.ohf { --토큰 }` emit → 컴포넌트는 `var()`만 쓰는 3층이고, 기존 3,736줄 CSS는 20개 파셜로 1:1 이식한 뒤 parity 테스트(컴파일 결과 vs 원본, `var()` 치환 후 선언 단위 비교)로 어긋남 0을 유지한다. 컴포넌트는 스튜디오가 이미 그리는 클래스를 그대로 쓰고 새 변형·상태만 SCSS로 더한다.

**Tech Stack:** React 19, Vite 7, sass-embedded, TypeScript 5.9(strict, noUnusedLocals/Parameters), Vitest 5 + jsdom + Testing Library, vite-plugin-dts, pnpm 10(corepack).

**Spec:** `docs/superpowers/specs/2026-09-18-design-system-design.md` — 실행자는 기획서와 이 계획을 함께 읽는다.

## Global Constraints

- 패키지 위치는 `/Users/brian/works/agent/openhigsfield/design/`. **git 저장소 밖**이다(`open-higgsfield/`는 건드리지 않는다). 이 계획에는 커밋 단계가 없다. 이력이 필요하면 사용자 승인 뒤 `design/`에서 `git init`한다.
- 원본 스타일시트: `../open-higgsfield/src/openhiggsfield/openhiggsfield.css`(3,736줄). 원본 아이콘: `../open-higgsfield/src/openhiggsfield/icons.tsx`. 원본 `ui.tsx`, `data.ts`. 읽기만 한다.
- pnpm은 **10.33.2**(`packageManager` 필드). 이 머신의 전역 `pnpm`은 9.10이므로 모든 명령은 `corepack pnpm …`으로 실행한다. 아래에서 `pnpm`이라고 쓴 것은 전부 `corepack pnpm`을 뜻한다.
- 기존 토큰 31개(`--bg … --danger-line`)는 이름·값을 바꾸지 않는다. `--font-ui` 값은 `var(--font-ohf-inter), ui-sans-serif, system-ui, sans-serif` 그대로.
- 토큰은 `.ohf` 스코프에 선언한다(`:root` 아님). 모든 클래스는 `ohf-` 접두어. 쇼케이스 전용 클래스는 `sc-` 접두어.
- 컴포넌트 SCSS(`src/components`, `src/composites`)는 토큰 값 리터럴을 쓰지 않고 `var()`만 쓴다(반지름 4/6/8/10/14/15/24/999px, 높이 28/32/36/38/46px, 글자 크기 10.5/11.5/12.5/13/14/15/22px, 굵기 500/550/600/620, 자간 −0.005/−0.015/0.16em, 지속 0.12/0.15/0.2/0.34s, 색·그림자 값). `src/slides` SCSS는 앱 토큰을 참조하지 않고(`var(--sl-*)`만) 앱 색·그림자 값을 쓰지 않는다.
- 컴포넌트에 문구를 넣지 않는다. 모든 글자는 props. 아이콘만 있는 버튼은 `aria-label` 필수(타입으로 강제).
- 진짜 요소를 쓴다: `<button>`, `<a href>`, `<input>`+`<label>`, `<dialog>`. `aria-pressed`(토글), `aria-selected`(탭), `role="switch"`.
- `ref`는 React 19의 일반 prop. `className`과 native 속성은 그대로 전달.
- 라이브러리 코드(`src/`)는 `react-dom`을 import하지 않는다(`dist/index.js`에 react-dom 코드 없음).
- 주석은 `/* … */`로 "왜"만 적는다. 한국어 응답, 코드 식별자는 영문.
- 각 Task는 `corepack pnpm test && corepack pnpm typecheck`가 통과해야 끝난다.

## 공통 규약

**스튜디오 클래스 재사용 규칙.** 스튜디오 파셜이 이미 그리는 클래스는 컴포넌트가 그대로 쓴다: `ohf-chip`, `ohf-ctl(-glyph/-value)`, `ohf-kbd`, `ohf-spinner`, `ohf-tabs/ohf-tab/ohf-thumb`, `ohf-icon-btn(--ghost)`, `ohf-field(-row/-label/-value)`, `ohf-input`, `ohf-batch(-step/-value/-max)`, `ohf-slider`, `ohf-opts/ohf-opt(-label/-check/-ratio/-box)`, `ohf-skeleton(-label/-clock)`, `ohf-popover(--setting/--list/--picker/--menu/--assets)`, `ohf-pop-head`, `ohf-menu(-row/-ic/-label/-count)`, `ohf-dialog-panel`, `ohf-alert(-ic/-text)`, `ohf-undo(-drain/-text/-act)`, `ohf-tip(--start/--end)`. 이런 컴포넌트의 SCSS는 **새 변형·상태만** 추가한다(특히 쇼케이스가 상태를 고정하는 `[data-state="hover"]`, `[data-state="active"]`). 스튜디오에 없는 것(Button, Tag, Switch, Avatar, CreditBadge, Thumb(`ohf-frame`), 조립 요소, 슬라이드)은 컴포넌트 SCSS가 전부를 정의한다. 새 클래스 이름은 스튜디오와 겹치지 않는다(확인됨: `ohf-btn`, `ohf-tag`, `ohf-switch`, `ohf-avatar`, `ohf-credit`, `ohf-frame`, `ohf-appbar`, `ohf-phead`, `ohf-brief`, `ohf-sb-*`, `ohf-astrip`, `ohf-canvas`, `ohf-pcard`, `ohf-fcard`, `ohf-scard`, `ohf-slide*`).

**컴포넌트 폴더.** `src/components/<Name>/{<Name>.tsx, <Name>.scss, index.ts, <Name>.test.tsx}`. 추가할 규칙이 하나도 없으면 `.scss`는 만들지 않는다(Kbd, Spinner, Slider, OptionList, Skeleton, Alert, UndoBar). `index.ts`는 `export * from "./<Name>";` 한 줄.

**상태 고정.** 모든 인터랙티브 컴포넌트는 `:hover`와 `[data-state="hover"]`, `:active`와 `[data-state="active"]`를 같은 규칙으로 묶는다. 쇼케이스는 `data-state`로 상태를 고정해 보여 준다.

**테스트.** Vitest + jsdom + `@testing-library/react`. 컴포넌트 테스트는 렌더 → 역할(role) → 상태 클래스/속성 확인. SCSS는 테스트에서 컴파일하지 않는다(`css: false`).

**검증 명령.** `corepack pnpm test`(Vitest), `corepack pnpm typecheck`(tsc), `corepack pnpm build`(라이브러리 + dist 검사), `corepack pnpm build:showcase`, `corepack pnpm tokens`.

## 파일 구조

```
design/
├─ package.json  pnpm-workspace.yaml  tsconfig.json  vite.config.ts  vitest.config.ts  index.html  README.md  .gitignore
├─ scripts/
│  ├─ export-tokens.mjs (+ export-tokens.d.mts)   _emit.scss → tokens.json
│  ├─ tokenize-studio.mjs                          스튜디오 파셜 토큰화(1회, 멱등)
│  └─ check-dist.mjs                               dist 3파일 존재, react-dom 없음, d.ts에 "@/" 없음, tokens.json 복사
├─ src/
│  ├─ index.ts                공개 API
│  ├─ vite-env.d.ts
│  ├─ lib/{cx.ts, ratio.ts}
│  ├─ styles/{index.scss, _mixins.scss, tokens/_maps.scss, tokens/_emit.scss, base/_reset.scss, base/_keyframes.scss, studio/_*.scss ×19}
│  ├─ tokens/{tokens.json, index.ts, tokens.test.ts}
│  ├─ icons/{index.tsx, icons.test.tsx}
│  ├─ components/<Name>/…  (17)
│  ├─ composites/<Name>/…  (9)
│  └─ slides/{styles.ts, SlideFrame.tsx, templates.tsx, slides.scss, index.ts, slides.test.tsx}
├─ showcase/{main.tsx, App.tsx, showcase.scss, data.ts, lib/{contrast.ts, slide.tsx}, sections/{Tokens,Components,Slides,Screens}.tsx, screens/*.tsx}
└─ test/{setup.ts, package.test.ts, lib/flatten.ts, lib/flatten.test.ts, parity.test.ts, token-rules.test.ts, tokens-sync.test.ts}
```

---
