# SDD ledger — plan: docs/superpowers/plans/2026-09-18-design-system.md

Spec: docs/superpowers/specs/2026-09-18-design-system-design.md
Workspace: .superpowers/sdd/2026-09-18-design-system/ (briefs, reports, snapshots, review packages)
Started: 2026-09-19. 사용자 요청: "디자인 시스템을 웹에서 볼수 있도록 구동해주세요." (design/ 없음 → 계획 실행 후 dev 서버 구동)

## Rulings (사전)

- Ruling: 실행 방식은 Subagent-Driven — 사용자가 방식을 고르지 않고 구동을 요청했고, 8천 줄 계획은 컨트롤러 문맥에 담을 수 없다 — 틀리면 inline보다 시간·토큰이 더 든다.
- Ruling: git 없이 진행. 커밋 대신 `snap.sh <label>` 스냅샷을 BASE/HEAD로, `pkg.sh A B`의 `diff -ruN -U10`을 리뷰 패키지로 쓴다. 구현자는 커밋하지 않는다 — 계획 Global Constraints("커밋 단계 없음, git init은 승인 뒤")와 "커밋은 요청받았을 때만" 규칙 — 틀리면 Task별 이력이 없다(스냅샷은 작업 폴더에 남고, 나중에 git init 가능).
- Ruling: 사전 점검은 머리말 + Task별 Files/Interfaces + 기계적 교차 점검(아이콘 이름, 쇼케이스 import 이름)으로 한정. 계획 전문은 다시 읽지 않는다(어제 직접 쓰고 자체 검토함) — 틀리면 Task 내부 불일치는 리뷰 루프에서야 드러난다.
- Ruling: 구현자·리뷰어 모델은 sonnet 바닥. 계획의 코드는 실행해 본 적이 없어 strict tsc·Sass 오류 디버깅이 필요하다 — 틀리면 비용이 조금 더 든다.
- Ruling: Task 1이 끝나면 `corepack pnpm dev`를 백그라운드로 띄운다(기본 포트 5173, 비어 있음 확인). 이후 Task는 HMR로 반영된다 — 사용자 요청의 본뜻이 "웹에서 보기"라서.

## Pre-flight scan

| 쌍 / Task | 공유하는 것 | 확인 결과 |
| --- | --- | --- |
| T1→전부 | 명령, `@/*` 별칭, vitest `css:false`, check-dist | 일치. SCSS 안의 `@/` 별칭은 계획에 대안(상대 경로) 있음 |
| T2→T3 | `tokens/_emit.scss`를 `styles/index.scss`가 첫 `@use` | 일치 |
| T3↔T4 | 스튜디오 파셜(T3 생성, T4 스크립트가 수정), parity 테스트가 둘 다의 게이트 | 일치. T4 뒤 parity 재확인 단계 있음 |
| T3,5,6,7,8,9,10 | `src/index.ts`에 export 줄 추가 | 순차 추가, 충돌 없음. T9는 `export * from "./slides"` (4635줄) |
| T4→T6–10 | 믹스인 `m.hover/active/disabled/control-states/focus-ring/press/tabular/truncate/bp`, `m.z` | 이름 일치 |
| T5→T6,7,8,10,11,12 | 아이콘 이름 | 계획 전체의 `*Icon` 이름이 원본 30 + 신규 12 안에 모두 있음(스크립트로 확인) |
| T6→T7,8,10 | `cx`, `ratioBox`, `ratioToCss`, `SegmentProps` | 일치 |
| T8→T10 | `ThumbProps`(StoryboardRow.thumb) | 일치 |
| T2–T10→T11,12 | 쇼케이스가 `@/index`에서 가져오는 74개 이름 | 전부 라이브러리 Task에 정의 있음(스크립트로 확인) |
| T1↔T11 | `showcase/main.tsx`(T1 임시 → T11 교체) | 의도된 교체 |
| T11↔T12 | `sections/Screens.tsx`(T11 자리표시 → T12 교체) | 의도된 교체 |
| T1↔T13 | README(T1 뼈대 → T13 본문) | 의도된 교체 |
| T13 | 래퍼 CLAUDE.md, 메모리 파일 수정 | design/ 밖 파일. 컨트롤러가 직접 확인 |
| 각 Task 자체 | 테스트 ↔ 구현 | 전문 재독 안 함(위 Ruling). 리뷰 루프가 그물 |

리뷰 기준이 결함으로 볼 만한 계획상 지시: `ratioBox/ratioToCss`와 Slider/OptionList는 원본(`data.ts`, `ui.tsx`)의 의도된 복제(패키지가 앱을 import할 수 없음). token-rules의 `it.skipIf`는 폴더가 빌 때만 건너뜀 + sanity 테스트 있음.

## Progress

- Task 1: ⚠️(테스트 증거는 diff 밖) → 컨트롤러가 `pnpm test`·`typecheck` 직접 실행해 확인. dev 서버 HTTP 200 확인.
- Task 1: minor (deferred): `scripts/check-dist.mjs`의 "ohf.css 없으면 빈 파일 생성" 대안이 이후 CSS 회귀를 숨길 수 있다.
- Task 1: Ruling: 위 minor는 Task 3에 실어 보낸다 — Task 3부터 `dist/ohf.css`는 비어 있으면 안 되므로 대안을 지우고 "없거나 비면 실패"로 바꾼다 — 틀리면 check-dist 몇 줄을 되돌리면 된다.
- Task 1: complete (snapshots t0..t1, review clean). 편차: check-dist 빈 CSS 대안, onlyBuiltDependencies에 @parcel/watcher.
- dev 서버: `corepack pnpm dev --host 127.0.0.1 --port 5173 --strictPort` 백그라운드(bash id biyzjff5f). http://127.0.0.1:5173/
- Ruling: 리뷰 N과 구현 N+1을 겹쳐 돌린다(리뷰어는 정적 스냅샷 diff만 읽는다). 리뷰 지적이 나오면 수정은 N+1 구현자가 끝난 뒤에 보내고(쓰는 에이전트는 항상 하나), 수정 diff는 별도 스냅샷 쌍으로 재리뷰한다 — 사용자가 화면을 기다리는 중이라 벽시계 시간을 줄인다 — 틀리면 N의 결함 위에 N+1이 쌓여 재작업이 생긴다.
- Task 2: 구현 DONE (snapshots t1..t2). 편차: export-tokens.mjs의 root 계산을 `new URL("..", import.meta.url)` 대신 dirname 기반으로(Vitest가 URL 구문을 재작성). 리뷰 진행 중.
- Task 2: minor (deferred): `_maps.scss`의 `//` 주석이 Global Constraint의 `/* … */` 규칙과 다르다(계획서 코드 그대로, plan-mandated). SCSS의 `//`는 컴파일 결과에 새지 않는다는 장점이 있어 최종 리뷰에서 판단.
- Task 2: complete (snapshots t1..t2, review clean)
- Task 3: 구현 DONE (snapshots t2..t3). parity 불일치 0, dist/ohf.css 53,860 bytes. 편차: parity.test.ts 경로 계산을 dirname 기반으로(Task 2와 같은 Vitest 재작성 문제); check-dist 대안 제거(Ruling 반영). 리뷰 패키지는 1:1 복사본(`studio/`, `_keyframes.scss`)을 diff 본문에서 뺐다 — 리뷰어는 스냅샷에서 직접 대조.
- Task 4: 구현 DONE (snapshots t3..t4). 토큰화 16개 파셜·238곳, 2회차 변경 0(멱등), parity 0. 편차: token-rules.test.ts 경로 계산 dirname 기반.
- Task 3: ⚠️(RED→GREEN 순서는 스냅샷으로 확인 불가) → 과정 주장일 뿐 결함 아님으로 처리. 리뷰어가 파셜 연결본과 원본 137–3736줄이 diff 0임을 직접 확인.
- Task 3: minor (deferred): task-3-report.md의 `wc -l` 설명 문구가 부정확(코드 영향 없음).
- Task 3: complete (snapshots t2..t3, review clean)
- Task 5: 구현 DONE (snapshots t4..t5). 아이콘 42개, 편차 없음.
- Task 5: ⚠️(테스트 실행 로그는 diff 밖) → 다음 Task들이 같은 스위트를 매번 돌리므로 그것으로 확인.
- Task 5: minor (deferred): icons.test.tsx가 `React`를 import하지 않고 `React.JSX.Element`를 쓴다(@types/react의 UMD 전역 덕에 통과).
- Task 5: complete (snapshots t4..t5, review clean)
- Task 4: minor (deferred): `_mixins.scss:4-5`의 `//` 주석(Task 2 minor와 같은 건, plan-mandated).
- Task 4: complete (snapshots t3..t4, review clean). 리뷰어가 토큰 맵 일치·정사각 컨트롤 예외·누락 0을 전체 트리에서 스크립트로 확인.
- Task 6: 구현 DONE (snapshots t5..t6). 46 passed / 1 skipped(slides). 편차: `test/setup.ts`에 `afterEach(cleanup)` 추가(vitest globals가 꺼져 있어 RTL 자동 정리가 안 돈다). 이후 Task에 알림.
- Task 7: 구현 DONE (snapshots t6..t7). 56 passed / 1 skipped. 편차: Field.tsx `(Boolean(error) || over)`(ReactNode 좁히기 TS2345).
- Task 6: 리뷰 — Spec ✅, Important 1(plan-mandated): Segment.scss에 `.ohf-tab[data-state="active"]` 고정 없음. Minor 2.
- Task 6: Ruling: 계획의 Step 9 코드 블록보다 계획 자신의 "상태 고정" 규약(구속력 있음)이 우선 → 고친다 — 틀리면 SCSS 한 규칙을 지우면 된다.
- Task 6: minor (deferred): Button의 `href` 분기에서 `disabled`가 `aria-disabled`만 주고 클릭을 막지 않는다.
- Task 6: minor (deferred): IconButton `spin`/`data-spin` 테스트 없음(계획서 테스트 그대로).
- Task 6: fix round 1/5 보냄(impl-task-6 재개). Task 8 구현은 이 수정이 끝난 뒤에 띄운다.
- Task 6: fix round 1/5 (1 addressed, 0 open — Segment active pin; snapshots t7..t7f)
- Task 6: complete (snapshots t5..t6 + fix t7..t7f, review clean). Task 8의 BASE는 t7f.
- Task 8: 구현 DONE (snapshots t7f..t8). 66 passed / 1 skipped. 편차 없음.
- Task 7: 리뷰 — Spec ❌(상태 고정), Important 2(둘 다 plan-mandated), Minor 2. 전문: task-7-review.md
- Task 7: Ruling: Switch에 hover/active 상태를 넣는다(`m.hover`/`m.active`로 `data-state`와 쌍) — 계획의 Step 3 코드보다 "모든 컨트롤은 모든 상태를 갖춘다"(저장소 디자인 원칙)와 계획의 상태 고정 규약이 우선 — 틀리면 Switch.scss 몇 줄을 지우면 된다. Task 11 쇼케이스의 Switch 매트릭스에 hover 열을 더한다.
- Task 7: parked — OptionList/Slider에 `[data-state]` 고정 없음 — Ruling: 코드는 그대로 둔다. 실제 `:hover` 규칙은 스튜디오 파셜에 있어 상태 자체는 갖췄고, 고정 속성은 이 컴포넌트들의 API로 닿지 않는다(OptionList는 옵션 버튼을 직접 그리고, Slider thumb은 의사 요소). 닿게 하려면 기획서에 없는 옵션별 전달 props가 필요하다. 계획도 두 컴포넌트는 SCSS 없음으로 정했고 Task 11 매트릭스도 hover를 고정하지 않는다 — 틀리면 쇼케이스에서 옵션 줄·슬라이더 손잡이의 hover를 얼려 보여 줄 수 없고, 작은 SCSS 두 파일로 나중에 고칠 수 있다.
- Task 7: fix round 1은 impl-task-9가 끝난 뒤 보낸다(쓰는 에이전트는 하나).
- Task 7: minor (deferred): Field의 hint·counter가 `aria-describedby`로 컨트롤에 연결되지 않는다.
- Task 7: minor (deferred): task-7-report.md 자체 검토 문구 부정확(코드 영향 없음).
- Task 9: 구현 DONE (snapshots t8..t9). 71 passed, token-rules의 slides 규칙 활성화·통과. 편차 없음(README에 position 설명 추가는 계획 지시).
- Ruling(일반): "상태 고정" 규약은 native 속성 전달로 `data-state`를 받을 수 있는 **컴포넌트의 루트 인터랙티브 요소**에 적용한다. 컴포넌트가 안에서 직접 그리는 하위 요소(OptionList의 옵션 줄, UndoBar의 실행 버튼, Slider thumb 의사 요소)는 대상이 아니다 — 닿게 하려면 기획서에 없는 전달 props가 필요하고, 실제 `:hover/:active`는 스튜디오 파셜이 이미 그린다 — 틀리면 쇼케이스에서 그 하위 요소의 hover를 얼려 보여 줄 수 없다(작은 SCSS + prop으로 나중에 보완 가능).
- Task 8: 리뷰 — Spec ❌(상태 고정 1건, plan-mandated), Important 1, Minor 2. 전문: task-8-review.md
- Task 8: parked — UndoBar의 `.ohf-undo-act`에 `[data-state]` 고정 없음 — Ruling: 위 일반 Ruling에 따라 코드는 그대로 둔다(Task 7의 OptionList/Slider와 같은 구조).
- Task 8: minor (deferred): task-8-report.md가 "모든 색·그림자가 var()"라고 과장(Thumb.scss:70에 토큰과 겹치지 않는 rgba 리터럴 — 결함 아님).
- Task 8: minor (deferred): Popover.test.tsx가 `placement="down"`을 다루지 않는다.
- Task 8: complete (snapshots t7f..t8, 1 parked)
- Task 7: fix round 1 구현 DONE (snapshots t9..t9f, Switch.scss: hover=unchecked 트랙 `var(--line-2)`, active=knob scale 0.92). 재리뷰(haiku) 진행 중.
- 운영: 서브에이전트 창 20개가 쌓여 Task 10 구현자 spawn이 "fork failed: Device not configured"로 실패 → 일이 끝난 에이전트 16개에 shutdown 요청. 이후로는 Task가 끝날 때마다 정리한다. Task 10의 BASE는 t9f.
- Task 7: fix round 1/5 (1 addressed, 0 open — Switch hover/active; snapshots t9..t9f)
- Task 7: complete (snapshots t6..t7 + fix t9..t9f, 1 parked: OptionList/Slider 고정)
- Task 9: minor (deferred): QuoteSlide의 장식용 "“" 글리프가 JSX 리터럴(aria-hidden, plan-mandated).
- Task 9: minor (deferred): 템플릿 3곳의 `<h2 className="ohf-slide-h">` 한 줄 중복.
- Task 9: minor (deferred): slides.test.tsx가 impact/soft 프리셋을 직접 렌더해 확인하지 않는다.
- Task 9: complete (snapshots t8..t9, review clean)
- Task 10: 구현 DONE (snapshots t9f..t10). 86 passed. 편차: ProjectCard/FormatCard/StyleCard에 active 쌍 추가(상태 고정 Ruling), FormatCard/StyleCard의 Omit에 "name" 추가(TS2430: native `name?: string`과 충돌).
- Task 10: 리뷰 — Spec ❌(StoryboardRow만), Important 3(모두 StoryboardRow), Minor 2. 전문: task-10-review.md
- Task 10: Ruling: StoryboardRow의 선택을 `div onClick`에서 **진짜 `<button>`(제목) + `::after`로 줄 전체를 덮는 stretched 패턴**으로 바꾼다. 액션 칸은 버튼의 자손이 아니므로 클릭이 선택으로 번지지 않고(지적 1), 키보드로 닿는다(지적 3). `onSelect`가 없거나 `editing`이면 버튼 없이 지금처럼 div로 그린다(제목 자리에 입력 요소가 올 수 있음). 줄의 누름 상태는 `:has(.ohf-sb-select:active)`와 `[data-state="active"]`를 한 규칙으로 묶는다(지적 2). props(API)는 그대로 — 계획의 Step 코드보다 Global Constraint "진짜 요소를 쓴다"가 우선 — 틀리면 StoryboardRow 한 컴포넌트의 마크업·SCSS·테스트를 되돌리면 된다.
- Task 10: minor (deferred): StoryboardRowProps의 Omit에 "onClick"이 없다(Ruling 적용 뒤에는 줄에 자체 onClick이 없어 무해).
- Task 10: minor (deferred): 카드 3종의 `m.active { transform: scale(0.98) }` 블록 중복 → 공용 믹스인 후보.
- Task 10: ⚠️(dist 관련 주장은 스냅샷 밖) → Task 11 구현자가 같은 build를 다시 돌리므로 그것으로 확인.
- Task 10: fix round 1은 impl-task-11이 끝난 뒤 보낸다(쓰는 에이전트는 하나).
- Task 11: 구현 DONE (snapshots t10..t11). 88 passed, build·build:showcase 통과, dev 서버에서 #tokens/#components/#slides 렌더·콘솔 무오류 확인(구현자). 편차: Switch.tsx가 native 속성을 전달하도록 수정(`...rest`), Switch 매트릭스에 hover 열(Ruling).
- Task 10: fix round 1 구현 DONE (snapshots t11..t11f, StoryboardRow: 제목 `<button>` + stretched `::after`, 액션 z-index, `:has(:active)`+data-state). 91 passed. 재리뷰 진행 중. Task 12의 BASE는 t11f.
- Task 11: minor (deferred): Switch의 `...rest` 전달에 테스트 없음.
- Task 11: minor (deferred): Switch의 Omit이 `role`/`aria-checked`를 막지 않아 `{...rest}`로 덮어쓸 수 있다.
- Task 11: minor (deferred): Components.tsx:202 Switch 매트릭스의 disabled 열이 계획(checked+disabled)과 달리 unchecked로 그려진다(보고 안 된 외형 편차).
- Task 11: complete (snapshots t10..t11, review clean)
- Task 10: fix round 1/5 (3 addressed, 0 open — StoryboardRow 버블링·active 고정·키보드; snapshots t11..t11f)
- Task 10: minor (deferred): `statusAction`이 없어도 빈 `<span class="ohf-sb-status-action">`가 그려져 `.ohf-sb-side`에 gap 8px이 남는다 → 조건부 렌더로 바꾸면 된다.
- Task 10: complete (snapshots t9f..t10 + fix t11..t11f, review clean)
- Task 12: 구현 DONE (snapshots t11f..t12). 91 passed, build·build:showcase 통과, 구현자가 Chrome으로 #screens 11개 렌더·콘솔 무오류 확인. 편차: storyRows()에 `onSelect={() => {}}`(StoryboardRow 선택 버튼 렌더용).
- Ruling: Task 13의 Step 2(래퍼 CLAUDE.md)와 Step 4(메모리)는 컨트롤러가 직접 한다 — design/ 밖의 지침·메모리 파일이라 서브에이전트에 맡기지 않는다 — 틀려도 영향은 문서 두 곳.
- 사용자 지시(2026-09-19): "리뷰는 패스 해도 됩니다." → Task 12 리뷰 중단, Task 13 리뷰와 전체 최종 리뷰는 하지 않는다. deferred minor와 parked 항목은 최종 리뷰의 선별 없이 최종 보고에 그대로 싣는다.
- Task 12: complete (snapshots t11f..t12, 리뷰 생략 — 사용자 지시). 구현자 검증: 91 passed, build·build:showcase 통과, #screens 11개 브라우저 렌더·콘솔 무오류.
- Task 13 Step 2: 컨트롤러가 래퍼 CLAUDE.md의 Workspace layout 문단을 계획대로 수정(docs/superpowers 설명 + design/ 단락).
- 사용자 지시(2026-09-19): "git commit 하세요." → `design/`에서 `git init -b main` 후 첫 커밋 d5e70c5(207 files, Task 1–12 상태). 원격 없음, push 안 함. Task 13이 끝나면 README 커밋을 하나 더 한다.
- Task 12: 중단 요청 전에 리뷰가 끝나 있었다 — Spec ✅, Approved, 지적 0건(task-12-review.md). ⚠️(시각 대조·콘솔 무오류는 diff 밖)는 구현자의 브라우저 확인으로 갈음.
- Task 13: complete (리뷰 생략 — 사용자 지시). 구현자 + 컨트롤러 직접 검증: 91/91 passed(skipped 0), typecheck clean, build → dist ok(index.js 45,398 B · index.d.ts 1,484 B · ohf.css 78,651 B · tokens/tokens.json), react-dom 0건, tokens 멱등, tokenize 재실행 0. 편차: README의 컴포넌트 수 17 → 24(실측).
- 커밋: README는 design/ 저장소의 두 번째 커밋.
- 전체 최종 리뷰: 하지 않음(사용자 지시). 작업 폴더는 지우지 않는다 — 최종 리뷰를 건너뛰었으므로 원장·리뷰 파일·스냅샷이 유일한 기록이다.
