# Task 13 report — README와 최종 검증

컨트롤러 판정에 따라 **Step 1(README 완성)**과 **Step 3(최종 검증)**만 수행했다. Step 2(래퍼
CLAUDE.md)는 이미 컨트롤러가 직접 적용해 두었고(작업 중 파일 변경 알림으로 확인), Step 4(메모리
갱신)와 브리프 말미의 "자체 검토 기록" 절은 지시대로 건드리지 않았다.

## 구현 내용 — Step 1: README 완성

`design/README.md`를 브리프의 텍스트로 전체 교체하되, 팀 리드가 준 컨텍스트에 맞춰 다음을 반영했다.

1. **기존 "슬라이드" 절 보존.** Task 9에서 추가된 "기획서는 `position`을 템플릿 props로 두었지만
   `SlideFrame`이 갖는다"는 설명을 별도 절로 남기지 않고, 브리프의 "층" 절 4번(슬라이드) 문장 뒤에
   그대로 이어 붙였다 — 내용 손실 없이 브리프 구조에 접었다.
2. **컴포넌트 개수 정정(17 → 24).** 트리를 직접 세어 확인: `src/components/*`는 실제로 24개
   폴더(Alert, Avatar, Button, Chip, CreditBadge, Dialog, Field, IconButton, Input, Kbd,
   OptionList, Pill, Popover, Segment, Skeleton, Slider, Spinner, Stepper, Switch, Tag,
   Textarea, Thumb, Tooltip, UndoBar — `Menu`/`MenuRow`는 `Popover.tsx` 안에 있어 폴더로는
   늘지 않는다)이고, `src/composites/*`는 브리프 그대로 9개(일치, 수정 없음). 계획서의 "17"은
   계획 단계 견적이었고 실제 구현이 늘어난 것으로 판단해, 유지보수자에게 정확한 숫자를 전하기 위해
   고쳤다. 이 외의 수치(토큰 31+40=71, 슬라이드 템플릿 5·프리셋 4)는 실제 파일과 대조해 브리프
   그대로 정확함을 확인하고 손대지 않았다.
3. **"알려진 결정" 절에 7개 항목 추가.** 팀 리드가 준 컨텍스트 (a)~(g)를 각각 트리에서 실제로
   확인한 뒤(아래 "검증한 사실" 참고) 기존 4개 항목 뒤에 새 불릿으로 이어 붙였다. 문구는 한국어로
   새로 썼고(브리프에 대응 문장이 없었으므로), 식별자·경로는 원문 그대로 English.

그 외 절(명령, 스튜디오 클래스 ↔ 컴포넌트 표, 규칙, Next 앱에 붙이기)은 브리프 텍스트를 한 글자도
바꾸지 않고 그대로 실었다.

### 검증한 사실 (팀 리드 컨텍스트 a–g)

- (a) `test/parity.test.ts:16`, `test/token-rules.test.ts:14`, `scripts/export-tokens.mjs:14`가
  전부 `dirname(fileURLToPath(import.meta.url))` 패턴을 씀을 grep으로 확인.
- (b) `scripts/check-dist.mjs`에 `dist/ohf.css` 존재 확인 + `size === 0` 체크가 실제로 있음을
  파일 열어 확인.
- (c) `test/setup.ts`가 `afterEach(cleanup)`을 등록하고, 그 이유(globals 미설정)가 파일 자체
  주석에 적혀 있음을 확인.
- (d) `StoryboardRow.tsx`에서 `onSelect && !editing`일 때만 `<button class="ohf-sb-title
  ohf-sb-select">`가 렌더링되고 행 div에는 `onClick`이 없음을 소스에서 확인.
- (e) `Switch.tsx`/`Switch.scss`에서 `:hover`(오프 트랙 색 변화)·`:active`(놉 스케일) 규칙과
  `{...rest}`를 통한 네이티브 속성 전달을 확인.
- (f) 쇼케이스(`showcase/sections/Components.tsx`)에서 `Slider`·`OptionList`·`UndoBar`는
  `data-state` 매트릭스 열 없이 렌더링되고, `Button`류만 `data-state`로 hover/active를
  고정함을 확인 — 내부 요소는 고정 대상이 아니라는 서술과 일치.
- (g) `pnpm-workspace.yaml`의 `onlyBuiltDependencies: [esbuild, "@parcel/watcher"]`를 확인.

## Step 3: 최종 검증

```bash
cd /Users/brian/works/agent/openhigsfield/design
corepack pnpm test
```
```
 Test Files  44 passed (44)
      Tests  91 passed (91)
   Duration  6.48s
```
skipped 0, 실패 0.

```bash
corepack pnpm typecheck
```
```
> tsc --noEmit
```
(출력 없음 = 타입 오류 없음)

```bash
corepack pnpm build
```
```
✓ 103 modules transformed.
[unplugin:dts] Declaration files built in 1091ms.
dist/ohf.css   78.65 kB │ gzip: 14.04 kB
dist/index.js  45.40 kB │ gzip: 10.16 kB │ map: 104.14 kB
✓ built in 1.43s
dist ok
```

```bash
corepack pnpm build:showcase
```
```
✓ 151 modules transformed.
dist-showcase/index.html                                    0.92 kB
dist-showcase/assets/PretendardVariable-CJuje-Rk.woff2  2,057.69 kB
dist-showcase/assets/index-Cvz5UkcC.css                    88.23 kB │ gzip: 15.63 kB
dist-showcase/assets/index-CbQKdsNl.js                    295.37 kB │ gzip: 90.08 kB
✓ built in 744ms
```

**`tokens` 멱등성(git 없이 체크섬 대조):**
```bash
shasum src/tokens/tokens.json   # before: bd8831289e7f0b480fbc2114e7ac3397fd302219
corepack pnpm tokens            # wrote .../src/tokens/tokens.json
shasum src/tokens/tokens.json   # after:  bd8831289e7f0b480fbc2114e7ac3397fd302219
```
before/after 체크섬 동일 — 파일 내용 변화 없음(byte-identical) 확인.

**`tokenize-studio.mjs` 재실행:**
```bash
node scripts/tokenize-studio.mjs
```
```
tokenized 0 partials
```

**dist 파일 크기 및 react-dom 검사:**
```bash
ls -la dist/index.js dist/index.d.ts dist/ohf.css
```
```
dist/index.d.ts   1484 bytes
dist/index.js    45398 bytes
dist/ohf.css     78651 bytes
```
```bash
grep -c "react-dom" dist/index.js
```
```
0
```

`ls dist dist/tokens` — `dist/tokens/tokens.json`(1960 bytes) 존재 확인.

전 항목 브리프의 기대치와 일치: 테스트 전부 통과(skipped 0), 타입 오류 없음, `dist ok`,
`dist/tokens/tokens.json` 존재, `react-dom` 0건, `tokenized 0 partials`, tokens 멱등.

**dev 서버:** 검증 내내 `pnpm dev`는 실행하지 않았고, 이미 떠 있던 `http://127.0.0.1:5173/`
프로세스는 건드리지 않았다(위 명령 중 아무것도 dev 서버를 필요로 하지 않았다).

## 파일 변경

- `design/README.md` — 전체 교체(위 내용).

## 자체 점검

- 완전성: Step 1·3 전 항목 수행, 검증 명령 전부 실제로 실행하고 출력을 그대로 옮겼다.
- 품질: README에 디버그 잔재 없음, 코드 식별자 영문 유지, 새 불릿은 "왜/무엇" 사실 서술로
  기존 톤과 맞춤.
- 규율: `design/README.md` 외 파일은 건드리지 않았다(래퍼 `CLAUDE.md`, 메모리 파일은 스코프
  밖이라 손대지 않음 — 컨트롤러가 이미 `CLAUDE.md`는 처리함을 확인함).
- 편차: 컴포넌트 개수 "17"을 "24"로 정정(위에서 근거 설명). 브리프의 다른 숫자·문장은 전부
  검증 후 그대로 유지.
- 우려사항: 없음 — 모든 검증 명령이 브리프의 기대치와 정확히 일치했다.

---

**Status:** DONE
테스트: `test` 91/91(44 files) 통과, skipped 0 · `typecheck` 오류 없음 · `build` dist ok(ohf.css 78.65kB, index.js 45.40kB, index.d.ts 1484B) · `build:showcase` 통과 · `tokens` 멱등(체크섬 동일) · `tokenize-studio` 재실행 0 · `react-dom` 0건
편차: README의 컴포넌트 개수 "17"을 실측값 "24"로 정정(트리 확인, Menu/MenuRow는 Popover 폴더에 포함)
우려: 없음
보고서: `/Users/brian/works/agent/openhigsfield/.superpowers/sdd/2026-09-18-design-system/task-13-report.md`
