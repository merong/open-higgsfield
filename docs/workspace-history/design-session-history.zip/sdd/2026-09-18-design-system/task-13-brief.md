### Task 13: README, 래퍼 CLAUDE.md, 최종 검증

**Files:**
- Modify: `design/README.md`, `/Users/brian/works/agent/openhigsfield/CLAUDE.md`
- Modify: `/Users/brian/.claude/projects/-Users-brian-works-agent-openhigsfield/memory/design-system-package.md`(진행 상태)

- [ ] **Step 1: README 완성**

`design/README.md`(전체 교체):

```markdown
# @openhiggsfield/design

OpenHiggsfield 스튜디오의 디자인 시스템. 기존 `openhiggsfield.css`(3,736줄)를 SCSS 파셜로 옮겨 토큰화하고, 그 위에 React 컴포넌트·조립 요소·슬라이드 층을 얹었다. 기획서: `../docs/superpowers/specs/2026-09-18-design-system-design.md`.

## 명령

이 머신의 전역 pnpm은 9이므로 `corepack pnpm`을 쓴다(`packageManager: pnpm@10.33.2`).

| 명령 | 내용 |
| --- | --- |
| `corepack pnpm dev` | 쇼케이스(`#tokens`, `#components`, `#slides`, `#screens/<id>`) |
| `corepack pnpm build` | `dist/index.js`, `dist/index.d.ts`, `dist/ohf.css` + `scripts/check-dist.mjs` |
| `corepack pnpm build:showcase` | `dist-showcase/` |
| `corepack pnpm tokens` | `_emit.scss` → `src/tokens/tokens.json` |
| `corepack pnpm test` | Vitest: parity, token-rules, tokens-sync, contrast, 컴포넌트 스모크 |
| `corepack pnpm typecheck` | `tsc --noEmit` |

## 층

1. **토큰** `src/styles/tokens/_maps.scss` → `_emit.scss`가 `.ohf { --… }`로 뽑는다. 기존 31개는 값 그대로, 40개 추가(`--radius-*`, `--h-*`, `--fs-*`, `--fw-*`, `--ls-*`, `--sp-*`, `--dur-*`). `$z`, `$bp`는 SCSS 전용.
2. **스튜디오 파셜** `src/styles/base/*`, `src/styles/studio/*` — 원본 20개 섹션을 1:1로. `test/parity.test.ts`가 원본과 선언 단위로 비교한다(`var()`는 양쪽 다 치환한 뒤). 원본 경로: `../open-higgsfield/src/openhiggsfield/openhiggsfield.css`.
3. **컴포넌트** `src/components/*`(17), `src/composites/*`(9). 스튜디오가 이미 그리는 클래스는 그대로 쓰고 새 변형·상태만 SCSS로 더한다. 토큰은 `var()`로만(`test/token-rules.test.ts`).
4. **슬라이드** `src/slides/*` — `SlideFrame` + 템플릿 5 + 프리셋 4. 앱 토큰을 쓰지 않는다(`--sl-*`만). 세로 정렬 `position`은 템플릿이 아니라 `SlideFrame`이 갖는다.

## 스튜디오 클래스 ↔ 컴포넌트

| 스튜디오 | 컴포넌트 |
| --- | --- |
| `.ohf-generate` | `Button variant="primary" size="lg"` |
| `.ohf-btn-solid` / `.ohf-ctl--model` | `Button variant="model"` |
| `.ohf-ctl` | `Button variant="secondary"`(문구) · `Pill`(값) |
| `.ohf-btn-quiet` | `Button variant="ghost"` |
| `.ohf-icon-btn(--ghost)` | `IconButton` |
| `.ohf-chip` | `Chip` |
| `.ohf-tabs/.ohf-tab/.ohf-thumb` | `Segment` |
| `.ohf-field*` / `.ohf-input` | `Field` / `Input` / `Textarea` |
| `.ohf-batch*` | `Stepper` |
| `.ohf-slider` / `.ohf-opts` | `Slider` / `OptionList` |
| `.ohf-skeleton*` | `Skeleton` |
| `.ohf-popover*` / `.ohf-menu*` | `Popover` / `Menu` / `MenuRow` |
| `.ohf-dialog-panel` | `Dialog` |
| `.ohf-alert*` / `.ohf-undo*` / `.ohf-tip` / `.ohf-kbd` / `.ohf-spinner` | `Alert` / `UndoBar` / `Tooltip` / `Kbd` / `Spinner` |

## 규칙

- 라임(`--accent`)은 상태에만: 선택, 주 동작, 생성 중. 한 화면에 primary 버튼은 하나.
- 컴포넌트에 문구를 넣지 않는다. 필수/선택 표시도 `required="필수"`처럼 문구를 넘긴다.
- 상태는 `:hover`와 `[data-state="hover"]`를 항상 같이 정의한다(쇼케이스가 고정해 보여 준다).
- `src/`는 `react-dom`을 import하지 않는다.

## Next 앱에 붙이기(통합 단계, 아직 하지 않음)

1. `open-higgsfield/package.json`에 `"@openhiggsfield/design": "file:../design"`(또는 배포 뒤 버전).
2. `src/app/layout.tsx`에서 `import "@openhiggsfield/design/ohf.css"`로 바꾸고 `openhiggsfield.css` import를 뺀다. parity가 0이므로 화면은 같다.
3. Pretendard 전환: `--font-ohf-inter`를 `next/font/local`의 Pretendard 변수로 싣는다. `--font-ui` 값은 바꾸지 않는다.
4. 컴포넌트 치환은 화면 단위로, 위 표를 따라.

## 알려진 결정

- `Segment`의 선택 판은 실제 폭을 재서 움직인다(`ResizeObserver`, 없으면 건너뜀).
- `Dialog`는 `<dialog>`와 `showModal()`을 쓴다. `inline`이면 패널만 그린다(쇼케이스·미리보기).
- `Thumb`의 `flat` 상태 색은 props(`flatColor`, `flatAccent`)로 받는다. 기본값은 basic 프리셋.
- 스튜디오 파셜의 토큰화는 `scripts/tokenize-studio.mjs`가 했고 멱등이다. 간격 리터럴과 7/9/12px 보정값은 그대로다.
```

- [ ] **Step 2: 래퍼 CLAUDE.md에 한 단락**

`/Users/brian/works/agent/openhigsfield/CLAUDE.md`의 `## Workspace layout` 첫 문단에서 "`docs/` is an empty scratch folder"를 "`docs/superpowers/` holds the specs and plans (outside git on purpose)"로 바꾸고, 그 문단 바로 뒤에 추가:

```markdown
`design/` (sibling of `open-higgsfield/`, also outside git) is the design-system
package `@openhiggsfield/design`: React + Vite library (`dist/index.js`,
`dist/ohf.css`) plus a showcase. Its SCSS partials are a 1:1 port of
`openhiggsfield.css`, verified by `design/test/parity.test.ts` against the
original file — **change the studio stylesheet in one place and re-run that
test**. Commands there use `corepack pnpm` (pnpm 10). See `design/README.md`.
```

- [ ] **Step 3: 최종 검증**

Run:

```bash
cd /Users/brian/works/agent/openhigsfield/design
corepack pnpm test && corepack pnpm typecheck && corepack pnpm build && corepack pnpm build:showcase
ls dist dist/tokens && grep -c "react-dom" dist/index.js; echo "(0이어야 함)"
node scripts/tokenize-studio.mjs
```

Expected: 테스트 전부 통과(skipped 0), 타입 오류 없음, `dist ok`, `dist/tokens/tokens.json` 존재, `react-dom` 0건, `tokenized 0 partials`.

- [ ] **Step 4: 메모리 갱신**

`/Users/brian/.claude/projects/-Users-brian-works-agent-openhigsfield/memory/design-system-package.md`의 "진행 상태" 문단을 다음으로 바꾼다(날짜는 실제 완료일):

```
진행 상태(YYYY-MM-DD): 구현 완료. `design/`에서 `corepack pnpm test && corepack pnpm typecheck && corepack pnpm build`가 통과한다. 계획서: `docs/superpowers/plans/2026-09-18-design-system.md`. 다음은 Next 앱 통합(README "Next 앱에 붙이기" 절), 사용자 결정 뒤에.
```

---

## 자체 검토 기록

- 기획서 §3 구조: Task 1(설정), 2(토큰), 3(파셜), 5(아이콘), 6–8(컴포넌트), 9(슬라이드), 10(조립), 11–12(쇼케이스), `scripts/` 3개(Task 1·2·4). `test/` 5개 + `flatten` 도우미.
- 기획서 §4: 31 + 40 토큰(Task 2), 믹스인 6종 + `z()`(Task 4), 슬라이드 토큰(Task 9; `--sl-acc-ink`, `--sl-head-weight/-ls/-lh`를 더했다 — 프리셋의 굵기·자간·행간을 실을 자리), 토큰화 범위(Task 4 스크립트).
- 기획서 §5: 17 기본 요소(Task 6–8), 9 조립 요소(Task 10), 슬라이드 5 템플릿·4 프리셋(Task 9), 아이콘 30+12(Task 5). `position`은 `SlideFrame` prop(README에 기록). `Field.required/optional`은 문구(ReactNode).
- 기획서 §6: 4 섹션(Task 11–12), 화면 11장(Task 12).
- 기획서 §7: parity(Task 3), 토큰 규칙(Task 4, 슬라이드는 `--sl-*` 규칙), 토큰 동기화(Task 2), 스모크(각 컴포넌트 테스트), 타입·빌드(`check-dist.mjs`).
- 기획서 §9 확인 항목: Task 1 Step 4에 처방 포함. `sass-embedded` arm64 패키지는 존재 확인됨(1.104.1).
- 기획서와 다른 점: 토큰 수 33→31(원본 재계산, 기획서 수정함); `Skeleton`·`Kbd`·`Spinner`·`Slider`·`OptionList`·`Alert`·`UndoBar`는 SCSS 파일 없음(추가 규칙이 없다); 조립 요소·컴포넌트 클래스 중 스튜디오에 없는 것은 새 이름(`ohf-frame`, `ohf-appbar` 등, 충돌 확인함).
- 타입 일관성: `SegmentProps`(Task 6) → `TopBar.nav`, `CanvasPanel.mode`(Task 10); `ThumbProps`(Task 8) → `StoryboardRow.thumb`(Task 10); `SlideFrameProps`(Task 9) → `renderSlide`(Task 11); `ButtonVariant`/`ButtonSize`(Task 6) → 쇼케이스(Task 11). `cx`·`ratioBox`·`ratioToCss`는 공개 API에서 export(Task 6)하고 쇼케이스가 `@/index`로 쓴다.
