# Task 4 Report: 믹스인, 스튜디오 토큰화 패스, token-rules 테스트

## Summary

All six steps of `task-4-brief.md` completed as specified, with one documented deviation (an import-path fix already established as precedent in Task 3). Final gate `corepack pnpm test && corepack pnpm typecheck && corepack pnpm build` is green.

## What was implemented

### Step 1 — `src/styles/_mixins.scss` (created)

Written verbatim from the brief: `hover`/`active`/`disabled` state mixins (each pairing the real pseudo-class/attribute with the showcase's pinned `[data-state="…"]`), `control-states($hover-bg, $hover-color)`, `focus-ring`, `press`, `tabular`, `truncate`, `bp($name)` (media-query mixin over `maps.$bp`), and function `z($name)` (over `maps.$z`).

### Step 2 — `test/token-rules.test.ts` (created)

Written from the brief with one deviation (see below). First run: **1 passed, 2 skipped** — exactly as the brief predicts, since `src/components`, `src/composites`, `src/slides` don't exist yet (Tasks 6 and 9 will populate them and turn the skipped rules on).

### Step 3 — `scripts/tokenize-studio.mjs` (created)

Written verbatim from the brief: rewrites `border-radius`/`height`/`font-size`/`font-weight`/`letter-spacing`/`transition`/`animation` literals to `var(--token-*)` inside `src/styles/base/*.scss` and `src/styles/studio/*.scss`, innermost-block-only via the brace regex, with the square-control exception (equal width/height literal pair both stay literal) and the `--ctl-r: 10px` → `var(--radius-ctl)` special case.

### Step 4 — Ran the script, confirmed parity

- `node scripts/tokenize-studio.mjs` → `tokenized 16 partials` (≥ 15, as expected).
- `corepack pnpm test test/parity.test.ts` → **3 passed**, 0 mismatches. Tokenization does not change any resolved value, so parity holds untouched.
- Second run: `node scripts/tokenize-studio.mjs` → `tokenized 0 partials` (idempotent, confirmed).
- `grep -n "ctl-r" src/styles/studio/_attached.scss` → `114:  --ctl-r: var(--radius-ctl);`

**Before/after `wc -c` (bytes) per partial:**

| file | before | after |
|---|---:|---:|
| base/_keyframes.scss | 3985 | 3985 |
| base/_reset.scss | 2374 | 2410 |
| studio/_asset-picker.scss | 6502 | 6748 |
| studio/_attached.scss | 3526 | 3646 |
| studio/_composer.scss | 2635 | 2728 |
| studio/_dialogs.scss | 2122 | 2185 |
| studio/_dock.scss | 14411 | 14875 |
| studio/_empty.scss | 2524 | 2565 |
| studio/_entrance.scss | 536 | 536 |
| studio/_gallery.scss | 5089 | 5177 |
| studio/_lamp.scss | 1243 | 1299 |
| studio/_main.scss | 130 | 130 |
| studio/_picking.scss | 10562 | 10683 |
| studio/_popovers.scss | 11858 | 12324 |
| studio/_reduced-motion.scss | 735 | 735 |
| studio/_responsive.scss | 5204 | 5223 |
| studio/_shell.scss | 136 | 136 |
| studio/_tabs.scss | 1628 | 1708 |
| studio/_tooltips.scss | 2183 | 2215 |
| studio/_topbar.scss | 902 | 923 |
| studio/_viewer.scss | 10675 | 11085 |
| **total** | **88960** | **91316** |

16 files grew (byte count went up because `NNpx` → `var(--radius-xx)` etc. is longer text); `_keyframes`, `_entrance`, `_main`, `_reduced-motion`, `_shell` were unchanged (0 matching literals in those files) — consistent with "16 partials" changed out of 21 total.

**`var(--radius-|--h-|--fs-|--fw-|--ls-|--dur-` occurrence counts, before → after** (all were 0 before, since no tokenization pass had run yet):

| file | before | after |
|---|---:|---:|
| base/_reset.scss | 0 | 3 |
| base/_keyframes.scss | 0 | 0 |
| studio/_asset-picker.scss | 0 | 27 |
| studio/_attached.scss | 0 | 11 |
| studio/_composer.scss | 0 | 10 |
| studio/_dialogs.scss | 0 | 6 |
| studio/_dock.scss | 0 | 48 |
| studio/_empty.scss | 0 | 4 |
| studio/_entrance.scss | 0 | 0 |
| studio/_gallery.scss | 0 | 8 |
| studio/_lamp.scss | 0 | 6 |
| studio/_main.scss | 0 | 0 |
| studio/_picking.scss | 0 | 12 |
| studio/_popovers.scss | 0 | 47 |
| studio/_reduced-motion.scss | 0 | 0 |
| studio/_responsive.scss | 0 | 2 |
| studio/_shell.scss | 0 | 0 |
| studio/_tabs.scss | 0 | 8 |
| studio/_tooltips.scss | 0 | 3 |
| studio/_topbar.scss | 0 | 2 |
| studio/_viewer.scss | 0 | 41 |
| **total** | **0** | **238** |

### Step 5 — Mixin compile check

```
node -e 'import("sass-embedded").then(s => console.log(s.compileString(`@use "src/styles/mixins" as m; .x { @include m.control-states(var(--s3), var(--tx)); @include m.bp(sm) { gap: 0; } z-index: m.z(overlay); }`, { loadPaths: ["."] }).css))'
```

Output contained `.x:hover:not(:disabled):not([aria-disabled=true]), .x[data-state=hover] { … }`, `@media (max-width: 760px) { … }`, and `z-index: 40` — all three expected fragments present.

### Step 6 — Final gate

```
corepack pnpm test
```
```
 Test Files  6 passed (6)
      Tests  20 passed | 2 skipped (22)
```
(the 2 skips are the token-rules component/slide checks, correctly idle until Tasks 6/9 add files)

```
corepack pnpm typecheck
```
→ no output, exit clean.

```
corepack pnpm build
```
```
dist/ohf.css   56.32 kB │ gzip: 10.75 kB
dist/index.js   2.20 kB │ gzip:  0.92 kB │ map: 0.62 kB
dist ok
```

## Deviation from the brief

- **`test/token-rules.test.ts`**: the brief's literal text is `const root = fileURLToPath(new URL("..", import.meta.url));`. Per the context given at dispatch (and the precedent already recorded in `test/parity.test.ts` from Task 3), Vitest statically rewrites the `new URL(<relative>, import.meta.url)` pattern into an asset URL, which breaks `fileURLToPath`. Replaced with `dirname(dirname(fileURLToPath(import.meta.url)))` (the test lives in `test/`, so one `dirname` lands on `test/`, a second lands on the package root — the same location the brief's expression resolves to) plus an explanatory comment. No other line of the test changed. `scripts/tokenize-studio.mjs` keeps the brief's literal `new URL("..", import.meta.url)` unchanged, since it is only ever invoked directly by `node` (never imported through Vite/Vitest's transform pipeline) — consistent with the dispatch note that scripts run only by `node` directly may keep that form.

No other deviations. No files outside the brief's list were touched.

## Files created/changed

- Created: `src/styles/_mixins.scss`
- Created: `scripts/tokenize-studio.mjs`
- Created: `test/token-rules.test.ts`
- Modified (by running `tokenize-studio.mjs`, not by hand): `src/styles/base/_reset.scss`, and 15 of the 19 `src/styles/studio/_*.scss` partials (`_asset-picker`, `_attached`, `_composer`, `_dialogs`, `_dock`, `_empty`, `_gallery`, `_lamp`, `_picking`, `_popovers`, `_responsive`, `_tabs`, `_tooltips`, `_topbar`, `_viewer` — 15 studio files + `_reset.scss` = 16 total, matching the script's own count). `_entrance.scss`, `_main.scss`, `_shell.scss`, `_reduced-motion.scss`, `base/_keyframes.scss` had no matching literals and are untouched.

## Self-review

- **Completeness**: all 6 steps executed in order, every expected output matched (skip counts, tokenized-N counts, ctl-r line, parity pass, idempotent second run, mixin compile fragments, final green gate).
- **Quality**: no debug leftovers; the only comment added beyond the brief's own is the one explaining the `token-rules.test.ts` path-resolution deviation, in the same "why, not what" style as the codebase's existing precedent comment in `parity.test.ts`.
- **Discipline**: touched only the files the brief named, plus the studio/base partials the script itself rewrites (as documented under "Modify" in the brief's file list). Did not touch `src/styles/index.scss`, `tokens/_maps.scss`, `tokens/_emit.scss`, or any other task's files. Did not touch the running Vite dev server (still listening on :5173 after the session, confirmed via `lsof`).
- **Testing**: `token-rules.test.ts` genuinely exercises real behavior — it recurses `src/components`/`src/composites`/`src/slides`, parses SCSS declarations line-by-line, and checks literal token values / colors / durations against `tokens.json`; the two `skipIf`s are legitimate (those directories are empty until later tasks) rather than tests silently vacuous by mistake — verified by the "1 passed | 2 skipped" count matching the brief's explicit expectation.
- **Concerns**: none. The single deviation is minimal, well-precedented (same pattern Task 2's `export-tokens.mjs` and Task 3's `parity.test.ts` already used for the identical Vitest/Vite `new URL` rewrite issue), and does not change the test's behavior or intent — only how it locates the package root.
