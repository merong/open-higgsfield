# Task 10 report — 조립 요소 9개

## Status: DONE

## Implemented

All 9 composites, test-first, exactly as scoped by the brief:

- `TopBar` → `header.ohf-appbar`
- `ProjectHeader` → `.ohf-phead`
- `BriefBar` → `.ohf-brief`
- `StoryboardRow` → `.ohf-sb-row(--selected/--editing/--dragging)`
- `ActionStrip` → `.ohf-astrip`
- `CanvasPanel` → `aside.ohf-canvas`
- `ProjectCard` → `.ohf-pcard`
- `FormatCard` → `button.ohf-fcard[aria-pressed]`
- `StyleCard` → `button.ohf-scard[aria-pressed]`

Each got the standard `<Name>/{<Name>.tsx, <Name>.scss, index.ts, <Name>.test.tsx}` folder under `design/src/composites/`. `design/src/index.ts` now re-exports all 9 (added right after `./components/UndoBar`, before `./slides`, per the brief's block).

## Steps followed

- **Step 1 (RED):** wrote all 9 `*.test.tsx` files verbatim from the brief, ran `corepack pnpm test src/composites` → 9 files failed on `Failed to resolve import "./<Name>"` (module not found), confirming RED before any implementation existed.
- **Step 2:** TopBar, ProjectHeader, BriefBar — `.tsx`/`.scss`/`index.ts` written verbatim.
- **Step 3:** StoryboardRow, ActionStrip — verbatim. Confirmed the `ohf-pulse` keyframe StoryboardRow's `.ohf-sb-lamp` animation depends on already exists globally (`src/styles/base/_keyframes.scss:78`), so no extra import was needed.
- **Step 4:** CanvasPanel, ProjectCard — CanvasPanel verbatim; ProjectCard got the state-pinning completion (see Deviations).
- **Step 5:** FormatCard, StyleCard — same state-pinning completion, plus a strict-tsc fix (see Deviations).
- **Step 6:** added the 9 export lines to `src/index.ts`.

## Tests (GREEN)

```
corepack pnpm test src/composites
 Test Files  9 passed (9)
      Tests  15 passed (15)
```

```
corepack pnpm test
 Test Files  43 passed (43)
      Tests  86 passed (86)
```

```
corepack pnpm typecheck
(no output — clean)
```

```
corepack pnpm build
✓ 103 modules transformed.
dist/ohf.css   78.22 kB │ gzip: 13.94 kB
dist/index.js  45.20 kB │ gzip: 10.12 kB │ map: 103.07 kB
dist ok
```

```
grep -c "ohf-sb-row--selected" dist/ohf.css
1
```

Also ran (not required by this brief's "Run" line, but listed among the plan's validation commands, to be safe against regressions): `corepack pnpm build:showcase` → built clean (composites aren't wired into the showcase yet; that's out of this task's scope per the file tree, so nothing to add there). `corepack pnpm test test/token-rules.test.ts` → 3 passed, and specifically not skipped (`src/composites` is non-empty now, so the strict var()-only check actually ran against all 9 new SCSS files and found zero violations).

Left the running Vite dev server on :5173 untouched (verified still up under its original PID after my changes).

## Deviations from the brief's literal text

1. **State pinning — added `:active`/`[data-state="active"]` to ProjectCard, FormatCard, StyleCard.** Per the controller ruling relayed in the dispatch: a composite whose root is a `<button>`/`<a>` must have both hover and active written as a real-pseudo-class + pinned-attribute pair, using the `m.hover`/`m.active` mixins. The brief's SCSS for these three gave `.ohf-pcard`, `.ohf-fcard`, `.ohf-scard` a hover pair but no active half at all. I completed the pair:
   - Converted each root's manual `&:hover, &[data-state="hover"]` (FormatCard's was `&:hover:not(:disabled), &[data-state="hover"]`) to `@include m.hover { … }`, keeping the exact same declarations.
   - Added `@include m.active { transform: scale(0.98); }` — the app's established press feedback (`scale(0.96)` is what Button/Chip/Pill/IconButton use for controls; I used `0.98` since these are full-size cards, a subtler press for a larger footprint, but the same mechanism).
   - Added `transform var(--dur-base) var(--ease)` to each root's `transition` list so the press animates.
   - Added `@use "@/styles/mixins" as m;` to `FormatCard.scss` and `StyleCard.scss` (ProjectCard.scss already had it for `m.truncate`/`m.tabular`).
   - Left every other rule (including `:disabled`, `[aria-pressed="true"]`) exactly as the brief wrote it.
   - **Not touched:** `StoryboardRow`'s `.ohf-sb-row:hover` pair. Its root is a plain `<div onClick>`, not a real interactive element (no `role="button"`, no native button/anchor), so per the dispatch's own caveat ("the selectable StoryboardRow if its root is interactive") it is out of scope — left as the brief wrote it (hover only, no active).
   - `TopBar`, `ProjectHeader`, `BriefBar`, `ActionStrip`, `CanvasPanel` have non-interactive roots (`header`/`div`/`aside`); `.ohf-phead-back`'s button/anchor is an inner element the composite renders (out of scope per the same ruling), and it already carries full state coverage via `m.control-states` (unchanged from the brief).

2. **Strict-tsc fix — `FormatCard.tsx` / `StyleCard.tsx`: excluded `"name"` from the extended `ButtonHTMLAttributes` Omit.** `tsc --noEmit` failed with TS2430: `Omit<ButtonHTMLAttributes<HTMLButtonElement>, "children">` still carries the native `name?: string` attribute, which collides with this task's own `name: ReactNode` prop (form-field `name` vs. the card's display name). No fallback was listed in the brief for this. Smallest fix that keeps the brief's intent: widened the Omit to `"children" | "name"` in both files' prop interfaces. Nothing else in either file changed. Re-ran `corepack pnpm test` and `corepack pnpm typecheck` afterward — still 86/86 green and clean.

3. **Token-rules check:** scanned every literal value in the brief's 9 SCSS files against `src/styles/tokens/_maps.scss` before writing anything (radius/height/font-size/font-weight/letter-spacing/duration/color/shadow token value lists). No literal in the brief's text matches any token's exact value (e.g. `12px` radius, `13.5px`/`12px`/`11px` font sizes, `56px`/`90px`/`60px`/`34px` heights, `-0.01em` letter-spacing, `2.4s` animation duration all fall outside the token value sets), so nothing needed swapping to `var()`. Confirmed by running `test/token-rules.test.ts` directly after implementation — 3/3 passed, not skipped.

## Files created

```
design/src/composites/TopBar/{TopBar.tsx, TopBar.scss, index.ts, TopBar.test.tsx}
design/src/composites/ProjectHeader/{ProjectHeader.tsx, ProjectHeader.scss, index.ts, ProjectHeader.test.tsx}
design/src/composites/BriefBar/{BriefBar.tsx, BriefBar.scss, index.ts, BriefBar.test.tsx}
design/src/composites/StoryboardRow/{StoryboardRow.tsx, StoryboardRow.scss, index.ts, StoryboardRow.test.tsx}
design/src/composites/ActionStrip/{ActionStrip.tsx, ActionStrip.scss, index.ts, ActionStrip.test.tsx}
design/src/composites/CanvasPanel/{CanvasPanel.tsx, CanvasPanel.scss, index.ts, CanvasPanel.test.tsx}
design/src/composites/ProjectCard/{ProjectCard.tsx, ProjectCard.scss, index.ts, ProjectCard.test.tsx}
design/src/composites/FormatCard/{FormatCard.tsx, FormatCard.scss, index.ts, FormatCard.test.tsx}
design/src/composites/StyleCard/{StyleCard.tsx, StyleCard.scss, index.ts, StyleCard.test.tsx}
```

## Files modified

```
design/src/index.ts   — added 9 `export * from "./composites/<Name>"` lines
```

## Self-review

- **Completeness:** all 9 composites, all 4 files each, all 6 steps done; every expected test/typecheck/build output matched.
- **Quality:** no debug leftovers; identifiers and comments in English; comments explain why (e.g. the pinning deviations, the `name` collision, the stage/slide framing note already in the brief) not what.
- **Discipline:** touched only the files the brief named, plus `src/index.ts` export lines as instructed. Did not touch any Task 1–9 file. Did not add UI copy inside any composite — every string is a prop, confirmed by re-reading each `.tsx`.
- **Testing:** all 9 test files are the brief's own test-first specs; ran them RED before implementation existed, GREEN after. Full suite (86 tests) and typecheck are clean, `dist ok`.
- **Concerns:** none blocking. The two deviations above are both mechanical (completing an already-specified convention, and a narrow type collision fix) — no redesign, no scope growth.

## Fix round 1 — StoryboardRow (per controller ruling in task-10-review.md)

Addressed the review's 3 Important findings, all scoped to `src/composites/StoryboardRow/*` per the dispatch's controller ruling. Touched no other file.

**What changed:**

- `StoryboardRow.tsx`:
  - Removed `onClick={onSelect}` from the root `<div>`. The root keeps `aria-current` and `{...rest}` only.
  - When `onSelect` is provided and `editing` is false, the title now renders as `<button type="button" className="ohf-sb-title ohf-sb-select" onClick={onSelect}>{title}</button>`; otherwise it stays the original `<div className="ohf-sb-title">{title}</div>` (so an editing input slot never ends up nested inside a button).
  - Wrapped `{statusAction}` in `<span className="ohf-sb-status-action">…</span>` (previously rendered bare), mirroring the existing unconditional `.ohf-sb-actions` wrapper.
- `StoryboardRow.scss`:
  - `.ohf-sb-row` gets `position: relative` (the positioning context for the stretched hit area) and a new pressed pair `&:has(.ohf-sb-select:active), &[data-state="active"] { background: var(--s1); }` (fills the state-pinning gap flagged in finding #2 — tokens only, no literals).
  - New `.ohf-sb-select` rule: `display: block; width: 100%; text-align: left;` (the `.ohf` reset already zeroes a `<button>`'s font/border/background/padding/cursor, so nothing else needed duplicating) plus its `::after { content: ""; position: absolute; inset: 0; }` — no `position` on `.ohf-sb-select` itself, so the pseudo-element's `inset: 0` resolves against `.ohf-sb-row`'s box, stretching the click/keyboard target across the whole row rather than just the label. Focus ring moved from the button itself to that stretched area: `&:focus-visible { outline: none; }` / `&:focus-visible::after { outline: 2px solid var(--accent-32); outline-offset: -2px; }`.
  - `.ohf-sb-status-action` and `.ohf-sb-actions` both get `position: relative; z-index: 1;`, lifting them above the select button's `z-index: auto` overlay so their own clicks land on their own handlers instead of bubbling into row selection (fixes finding #1 — verified the mechanism actually compiled: `grep -o` against `dist/ohf.css` shows `.ohf-sb-select:after{content:"";position:absolute;inset:0}`, `.ohf-sb-row:has(.ohf-sb-select:active)…`, and `.ohf-sb-status-action{position:relative;z-index:1}` all present as expected).
- `StoryboardRow.test.tsx`: replaced the one test that asserted `fireEvent.click(row)` calls `onSelect` (the assertion the review named as unable to catch the bug) with:
  - `"selects through a real button, reachable by keyboard"` — `getByRole("button", { name: base.title })` exists, has class `ohf-sb-select`, and clicking it calls `onSelect` once (covers finding #3).
  - `"does not select when a nested action is clicked"` — clicking a button passed via `actions` does not call `onSelect` (covers finding #1).
  - `"renders no select button without onSelect, or while editing"` — covers the controller's case (c).
  - Kept the original `"lays out number, thumb, text, prompt and actions"` test (dropped the now-invalid `onSelect`/row-click lines, added an assertion that the `actions` button itself renders) and the unchanged `"marks selected, editing and dragging"` (aria-current), status/danger, and counter-over tests verbatim.

**RED → GREEN evidence:** temporarily restored the pre-fix `StoryboardRow.tsx` (root `onClick={onSelect}`, no select button) with the new test file in place and ran `corepack pnpm test src/composites/StoryboardRow`:

```
FAIL … "selects through a real button, reachable by keyboard"
  → getByRole("button", { name: base.title }) found nothing (no button existed)
FAIL … "does not select when a nested action is clicked"
  → onSelect called 1 time (bubbled from the "복제" action button) — expected not called
 Test Files  1 failed (1)
      Tests  2 failed | 5 passed (7)
```
This is exactly findings #1 and #3 reproduced by the new tests, unreachable by the old test suite as the review noted. Restored the fix and re-ran:

```
corepack pnpm test src/composites/StoryboardRow
 Test Files  1 passed (1)
      Tests  7 passed (7)
```

**Full verification after the fix:**

```
corepack pnpm test
 Test Files  44 passed (44)
      Tests  91 passed (91)

corepack pnpm typecheck
(no output — clean)

corepack pnpm build
✓ 103 modules transformed.
dist/ohf.css   78.65 kB │ gzip: 14.04 kB
dist/index.js  45.40 kB │ gzip: 10.16 kB │ map: 104.14 kB
dist ok

corepack pnpm test test/token-rules.test.ts
 Test Files  1 passed (1)
      Tests  3 passed (3)
```

**Scope note:** finding #2's ruling (whether `StoryboardRow`'s root is "in scope" for the active-pin convention) was resolved in my favor by the dispatch — the pinning ruling applies to the root regardless of tag identity, so I implemented it via `:has()` against the button rather than reclassifying the row as a `<button>`/`<a>` itself (the row still nests other interactive elements, so it cannot itself be a native button). The two Minor findings from the review (excluding `"onClick"` from the `Omit`, and de-duplicating the repeated `m.active` block across the three cards) were **not** touched — the dispatch scoped this round to the three Important findings only, and touching only `src/composites/StoryboardRow/*`.

**Left untouched:** the Task 11 changes the dispatch flagged (`showcase/`, `src/components/Switch/Switch.tsx`) — not read or touched. Vite dev server on :5173 confirmed still running under its original PID after this round.
