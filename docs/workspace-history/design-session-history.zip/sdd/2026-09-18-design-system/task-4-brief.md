### Task 4: 믹스인, 스튜디오 토큰화 패스, token-rules 테스트

**Files:**
- Create: `design/src/styles/_mixins.scss`, `design/scripts/tokenize-studio.mjs`
- Modify: `design/src/styles/base/_reset.scss`, `design/src/styles/studio/_*.scss`(스크립트가 고침)
- Test: `design/test/token-rules.test.ts`

**Interfaces:**
- Produces: 믹스인 `m.hover`, `m.active`, `m.disabled`, `m.control-states($hover-bg, $hover-color)`, `m.focus-ring`, `m.press`, `m.tabular`, `m.truncate`, `m.bp($name)`, 함수 `m.z($name)`. 컴포넌트 SCSS는 `@use "@/styles/mixins" as m;`로 쓴다.

- [ ] **Step 1: 믹스인 작성**

`design/src/styles/_mixins.scss`:

```scss
@use "sass:map";
@use "tokens/maps";

// The showcase pins a state with data-state, so every state rule is written
// for the real pseudo-class and for the pinned attribute at once.
@mixin hover {
  &:hover:not(:disabled):not([aria-disabled="true"]),
  &[data-state="hover"] {
    @content;
  }
}

@mixin active {
  &:active:not(:disabled):not([aria-disabled="true"]),
  &[data-state="active"] {
    @content;
  }
}

@mixin disabled {
  &:disabled,
  &[aria-disabled="true"],
  &[data-state="disabled"] {
    @content;
  }
}

@mixin control-states($hover-bg, $hover-color) {
  transition:
    background var(--dur-base) ease,
    border-color var(--dur-base) ease,
    color var(--dur-base) ease,
    transform var(--dur-base) var(--ease);
  @include hover {
    background: $hover-bg;
    color: $hover-color;
  }
  @include active {
    transform: scale(0.96);
  }
  @include disabled {
    color: var(--tx-off);
    cursor: default;
    transform: none;
  }
}

@mixin focus-ring {
  &:focus-visible {
    outline: 2px solid var(--accent-32);
    outline-offset: 2px;
  }
}

@mixin press {
  transition: transform var(--dur-base) var(--ease);
  &:active {
    transform: scale(0.96);
  }
}

@mixin tabular {
  font-variant-numeric: tabular-nums;
}

@mixin truncate {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

@mixin bp($name) {
  @media (max-width: map.get(maps.$bp, $name)) {
    @content;
  }
}

@function z($name) {
  @return map.get(maps.$z, $name);
}
```

- [ ] **Step 2: 실패하는 token-rules 테스트 작성**

`design/test/token-rules.test.ts`:

```ts
import { readdirSync, readFileSync, statSync } from "node:fs";
import { join, relative } from "node:path";
import { fileURLToPath } from "node:url";

import { describe, expect, it } from "vitest";

import tokens from "../src/tokens/tokens.json";

const root = fileURLToPath(new URL("..", import.meta.url));
const norm = (s: string) => s.replace(/\s+/g, " ").trim().toLowerCase();

function scssFiles(dir: string): string[] {
  const abs = join(root, dir);
  try {
    statSync(abs);
  } catch {
    return [];
  }
  return readdirSync(abs).flatMap((name) => {
    const path = join(abs, name);
    return statSync(path).isDirectory() ? scssFiles(join(dir, name)) : path.endsWith(".scss") ? [path] : [];
  });
}

const byPrefix = (prefix: string) =>
  Object.entries(tokens)
    .filter(([k]) => k.startsWith(prefix))
    .map(([, v]) => norm(v));

const RULES: Record<string, string[]> = {
  "border-radius": byPrefix("radius-"),
  height: byPrefix("h-"),
  "font-size": byPrefix("fs-"),
  "font-weight": byPrefix("fw-"),
  "letter-spacing": byPrefix("ls-"),
};
const DURATIONS = byPrefix("dur-");
const NON_COLOR = /^(radius|h|fs|fw|ls|sp|dur|shadow)-|^(glint|ease|ease-slide|font-ui)$/;
const COLORS = Object.entries(tokens)
  .filter(([k]) => !NON_COLOR.test(k))
  .map(([, v]) => norm(v));
const SHADOWS = [...byPrefix("shadow-"), norm(tokens.glint)];

interface Violation {
  file: string;
  line: number;
  text: string;
}

function declarations(file: string) {
  return readFileSync(file, "utf8")
    .split("\n")
    .map((text, i) => ({ text, line: i + 1, m: /^\s*([a-z-]+)\s*:\s*([^;{]+);?\s*$/.exec(text) }))
    .filter((d) => d.m && !d.text.trim().startsWith("//"))
    .map((d) => ({ line: d.line, prop: d.m![1]!, value: norm(d.m![2]!) }));
}

/* Component SCSS may only reach a token through var(); the literal value of a
   token in a property is the drift this test exists to stop. */
function strictViolations(file: string): Violation[] {
  const out: Violation[] = [];
  for (const d of declarations(file)) {
    const rel = relative(root, file);
    if (RULES[d.prop]?.includes(d.value)) out.push({ file: rel, line: d.line, text: `${d.prop}: ${d.value}` });
    if (/^(transition|animation)(-duration)?$/.test(d.prop) && DURATIONS.some((t) => new RegExp(`(^|[\\s,])${t.replace(".", "\\.")}([\\s,]|$)`).test(d.value))) {
      out.push({ file: rel, line: d.line, text: `${d.prop}: ${d.value}` });
    }
    if ([...COLORS, ...SHADOWS].some((t) => d.value.includes(t))) out.push({ file: rel, line: d.line, text: `${d.prop}: ${d.value}` });
  }
  return out;
}

/* Slides are the customer's content: they must not borrow the app palette,
   and the only custom properties they may read are their own --sl-* ones. */
function slideViolations(file: string): Violation[] {
  const out: Violation[] = [];
  const rel = relative(root, file);
  for (const d of declarations(file)) {
    if ([...COLORS, ...SHADOWS].some((t) => d.value.includes(t))) out.push({ file: rel, line: d.line, text: `${d.prop}: ${d.value}` });
    for (const m of d.value.matchAll(/var\(--([\w-]+)/g)) {
      if (!m[1]!.startsWith("sl-")) out.push({ file: rel, line: d.line, text: `var(--${m[1]}) is an app token` });
    }
  }
  return out;
}

/* Skipped, not passed, while a directory is still empty: a green run must
   never come from checking nothing. */
const strictFiles = [...scssFiles("src/components"), ...scssFiles("src/composites")];
const slideFiles = scssFiles("src/slides");

describe("token rules", () => {
  it.skipIf(strictFiles.length === 0)(
    "components and composites use tokens through var(), never their literal values",
    () => {
      expect(strictFiles.flatMap(strictViolations)).toEqual([]);
    },
  );

  it.skipIf(slideFiles.length === 0)("slides reference only --sl-* custom properties and no app colours", () => {
    expect(slideFiles.flatMap(slideViolations)).toEqual([]);
  });

  it("recognises a literal token value", () => {
    expect(RULES["border-radius"]).toContain("10px");
    expect(COLORS).toContain("#d1fe17");
    expect(DURATIONS).toContain("0.15s");
  });
});
```

Run: `corepack pnpm test test/token-rules.test.ts`
Expected: 1 passed, 2 skipped(컴포넌트·슬라이드 SCSS가 아직 없다). Task 6과 Task 9에서 파일이 생기면 규칙 검사가 실제로 돈다.

- [ ] **Step 3: 토큰화 스크립트 작성**

`design/scripts/tokenize-studio.mjs`:

```js
import { readdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { fileURLToPath } from "node:url";

/* Rewrites literals that equal a token to var(--token), property by property,
   inside the studio partials. Runs once but is idempotent: a value already
   written as var() matches nothing here. Spacing literals stay literal on
   purpose (spec 4.6), as do 7px/9px/12px concentric corrections. */
const root = fileURLToPath(new URL("..", import.meta.url));
const DIRS = ["src/styles/base", "src/styles/studio"];

const RADIUS = { "4px": "xs", "6px": "sm", "8px": "md", "10px": "ctl", "14px": "lg", "15px": "bar", "24px": "xl", "999px": "pill" };
const HEIGHT = { "28px": "xs", "32px": "sm", "36px": "md", "38px": "lg", "46px": "bar" };
const FS = { "10.5px": "2xs", "11.5px": "xs", "12.5px": "sm", "13px": "md", "14px": "base", "15px": "lg", "22px": "title" };
const FW = { 500: "medium", 550: "strong", 600: "bold", 620: "display" };
const LS = { "-0.005em": "tight", "-0.015em": "heading", "0.16em": "caps" };
const DUR = { "0.12s": "fast", "0.15s": "base", "0.2s": "slow", "0.34s": "slide" };

function tokenizeBlock(body) {
  /* A square control (width equal to its height) keeps both literals: a height
     token next to a literal width would read as two different decisions. */
  const widths = [...body.matchAll(/(?:^|\n)\s*width:\s*([\d.]+px);/g)].map((m) => m[1]);
  let out = body;
  out = out.replace(/(\n\s*)border-radius:\s*([\d.]+px);/g, (m, ws, v) => (RADIUS[v] ? `${ws}border-radius: var(--radius-${RADIUS[v]});` : m));
  out = out.replace(/(\n\s*)height:\s*([\d.]+px);/g, (m, ws, v) => (HEIGHT[v] && !widths.includes(v) ? `${ws}height: var(--h-${HEIGHT[v]});` : m));
  out = out.replace(/(\n\s*)font-size:\s*([\d.]+px);/g, (m, ws, v) => (FS[v] ? `${ws}font-size: var(--fs-${FS[v]});` : m));
  out = out.replace(/(\n\s*)font-weight:\s*(\d+);/g, (m, ws, v) => (FW[v] ? `${ws}font-weight: var(--fw-${FW[v]});` : m));
  out = out.replace(/(\n\s*)letter-spacing:\s*(-?[\d.]+em);/g, (m, ws, v) => (LS[v] ? `${ws}letter-spacing: var(--ls-${LS[v]});` : m));
  out = out.replace(/(\n\s*)(transition|animation)(:[^;]*;)/g, (m, ws, prop, rest) =>
    `${ws}${prop}${rest.replace(/(?<=\s)(0\.12s|0\.15s|0\.2s|0\.34s)(?=[\s,;])/g, (d) => `var(--dur-${DUR[d]})`)}`,
  );
  out = out.replace(/--ctl-r:\s*10px;/g, "--ctl-r: var(--radius-ctl);");
  return out;
}

function tokenize(src) {
  /* Innermost blocks only: a rule inside @media is matched by itself, and the
     @media block, which contains braces, is left alone. */
  return src.replace(/\{([^{}]*)\}/g, (m, body) => `{${tokenizeBlock(body)}}`);
}

let changed = 0;
for (const dir of DIRS) {
  for (const name of readdirSync(join(root, dir)).filter((n) => n.endsWith(".scss"))) {
    const file = join(root, dir, name);
    const before = readFileSync(file, "utf8");
    const after = tokenize(before);
    if (after !== before) {
      writeFileSync(file, after);
      changed++;
    }
  }
}
console.log(`tokenized ${changed} partials`);
```

- [ ] **Step 4: 스크립트 실행과 parity 유지 확인**

Run: `cd /Users/brian/works/agent/openhigsfield/design && node scripts/tokenize-studio.mjs`
Expected: `tokenized N partials`(N ≥ 15).

Run: `grep -c "var(--radius-\|var(--h-\|var(--fs-\|var(--fw-\|var(--ls-\|var(--dur-" src/styles/studio/*.scss src/styles/base/*.scss | tail -3 && grep -n "ctl-r" src/styles/studio/_attached.scss`
Expected: 파셜마다 치환 수가 보이고, `_attached.scss`에 `--ctl-r: var(--radius-ctl);`.

Run: `corepack pnpm test test/parity.test.ts`
Expected: PASS — 토큰화는 값을 바꾸지 않으므로 어긋남 0. 실패하면 메시지의 선언을 보고 해당 치환을 되돌린다(스크립트를 고친 뒤 파셜을 Task 3 Step 6으로 다시 만들고 재실행한다).

Run: `node scripts/tokenize-studio.mjs`
Expected: `tokenized 0 partials`(멱등).

- [ ] **Step 5: 믹스인이 컴파일되는지 확인**

Run: `cd /Users/brian/works/agent/openhigsfield/design && node -e 'import("sass-embedded").then(s => console.log(s.compileString(`@use "src/styles/mixins" as m; .x { @include m.control-states(var(--s3), var(--tx)); @include m.bp(sm) { gap: 0; } z-index: m.z(overlay); }`, { loadPaths: ["."] }).css))'`
Expected: `.x:hover:not(:disabled)…`, `@media (max-width: 760px)`, `z-index: 40`이 포함된 CSS가 출력된다.

- [ ] **Step 6: 마무리 검증**

Run: `corepack pnpm test && corepack pnpm typecheck && corepack pnpm build`
Expected: 전부 통과(token-rules 2건은 skipped), `dist ok`.

---

