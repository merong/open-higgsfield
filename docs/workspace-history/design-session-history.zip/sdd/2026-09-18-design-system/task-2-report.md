# Task 2 리포트: 토큰 맵 → emit → tokens.json

## 구현 내용

브리프 Step 1–6을 순서대로 수행했다.

1. `design/test/tokens-sync.test.ts` — 브리프 원문 그대로 작성.
2. RED 확인: `corepack pnpm test test/tokens-sync.test.ts` →
   `Failed to resolve import "../scripts/export-tokens.mjs". Does the file exist?` (예상대로 실패).
3. `design/src/styles/tokens/_maps.scss`, `design/src/styles/tokens/_emit.scss` — 브리프 원문 그대로 작성.
   - `$legacy` 31개 값을 원본 `open-higgsfield/src/openhiggsfield/openhiggsfield.css` 8–43행과 대조: **완전히 일치, 불일치 없음.**
4. `design/scripts/export-tokens.mjs`, `design/scripts/export-tokens.d.mts` 작성 (Step 4의 `root` 계산에 편차 있음, 아래 참조).
5. `corepack pnpm tokens` 실행 → `src/tokens/tokens.json` 생성, 71개 키, `head -5`에 `"bg": "#0a0a0b"` 확인. `design/src/tokens/index.ts`, `design/src/tokens/tokens.test.ts` 작성.
6. GREEN 확인 (아래 테스트 섹션).

## 브리프 원문과의 편차

**`scripts/export-tokens.mjs`의 `root` 계산 방식 변경.**

브리프 원문:
```js
const root = fileURLToPath(new URL("..", import.meta.url));
```

이 리터럴은 `node scripts/export-tokens.mjs`로 직접 실행할 때는 문제없이 동작한다 (Step 5에서 확인). 하지만 `test/tokens-sync.test.ts`가 이 스크립트를 `import`하면 Vite/Vitest의 변환 파이프라인을 거치는데, Vite는 `new URL(상대경로, import.meta.url)` 패턴을 애셋 URL 문법으로 정적 매칭해서 재작성한다 — 이 스크립트가 순수 Node 스크립트라는 것과 무관하게 텍스트 패턴만 보고 재작성한다. 그 결과 jsdom 테스트 환경에서 `new URL("..", import.meta.url)`의 `href`가 파일 경로가 아니라 `http://localhost:3000/dist/index.js` 같은 dev-server URL로 바뀌어 버리고, `fileURLToPath()`가 `TypeError: The URL must be of scheme file`로 죽는다.

디버그로 확인한 사실 (임시 디버그 파일로 재현 후 즉시 삭제):
- `import.meta.url`을 단독으로 읽으면 (두 번째 인자로 `new URL()`에 넘기지 않으면) vitest 안에서도 정상적으로 `file:///…/scripts/export-tokens.mjs`를 반환한다.
- `new URL("..", import.meta.url)`처럼 **두 인자 형태**로 호출한 경우에만 Vite가 재작성해서 깨진다.

**수정:** 브리프의 의도(모듈 파일 위치 기준 부모 디렉터리를 `root`로 삼는다)를 유지하면서, Vite가 정적 매칭하는 2-인자 `new URL(..., import.meta.url)` 패턴 자체를 피하도록 `node:path`의 `dirname`/`join`으로 바꿨다:

```js
import { dirname, join } from "node:path";
...
const root = join(dirname(fileURLToPath(import.meta.url)), "..") + "/";
```

파일 하단의 `if (process.argv[1] === fileURLToPath(import.meta.url))` (단일 인자 호출)은 이 패턴에 해당하지 않으므로 그대로 두었다. `export-tokens.d.mts`는 브리프 원문 그대로.

이 외 편차 없음. `_maps.scss`, `_emit.scss`, `tokens/index.ts`, `tokens/tokens.test.ts`, `test/tokens-sync.test.ts`는 브리프 리터럴 그대로 사용.

## 원본 대조 (legacy 31개)

`open-higgsfield/src/openhiggsfield/openhiggsfield.css` 8–43행의 `.ohf { … }` 블록과 `_maps.scss`의 `$legacy` 맵을 1:1 대조 완료. `bg`부터 `danger-line`까지 이름·값 모두 일치. **불일치 없음** — 브리프의 리터럴 값이 이미 원본과 정확히 같았다.

## 테스트

```
$ corepack pnpm test
 RUN  v5.0.1 /Users/brian/works/agent/openhigsfield/design

 Test Files  3 passed (3)
      Tests  8 passed (8)
```
(tokens-sync.test.ts 4개 + tokens/tokens.test.ts 2개 + test/package.test.ts 2개 — 브리프 Step 6 예상과 일치)

```
$ corepack pnpm typecheck
> tsc --noEmit
(오류 없음)
```

RED→GREEN 근거: Step 2에서 `test/tokens-sync.test.ts` 단독 실행 시 `Failed to resolve import "../scripts/export-tokens.mjs"`로 실패 확인. `export-tokens.mjs`/`_maps.scss`/`_emit.scss`/`tokens.json`/`tokens/index.ts` 작성 후 전체 스위트 GREEN.

`corepack pnpm tokens` 재실행 결과도 확인: `src/tokens/tokens.json`이 71개 키, 브리프가 요구하는 순서(legacy 31개 → added 40개)와 리터럴 값 그대로 생성됨 (파일 내용 리포트에 포함하지 않지만 `head -5`에 `"bg": "#0a0a0b"` 확인, 전체 키 개수 71 확인).

## 변경/생성 파일

- 생성: `design/test/tokens-sync.test.ts`
- 생성: `design/src/styles/tokens/_maps.scss`
- 생성: `design/src/styles/tokens/_emit.scss`
- 생성: `design/scripts/export-tokens.mjs` (root 계산 편차 있음, 위 참조)
- 생성: `design/scripts/export-tokens.d.mts`
- 생성(생성물): `design/src/tokens/tokens.json`
- 생성: `design/src/tokens/index.ts`
- 생성: `design/src/tokens/tokens.test.ts`

기존 파일은 건드리지 않음 (`scripts/check-dist.mjs`, `package.json`의 `tokens` 스크립트, `pnpm-workspace.yaml`의 `onlyBuiltDependencies`는 Task 1에서 이미 준비되어 있었음을 확인만 했다).

## 셀프 리뷰

- **완전성**: 브리프의 6단계 모두 수행, 모든 파일 생성, 모든 기대 출력 확인.
- **품질**: 디버그용으로 임시 생성했던 `scripts/_debug.mjs`, `test/debug-import-meta.test.ts` 파일은 원인 규명 직후 전부 삭제함 (저장소에 남아있지 않음, 재확인 완료).
- **절도(discipline)**: 브리프가 지목한 파일 외에는 손대지 않음. `root` 계산 방식 변경 외에는 리터럴 그대로.
- **테스트**: `tokens-sync.test.ts`는 실제 SCSS 컴파일 결과(`collectTokens()`)와 디스크상의 `tokens.json`을 비교하므로 실제 동작을 검증한다. `tokens.test.ts`는 `cssVar`/freeze를 검증.

## 우려 사항

없음. `root` 계산 편차는 Vite의 정적 패턴 매칭이라는 명확한 원인이 있고, 동작(값)은 브리프 의도와 완전히 동일하다.
