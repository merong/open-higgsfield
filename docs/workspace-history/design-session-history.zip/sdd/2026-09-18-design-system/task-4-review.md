# Task 4 Review: 믹스인, 스튜디오 토큰화 패스, token-rules 테스트

### Spec Compliance

✅ Spec compliant. All five deliverables from `task-4-brief.md`'s file list are present and match:
- `design/src/styles/_mixins.scss` (new) — verbatim from Step 1's code block (`hover`/`active`/`disabled`/`control-states`/`focus-ring`/`press`/`tabular`/`truncate`/`bp`/`z`), confirmed by diff (review-t3..t4.diff:83-166).
- `design/scripts/tokenize-studio.mjs` (new) — verbatim from Step 3's code block, byte-for-byte (review-t3..t4.diff:25-77).
- `design/src/styles/base/_reset.scss` + 15 of 19 `design/src/styles/studio/_*.scss` partials modified by the script only; the 4 untouched (`_entrance`, `_main`, `_shell`, `_reduced-motion`) and `base/_keyframes.scss` are absent from the diff's file list because they genuinely contain zero matching literals — confirmed by re-running the brief's own grep command against `snap/t4`.
- `design/test/token-rules.test.ts` (new) — matches the brief with one documented, legitimate deviation (below).

**Deviation check (token-rules.test.ts root resolution):** the implementer replaced `fileURLToPath(new URL("..", import.meta.url))` with `dirname(dirname(fileURLToPath(import.meta.url)))`. This is the same Vitest static-`new URL`-rewrite workaround already established in `test/parity.test.ts` (Task 3) and `scripts/export-tokens.mjs` (Task 2) — verified against those files in `snap/t4`, both use the identical `dirname(fileURLToPath(...))` pattern with the same documented cause. Resolves to an identical path (test lives in `test/`, one `dirname` → `test/`, second → package root). Not a defect.

⚠️ Nothing left unverifiable — every claim in the report was checkable directly from the diff/snapshot and I checked it.

### Strengths

- **Token map fidelity is exact.** `tokenize-studio.mjs`'s `RADIUS`/`HEIGHT`/`FS`/`FW`/`LS`/`DUR` objects match `snap/t4/src/styles/tokens/_maps.scss`'s `$radius`/`$height`/`$font-size`/`$font-weight`/`$letter-spacing`/`$duration` name-for-name and value-for-value (`_maps.scss:41-48`).
- **Square-control exemption is complete and correct, verified across the whole tree, not just sampled hunks.** Read every hunk in all 15 changed studio partials plus `base/_reset.scss` (files sampled: `_asset-picker`, `_attached`, `_composer`, `_dialogs`, `_dock`, `_empty`, `_gallery`, `_lamp`, `_picking`, `_popovers`, `_responsive`, `_tabs`, `_tooltips`, `_topbar`, `_viewer`, `base/_reset`), then wrote a small script against the full `snap/t4` tree (not just the diff) checking every `height: var(--h-*)` block for a co-located literal `width:` at the pre-conversion pixel value — 0 false positives (no square control was wrongly converted) and 0 false negatives (every leftover literal `height:` matching a token value — `.ohf-icon-btn--ghost` 28×28, `.ohf-tile-act` 36×36/32×32, `.ohf-pick` 36×36, `.ohf-attach` 38×38, `.ohf-batch-step` 28×28, `.ohf-viewer-trash/-keep` 36×36, `.ohf-fail-ic` 28×28 — is a genuine square control correctly left alone).
- **No missed conversions anywhere in border-radius/font-size/font-weight/letter-spacing** and **no un-converted matching durations in any `transition`/`animation` declaration**, confirmed the same way across all 21 base+studio files.
- **Report's own numbers are independently reproducible.** Re-running the brief's Step 4 grep against `snap/t4` reproduces the report's per-file `var(--radius-|--h-|--fs-|--fw-|--ls-|--dur-` counts exactly (dock:48, popovers:47, viewer:41, asset-picker:27, … total 238), and `_attached.scss:114` does read `--ctl-r: var(--radius-ctl);`.
- **`token-rules.test.ts`'s guard test is real**, not vacuous: `tokens.json` (Task 2 output) does contain `"radius-ctl": "10px"`, `"accent": "#d1fe17"`, `"dur-base": "0.15s"`, so the "recognises a literal token value" assertion actually exercises the `RULES`/`COLORS`/`DURATIONS` construction rather than trivially passing.

### Issues

#### Critical (Must Fix)
None.

#### Important (Should Fix)
None.

#### Minor (Nice to Have)
- `src/styles/_mixins.scss:4-5` — two `//` line comments ("The showcase pins a state with data-state…") violate plan-header.md's global constraint "주석은 `/* … */`로 "왜"만 적는다." This is copied verbatim from the brief's own Step 1 code block, not introduced independently by the implementer, and matches pre-existing precedent already in the tree from earlier tasks (`src/styles/index.scss:1-2`, `src/styles/tokens/_maps.scss:1-4,40,43,50`, both untouched by this diff). Flagging for the controller since the constraint is worded as absolute and this is now the third file carrying the same inconsistency; low practical impact (stripped at compile, no effect on `dist`).

### Assessment

**Task quality:** Approved

**Reasoning:** The mixins and tokenize script are verbatim to spec, the tokenization pass is provably complete and correct — zero missed conversions and zero incorrect square-control exemptions across the entire 21-file base+studio tree, not merely the sampled hunks — and the test file faithfully implements the brief with a well-precedented, documented workaround for a known Vitest quirk. The only issue found is a pre-existing, brief-mandated comment-style nit with no functional impact.
