### Task 2: 토큰 맵 → emit → tokens.json

**Files:**
- Create: `design/src/styles/tokens/_maps.scss`, `design/src/styles/tokens/_emit.scss`
- Create: `design/scripts/export-tokens.mjs`, `design/scripts/export-tokens.d.mts`
- Create: `design/src/tokens/tokens.json`(생성물), `design/src/tokens/index.ts`
- Test: `design/test/tokens-sync.test.ts`, `design/src/tokens/tokens.test.ts`

**Interfaces:**
- Produces: SCSS 맵 `maps.$legacy`(31개), `$radius`, `$height`, `$font-size`, `$font-weight`, `$letter-spacing`, `$space`, `$duration`, `$z`, `$bp`; `collectTokens(): Record<string, string>`; `tokens`(71개, 키는 `--` 없는 커스텀 프로퍼티 이름), `type Token`, `cssVar(name: Token): string`.

- [ ] **Step 1: 실패하는 동기화 테스트 작성**

`design/test/tokens-sync.test.ts`:

```ts
import { describe, expect, it } from "vitest";

import { collectTokens } from "../scripts/export-tokens.mjs";
import onDisk from "../src/tokens/tokens.json";

const LEGACY = [
  "bg", "rail", "s1", "s2", "s3", "s4", "line", "line-2", "tx", "tx2", "tx3", "tx4", "tx-off",
  "accent", "accent-strong", "accent-ink", "accent-08", "accent-14", "accent-32", "plate", "plate-ink",
  "shadow-1", "shadow-2", "shadow-3", "glint", "ease", "ease-slide", "font-ui", "danger", "danger-bg", "danger-line",
];
const ADDED = [
  ...["xs", "sm", "md", "ctl", "lg", "bar", "xl", "pill"].map((k) => `radius-${k}`),
  ...["xs", "sm", "md", "lg", "bar"].map((k) => `h-${k}`),
  ...["2xs", "xs", "sm", "md", "base", "lg", "title"].map((k) => `fs-${k}`),
  ...["medium", "strong", "bold", "display"].map((k) => `fw-${k}`),
  ...["tight", "heading", "caps"].map((k) => `ls-${k}`),
  ...[0, 1, 2, 3, 4, 5, 6, 7, 8].map((k) => `sp-${k}`),
  ...["fast", "base", "slow", "slide"].map((k) => `dur-${k}`),
];

describe("tokens.json", () => {
  it("is what export-tokens.mjs produces from the SCSS maps", () => {
    expect(onDisk).toEqual(collectTokens());
  });

  it("declares the 31 legacy tokens and the 40 added ones, in that order", () => {
    expect(Object.keys(onDisk)).toEqual([...LEGACY, ...ADDED]);
  });

  it("keeps the legacy values byte-for-byte", () => {
    expect(onDisk.bg).toBe("#0a0a0b");
    expect(onDisk.accent).toBe("#d1fe17");
    expect(onDisk.line).toBe("rgba(255, 255, 255, 0.06)");
    expect(onDisk["shadow-2"]).toBe("0 4px 12px rgba(0, 0, 0, 0.3), 0 16px 40px rgba(0, 0, 0, 0.35)");
    expect(onDisk["font-ui"]).toBe("var(--font-ohf-inter), ui-sans-serif, system-ui, sans-serif");
    expect(onDisk.ease).toBe("cubic-bezier(0.2, 0, 0, 1)");
  });

  it("uses the agreed values for the added tokens", () => {
    expect(onDisk["radius-ctl"]).toBe("10px");
    expect(onDisk["radius-pill"]).toBe("999px");
    expect(onDisk["h-bar"]).toBe("46px");
    expect(onDisk["fs-sm"]).toBe("12.5px");
    expect(onDisk["fw-display"]).toBe("620");
    expect(onDisk["ls-caps"]).toBe("0.16em");
    expect(onDisk["sp-8"]).toBe("32px");
    expect(onDisk["dur-slide"]).toBe("0.34s");
  });
});
```

- [ ] **Step 2: 실패 확인**

Run: `corepack pnpm test test/tokens-sync.test.ts`
Expected: FAIL — `scripts/export-tokens.mjs`를 찾지 못한다.

- [ ] **Step 3: 맵과 emit 작성**

`design/src/styles/tokens/_maps.scss`:

```scss
// Source of truth for every runtime token. `_emit.scss` turns these maps into
// custom properties on `.ohf`; `scripts/export-tokens.mjs` turns the same
// output into tokens.json. The legacy map is copied from openhiggsfield.css and
// must not change: 424 var() uses and the parity test depend on it.

$legacy: (
  bg: #0a0a0b,
  rail: #101112,
  s1: #151719,
  s2: #1a1d1f,
  s3: #222629,
  s4: #2b3033,
  line: rgba(255, 255, 255, 0.06),
  line-2: rgba(255, 255, 255, 0.11),
  tx: #edefef,
  tx2: #a8aeaf,
  tx3: #878e90,
  tx4: #7d8486,
  tx-off: #5c6365,
  accent: #d1fe17,
  accent-strong: #ddfe51,
  accent-ink: #141a02,
  accent-08: rgba(209, 254, 23, 0.08),
  accent-14: rgba(209, 254, 23, 0.14),
  accent-32: rgba(209, 254, 23, 0.32),
  plate: rgba(6, 9, 8, 0.7),
  plate-ink: rgba(246, 250, 248, 0.9),
  shadow-1: (0 1px 2px rgba(0, 0, 0, 0.4)),
  shadow-2: (0 4px 12px rgba(0, 0, 0, 0.3), 0 16px 40px rgba(0, 0, 0, 0.35)),
  shadow-3: (0 8px 24px rgba(0, 0, 0, 0.4), 0 32px 88px rgba(0, 0, 0, 0.52)),
  glint: (inset 0 1px 0 rgba(255, 255, 255, 0.045)),
  ease: cubic-bezier(0.2, 0, 0, 1),
  ease-slide: cubic-bezier(0.16, 1, 0.3, 1),
  font-ui: (var(--font-ohf-inter), ui-sans-serif, system-ui, sans-serif),
  danger: #ff8d78,
  danger-bg: rgba(255, 141, 120, 0.1),
  danger-line: rgba(255, 141, 120, 0.28),
);

// Added tokens. Values are the ones the studio already uses as literals.
$radius: (xs: 4px, sm: 6px, md: 8px, ctl: 10px, lg: 14px, bar: 15px, xl: 24px, pill: 999px);
$height: (xs: 28px, sm: 32px, md: 36px, lg: 38px, bar: 46px);
// "2xs" is quoted: unquoted, Sass would read it as the number 2 with unit xs.
$font-size: ("2xs": 10.5px, xs: 11.5px, sm: 12.5px, md: 13px, base: 14px, lg: 15px, title: 22px);
$font-weight: (medium: 500, strong: 550, bold: 600, display: 620);
$letter-spacing: (tight: -0.005em, heading: -0.015em, caps: 0.16em);
$space: (0: 2px, 1: 4px, 2: 6px, 3: 8px, 4: 12px, 5: 16px, 6: 20px, 7: 24px, 8: 32px);
$duration: (fast: 0.12s, base: 0.15s, slow: 0.2s, slide: 0.34s);

// SCSS-only. Never emitted: z-order and breakpoints are structure, not theme.
$z: (base: 1, raised: 2, float: 3, bar: 30, overlay: 40);
$bp: (md: 900px, sm: 760px, xs: 640px, xxs: 560px, tiny: 400px, min: 360px);
```

`design/src/styles/tokens/_emit.scss`:

```scss
@use "maps";

.ohf {
  @each $k, $v in maps.$legacy {
    --#{$k}: #{$v};
  }
  @each $k, $v in maps.$radius {
    --radius-#{$k}: #{$v};
  }
  @each $k, $v in maps.$height {
    --h-#{$k}: #{$v};
  }
  @each $k, $v in maps.$font-size {
    --fs-#{$k}: #{$v};
  }
  @each $k, $v in maps.$font-weight {
    --fw-#{$k}: #{$v};
  }
  @each $k, $v in maps.$letter-spacing {
    --ls-#{$k}: #{$v};
  }
  @each $k, $v in maps.$space {
    --sp-#{$k}: #{$v};
  }
  @each $k, $v in maps.$duration {
    --dur-#{$k}: #{$v};
  }
}
```

- [ ] **Step 4: 내보내기 스크립트 작성**

`design/scripts/export-tokens.mjs`:

```js
import { writeFileSync } from "node:fs";
import { fileURLToPath } from "node:url";

import * as sass from "sass-embedded";

const root = fileURLToPath(new URL("..", import.meta.url));

/* Compiles _emit.scss on its own and reads the `.ohf { --x: y }` block back.
   The JSON is therefore derived from the same Sass output the stylesheet
   ships, never from a second parse of the maps. */
export function collectTokens() {
  const css = sass.compile(`${root}src/styles/tokens/_emit.scss`, { style: "expanded" }).css;
  const block = /\.ohf\s*\{([^}]*)\}/.exec(css);
  if (!block) throw new Error("_emit.scss produced no .ohf block");
  const tokens = {};
  for (const line of block[1].split(";")) {
    const m = /^\s*--([\w-]+)\s*:\s*([\s\S]+?)\s*$/.exec(line);
    if (m) tokens[m[1]] = m[2].replace(/\s+/g, " ");
  }
  return tokens;
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const out = `${root}src/tokens/tokens.json`;
  writeFileSync(out, `${JSON.stringify(collectTokens(), null, 2)}\n`);
  console.log(`wrote ${out}`);
}
```

`design/scripts/export-tokens.d.mts`:

```ts
export function collectTokens(): Record<string, string>;
```

- [ ] **Step 5: tokens.json 생성과 `tokens/index.ts`**

Run: `corepack pnpm tokens`
Expected: `src/tokens/tokens.json` 생성, 71개 키. `head -5 src/tokens/tokens.json`에 `"bg": "#0a0a0b"`.

`design/src/tokens/index.ts`:

```ts
import raw from "./tokens.json";

export type Token = keyof typeof raw;

/* Frozen so a consumer cannot mutate the shared table by accident. */
export const tokens: Readonly<Record<Token, string>> = Object.freeze({ ...raw });

export function cssVar(name: Token): string {
  return `var(--${name})`;
}
```

`design/src/tokens/tokens.test.ts`:

```ts
import { describe, expect, it } from "vitest";

import { cssVar, tokens } from "./index";

describe("tokens", () => {
  it("wraps a token name as a custom property reference", () => {
    expect(cssVar("radius-ctl")).toBe("var(--radius-ctl)");
  });

  it("is frozen", () => {
    expect(Object.isFrozen(tokens)).toBe(true);
  });
});
```

- [ ] **Step 6: 통과 확인**

Run: `corepack pnpm test`
Expected: PASS — tokens-sync 4개, tokens 2개, package 2개.

Run: `corepack pnpm typecheck`
Expected: 오류 없음. `tokens.json` import가 오류면 `resolveJsonModule`이 켜져 있는지 확인.

---

