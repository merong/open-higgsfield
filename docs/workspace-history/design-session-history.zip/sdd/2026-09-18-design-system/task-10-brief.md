### Task 10: 조립 요소 9개

**Files:**
- Create: `design/src/composites/{TopBar,ProjectHeader,BriefBar,StoryboardRow,ActionStrip,CanvasPanel,ProjectCard,FormatCard,StyleCard}/…`
- Modify: `design/src/index.ts`

**Interfaces:**
- Consumes: Task 6–8 기본 요소, 아이콘, 믹스인.
- Produces:
  - `TopBar({ brand, brandHref?, brandLabel, nav: SegmentProps, credits?, creditsUnit?, topUp?, avatar? })` → `header.ohf-appbar`
  - `ProjectHeader({ back: { href?, onClick?, label }, title, tags?, status?, actions? })` → `.ohf-phead`
  - `BriefBar({ label, topic, pills?, action? })` → `.ohf-brief`
  - `StoryboardRow({ index, thumb: ThumbProps, tag?, title, sub?, counter?, prompt?, promptIcon?, status?, statusTone?: "default"|"live"|"danger", statusAction?, actions?, selected?, editing?, dragging?, onSelect? })` → `.ohf-sb-row(--selected/--editing/--dragging)`
  - `ActionStrip({ status?, actions?, notice? })` → `.ohf-astrip`
  - `CanvasPanel({ mode: SegmentProps, index, total, onPrev, onNext, prevLabel, nextLabel, stage, templates?: {label, chips}, options?: {label, pills}, actions?, hint? })` → `aside.ohf-canvas`
  - `ProjectCard({ href?, onClick?, deck, title, meta, status?, statusTone?: "done"|"live"|"draft" })` → `.ohf-pcard`
  - `FormatCard({ icon, name, description, pressed?, soon? })` → `button.ohf-fcard[aria-pressed]`
  - `StyleCard({ preview, name, description, pressed? })` → `button.ohf-scard[aria-pressed]`

- [ ] **Step 1: 실패하는 테스트 작성(9개 파일)**

`design/src/composites/TopBar/TopBar.test.tsx`:

```tsx
import { render, screen } from "@testing-library/react";
import { expect, it } from "vitest";

import { TopBar } from "./TopBar";

it("holds brand, scope tabs, credits and account", () => {
  render(
    <TopBar
      brand="OpenHiggsfield"
      brandLabel="홈"
      nav={{ items: [{ id: "studio", label: "Studio" }, { id: "projects", label: "Projects" }], value: "projects", onChange: () => {}, "aria-label": "구역" }}
      credits={1240}
      creditsUnit="크레딧"
      topUp={<button type="button">충전</button>}
      avatar={<span data-testid="avatar" />}
    />,
  );
  expect(screen.getByRole("banner")).toHaveClass("ohf-appbar");
  expect(screen.getByRole("link", { name: "홈" })).toHaveClass("ohf-appbar-brand");
  expect(screen.getByRole("tab", { name: "Projects" })).toHaveAttribute("aria-selected", "true");
  expect(screen.getByText("1,240")).toBeInTheDocument();
  expect(screen.getByRole("button", { name: "충전" })).toBeInTheDocument();
  expect(screen.getByTestId("avatar")).toBeInTheDocument();
});
```

`design/src/composites/ProjectHeader/ProjectHeader.test.tsx`:

```tsx
import { render, screen } from "@testing-library/react";
import { expect, it } from "vitest";

import { ProjectHeader } from "./ProjectHeader";

it("has a back link, a heading, tags, status and actions", () => {
  render(
    <ProjectHeader
      back={{ href: "/projects", label: "프로젝트 목록으로" }}
      title="여름 자외선 차단제"
      tags={<span>카드뉴스</span>}
      status="저장됨"
      actions={<button type="button">내보내기</button>}
    />,
  );
  expect(screen.getByRole("link", { name: "프로젝트 목록으로" })).toHaveAttribute("href", "/projects");
  expect(screen.getByRole("heading", { level: 1, name: "여름 자외선 차단제" })).toHaveClass("ohf-phead-title");
  expect(screen.getByText("저장됨")).toHaveClass("ohf-phead-status");
  expect(screen.getByRole("button", { name: "내보내기" })).toBeInTheDocument();
});

it("uses a button when back has no href", () => {
  render(<ProjectHeader back={{ onClick: () => {}, label: "뒤로" }} title="t" />);
  expect(screen.getByRole("button", { name: "뒤로" })).toBeInTheDocument();
});
```

`design/src/composites/BriefBar/BriefBar.test.tsx`:

```tsx
import { render, screen } from "@testing-library/react";
import { expect, it } from "vitest";

import { BriefBar } from "./BriefBar";

it("shows the topic with its label and slots", () => {
  const { container } = render(<BriefBar label="주제" topic="여름철 자외선 차단제" pills={<span>8장</span>} action={<button type="button">다시</button>} />);
  expect(container.firstChild).toHaveClass("ohf-brief");
  expect(screen.getByText("주제")).toHaveClass("ohf-brief-label");
  expect(screen.getByText("여름철 자외선 차단제")).toHaveClass("ohf-brief-topic");
  expect(screen.getByRole("button", { name: "다시" })).toBeInTheDocument();
});
```

`design/src/composites/StoryboardRow/StoryboardRow.test.tsx`:

```tsx
import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";

import { StoryboardRow } from "./StoryboardRow";

const base = { index: 3, thumb: { state: "image" as const, src: "/a.png" }, tag: "목록", title: "상황별 추천 지수", sub: "출퇴근 · 야외" };

describe("StoryboardRow", () => {
  it("lays out number, thumb, text, prompt and actions", () => {
    const onSelect = vi.fn();
    const { container } = render(
      <StoryboardRow {...base} prompt="도심 출근길" actions={<button type="button">복제</button>} onSelect={onSelect} />,
    );
    const row = container.firstChild as HTMLElement;
    expect(row).toHaveClass("ohf-sb-row");
    expect(row.querySelector(".ohf-sb-num")).toHaveTextContent("3");
    expect(row.querySelector(".ohf-frame--image")).not.toBeNull();
    expect(row.querySelector(".ohf-sb-title")).toHaveTextContent("상황별 추천 지수");
    expect(row.querySelector(".ohf-sb-prompt-text")).toHaveTextContent("도심 출근길");
    fireEvent.click(row);
    expect(onSelect).toHaveBeenCalledTimes(1);
  });

  it("marks selected, editing and dragging", () => {
    const { container, rerender } = render(<StoryboardRow {...base} selected />);
    expect(container.firstChild).toHaveClass("ohf-sb-row--selected");
    expect(container.firstChild).toHaveAttribute("aria-current", "true");
    rerender(<StoryboardRow {...base} editing dragging />);
    expect(container.firstChild).toHaveClass("ohf-sb-row--editing", "ohf-sb-row--dragging");
  });

  it("shows a status instead of the prompt, with a tone and an action", () => {
    const { container } = render(
      <StoryboardRow {...base} thumb={{ state: "failed" }} status="생성 실패" statusTone="danger" statusAction={<button type="button">다시 시도</button>} />,
    );
    expect(container.querySelector(".ohf-sb-status")).toHaveClass("ohf-sb-status--danger");
    expect(container.querySelector(".ohf-sb-prompt")).toBeNull();
    expect(screen.getByRole("button", { name: "다시 시도" })).toBeInTheDocument();
  });

  it("turns the counter red past the limit", () => {
    const { container } = render(<StoryboardRow {...base} counter={{ value: 96, max: 90 }} />);
    expect(container.querySelector(".ohf-sb-counter")).toHaveClass("ohf-sb-counter--over");
  });
});
```

`design/src/composites/ActionStrip/ActionStrip.test.tsx`:

```tsx
import { render, screen } from "@testing-library/react";
import { expect, it } from "vitest";

import { ActionStrip } from "./ActionStrip";

it("puts status left, actions right and a notice above", () => {
  const { container } = render(
    <ActionStrip status="7장 생성 대기" actions={<button type="button">생성</button>} notice={<div role="alert">오류</div>} />,
  );
  expect(container.firstChild).toHaveClass("ohf-astrip");
  expect(screen.getByText("7장 생성 대기").closest(".ohf-astrip-status")).not.toBeNull();
  expect(screen.getByRole("alert").closest(".ohf-astrip-notice")).not.toBeNull();
  expect(screen.getByRole("button", { name: "생성" })).toBeInTheDocument();
});
```

`design/src/composites/CanvasPanel/CanvasPanel.test.tsx`:

```tsx
import { fireEvent, render, screen } from "@testing-library/react";
import { expect, it, vi } from "vitest";

import { CanvasPanel } from "./CanvasPanel";

it("pages through slides and hosts the stage and its rows", () => {
  const onNext = vi.fn();
  render(
    <CanvasPanel
      mode={{ items: [{ id: "slide", label: "슬라이드" }, { id: "phone", label: "휴대폰" }], value: "slide", onChange: () => {}, "aria-label": "보기" }}
      index={1}
      total={8}
      onPrev={() => {}}
      onNext={onNext}
      prevLabel="이전 슬라이드"
      nextLabel="다음 슬라이드"
      stage={<div data-testid="stage" />}
      templates={{ label: "템플릿", chips: <button type="button">표지</button> }}
      options={{ label: "옵션", pills: <span>위치</span> }}
      actions={<button type="button">PNG</button>}
      hint="힌트"
    />,
  );
  expect(screen.getByRole("complementary")).toHaveClass("ohf-canvas");
  expect(screen.getByRole("button", { name: "이전 슬라이드" })).toBeDisabled();
  fireEvent.click(screen.getByRole("button", { name: "다음 슬라이드" }));
  expect(onNext).toHaveBeenCalledTimes(1);
  expect(screen.getByText("1 / 8")).toHaveClass("ohf-canvas-pager");
  expect(screen.getByTestId("stage").closest(".ohf-canvas-stage")).not.toBeNull();
  expect(screen.getByText("힌트")).toHaveClass("ohf-canvas-hint");
});
```

`design/src/composites/ProjectCard/ProjectCard.test.tsx`:

```tsx
import { render, screen } from "@testing-library/react";
import { expect, it } from "vitest";

import { ProjectCard } from "./ProjectCard";

it("is a link card with a deck, title, meta and a status tone", () => {
  render(<ProjectCard href="/p/1" deck={<span data-testid="deck" />} title="아침 루틴" meta="카드뉴스 · 6장" status="3장 생성 중" statusTone="live" />);
  const card = screen.getByRole("link", { name: /아침 루틴/ });
  expect(card).toHaveClass("ohf-pcard");
  expect(card.querySelector(".ohf-pcard-status")).toHaveClass("ohf-pcard-status--live");
  expect(screen.getByTestId("deck").closest(".ohf-pcard-deck")).not.toBeNull();
});

it("is a button without href", () => {
  render(<ProjectCard onClick={() => {}} deck={null} title="t" meta="m" />);
  expect(screen.getByRole("button")).toHaveClass("ohf-pcard");
});
```

`design/src/composites/FormatCard/FormatCard.test.tsx`:

```tsx
import { render, screen } from "@testing-library/react";
import { expect, it } from "vitest";

import { FormatCard } from "./FormatCard";

it("is a pressed toggle with icon, name and description", () => {
  render(<FormatCard icon={<svg />} name="카드뉴스" description="캐러셀" pressed />);
  expect(screen.getByRole("button", { pressed: true })).toHaveClass("ohf-fcard");
});

it("is disabled and tagged when coming soon", () => {
  render(<FormatCard icon={<svg />} name="릴스" description="세로 영상" soon="준비 중" />);
  const el = screen.getByRole("button");
  expect(el).toBeDisabled();
  expect(el).toHaveClass("ohf-fcard--soon");
  expect(screen.getByText("준비 중")).toHaveClass("ohf-tag");
});
```

`design/src/composites/StyleCard/StyleCard.test.tsx`:

```tsx
import { render, screen } from "@testing-library/react";
import { expect, it } from "vitest";

import { StyleCard } from "./StyleCard";

it("shows a preview, a name and a check when pressed", () => {
  const { container } = render(<StyleCard preview={<span data-testid="pv" />} name="기본 고딕" description="남색과 노랑" pressed />);
  expect(screen.getByRole("button", { pressed: true })).toHaveClass("ohf-scard");
  expect(screen.getByTestId("pv").closest(".ohf-scard-preview")).not.toBeNull();
  expect(container.querySelector(".ohf-scard-check")).not.toBeNull();
});
```

Run: `corepack pnpm test src/composites`
Expected: 9개 파일 FAIL(모듈 없음).

- [ ] **Step 2: TopBar, ProjectHeader, BriefBar 구현**

`design/src/composites/TopBar/TopBar.tsx`:

```tsx
import type { ReactNode } from "react";

import { CreditBadge } from "@/components/CreditBadge";
import { Segment, type SegmentProps } from "@/components/Segment";
import { cx } from "@/lib/cx";

import "./TopBar.scss";

export interface TopBarProps {
  brand: ReactNode;
  brandHref?: string;
  brandLabel: string;
  nav: SegmentProps;
  credits?: number;
  creditsUnit?: ReactNode;
  topUp?: ReactNode;
  avatar?: ReactNode;
  className?: string;
}

export function TopBar({ brand, brandHref = "/", brandLabel, nav, credits, creditsUnit, topUp, avatar, className }: TopBarProps) {
  return (
    <header className={cx("ohf-appbar", className)}>
      <a className="ohf-appbar-brand" href={brandHref} aria-label={brandLabel}>
        <span className="ohf-appbar-mark" aria-hidden="true">
          <span />
        </span>
        <span className="ohf-appbar-name">{brand}</span>
      </a>
      <Segment {...nav} size="sm" plate />
      <span className="ohf-appbar-spacer" />
      {credits !== undefined && <CreditBadge amount={credits} unit={creditsUnit} />}
      {topUp}
      {avatar}
    </header>
  );
}
```

`design/src/composites/TopBar/TopBar.scss`:

```scss
.ohf-appbar {
  display: flex;
  align-items: center;
  gap: 16px;
  height: 56px;
  padding: 0 20px;
  border-bottom: 1px solid var(--line);
  flex-shrink: 0;
}
.ohf-appbar-brand {
  display: flex;
  align-items: center;
  gap: 9px;
  color: var(--tx);
  text-decoration: none;
}
.ohf-appbar-mark {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 20px;
  height: 20px;
  border-radius: var(--radius-sm);
  background: var(--accent);
  > span {
    width: 8px;
    height: 8px;
    border-radius: 2px;
    background: var(--accent-ink);
  }
}
.ohf-appbar-name {
  font-size: 13.5px;
  font-weight: var(--fw-display);
  letter-spacing: -0.01em;
}
.ohf-appbar-spacer {
  flex: 1 1 auto;
  min-width: 0;
}
```

`design/src/composites/TopBar/index.ts`: `export * from "./TopBar";`

`design/src/composites/ProjectHeader/ProjectHeader.tsx`:

```tsx
import type { ReactNode } from "react";

import { IconButton } from "@/components/IconButton";
import { ChevronLeftIcon } from "@/icons";
import { cx } from "@/lib/cx";

import "./ProjectHeader.scss";

export interface ProjectHeaderProps {
  back: { href?: string; onClick?: () => void; label: string };
  title: ReactNode;
  tags?: ReactNode;
  status?: ReactNode;
  actions?: ReactNode;
  className?: string;
}

export function ProjectHeader({ back, title, tags, status, actions, className }: ProjectHeaderProps) {
  return (
    <div className={cx("ohf-phead", className)}>
      {back.href ? (
        <a className="ohf-phead-back" href={back.href} aria-label={back.label}>
          <ChevronLeftIcon size={18} />
        </a>
      ) : (
        <IconButton ghost size={30} icon={<ChevronLeftIcon size={18} />} aria-label={back.label} onClick={back.onClick} />
      )}
      <h1 className="ohf-phead-title">{title}</h1>
      {tags}
      {status !== undefined && <span className="ohf-phead-status">{status}</span>}
      <span className="ohf-phead-spacer" />
      {actions}
    </div>
  );
}
```

`design/src/composites/ProjectHeader/ProjectHeader.scss`:

```scss
@use "@/styles/mixins" as m;

.ohf-phead {
  display: flex;
  align-items: center;
  gap: 12px;
  height: 52px;
  padding: 0 20px 0 12px;
  border-bottom: 1px solid var(--line);
  flex-shrink: 0;
}
.ohf-phead-back {
  display: flex;
  align-items: center;
  justify-content: center;
  width: var(--h-sm);
  height: var(--h-sm);
  border-radius: var(--radius-md);
  color: var(--tx3);
  @include m.control-states(var(--s3), var(--tx));
}
.ohf-phead-title {
  font-size: var(--fs-lg);
  font-weight: var(--fw-bold);
  letter-spacing: -0.01em;
  color: var(--tx);
  white-space: nowrap;
}
.ohf-phead-status {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-left: 4px;
  color: var(--tx4);
  font-size: var(--fs-xs);
}
.ohf-phead-spacer {
  flex: 1 1 auto;
  min-width: 0;
}
```

`design/src/composites/ProjectHeader/index.ts`: `export * from "./ProjectHeader";`

`design/src/composites/BriefBar/BriefBar.tsx`:

```tsx
import type { ReactNode } from "react";

import { cx } from "@/lib/cx";

import "./BriefBar.scss";

export interface BriefBarProps {
  label: ReactNode;
  topic: ReactNode;
  pills?: ReactNode;
  action?: ReactNode;
  className?: string;
}

export function BriefBar({ label, topic, pills, action, className }: BriefBarProps) {
  return (
    <div className={cx("ohf-brief", className)}>
      <span className="ohf-brief-label">{label}</span>
      <span className="ohf-brief-topic">{topic}</span>
      {pills}
      {action}
    </div>
  );
}
```

`design/src/composites/BriefBar/BriefBar.scss`:

```scss
@use "@/styles/mixins" as m;

/* The composer's own card: same plate, same hairline, same glint. */
.ohf-brief {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 6px 6px 6px 14px;
  border-radius: var(--radius-lg);
  background: var(--s2);
  border: 1px solid var(--line);
  box-shadow: var(--shadow-2), var(--glint);
}
.ohf-brief-label {
  flex-shrink: 0;
  font-size: var(--fs-xs);
  font-weight: var(--fw-strong);
  color: var(--tx3);
}
.ohf-brief-topic {
  flex: 1;
  min-width: 0;
  font-size: 13.5px;
  color: var(--tx);
  @include m.truncate;
}
```

`design/src/composites/BriefBar/index.ts`: `export * from "./BriefBar";`

- [ ] **Step 3: StoryboardRow, ActionStrip 구현**

`design/src/composites/StoryboardRow/StoryboardRow.tsx`:

```tsx
import type { HTMLAttributes, ReactNode } from "react";

import { Tag } from "@/components/Tag";
import { Thumb, type ThumbProps } from "@/components/Thumb";
import { GripIcon, ImageIcon } from "@/icons";
import { cx } from "@/lib/cx";

import "./StoryboardRow.scss";

export interface StoryboardRowProps extends Omit<HTMLAttributes<HTMLDivElement>, "title"> {
  index: number;
  thumb: ThumbProps;
  tag?: ReactNode;
  title: ReactNode;
  sub?: ReactNode;
  counter?: { value: number; max: number };
  /* The right column is either the prompt or a status line; a status wins. */
  prompt?: ReactNode;
  promptIcon?: ReactNode;
  status?: ReactNode;
  statusTone?: "default" | "live" | "danger";
  statusAction?: ReactNode;
  actions?: ReactNode;
  selected?: boolean;
  editing?: boolean;
  dragging?: boolean;
  onSelect?: () => void;
}

export function StoryboardRow({
  index,
  thumb,
  tag,
  title,
  sub,
  counter,
  prompt,
  promptIcon,
  status,
  statusTone = "default",
  statusAction,
  actions,
  selected = false,
  editing = false,
  dragging = false,
  onSelect,
  className,
  ...rest
}: StoryboardRowProps) {
  const over = counter !== undefined && counter.value > counter.max;
  return (
    <div
      className={cx(
        "ohf-sb-row",
        selected && "ohf-sb-row--selected",
        editing && "ohf-sb-row--editing",
        dragging && "ohf-sb-row--dragging",
        className,
      )}
      aria-current={selected ? "true" : undefined}
      onClick={onSelect}
      {...rest}
    >
      <div className="ohf-sb-num">
        <span className="ohf-sb-grip" aria-hidden="true">
          <GripIcon size={14} />
        </span>
        <span>{index}</span>
      </div>
      <Thumb {...thumb} />
      <div className="ohf-sb-text">
        {tag !== undefined && <Tag>{tag}</Tag>}
        <div className="ohf-sb-title">{title}</div>
        {(sub !== undefined || counter) && (
          <div className="ohf-sb-sub">
            <span className="ohf-sb-sub-text">{sub}</span>
            {counter && (
              <span className={cx("ohf-sb-counter", over && "ohf-sb-counter--over")}>
                {counter.value} / {counter.max}
              </span>
            )}
          </div>
        )}
      </div>
      <div className="ohf-sb-side">
        {status !== undefined ? (
          <span className={cx("ohf-sb-status", statusTone !== "default" && `ohf-sb-status--${statusTone}`)}>
            {statusTone === "live" && <span className="ohf-sb-lamp" aria-hidden="true" />}
            {status}
          </span>
        ) : prompt !== undefined ? (
          <span className="ohf-sb-prompt">
            <span className="ohf-sb-prompt-ic">{promptIcon ?? <ImageIcon size={13} />}</span>
            <span className="ohf-sb-prompt-text">{prompt}</span>
          </span>
        ) : null}
        {statusAction}
      </div>
      <div className="ohf-sb-actions">{actions}</div>
    </div>
  );
}
```

`design/src/composites/StoryboardRow/StoryboardRow.scss`:

```scss
@use "@/styles/mixins" as m;

.ohf-sb-row {
  display: grid;
  grid-template-columns: 28px 56px minmax(0, 1.15fr) minmax(0, 1fr) 92px;
  gap: 12px;
  align-items: center;
  height: 90px;
  padding: 0 16px 0 12px;
  border-left: 2px solid transparent;
  border-bottom: 1px solid var(--line);
  transition: background var(--dur-base) ease;

  &:hover,
  &[data-state="hover"] {
    background: var(--rail);
  }
  /* Selection is the one place the row takes the accent: a bar, not a fill. */
  &--selected {
    background: var(--s1);
    border-left-color: var(--accent);
  }
  &--editing {
    background: var(--s1);
    box-shadow: inset 0 0 0 1px var(--accent-32);
  }
  &--dragging {
    opacity: 0.6;
    background: var(--s2);
    box-shadow: var(--shadow-2);
  }
}
.ohf-sb-num {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  font-weight: var(--fw-medium);
  color: var(--tx3);
  @include m.tabular;
}
.ohf-sb-row--selected .ohf-sb-num {
  color: var(--tx);
  font-weight: var(--fw-bold);
}
.ohf-sb-grip {
  display: flex;
  color: transparent;
}
.ohf-sb-row--selected .ohf-sb-grip,
.ohf-sb-row:hover .ohf-sb-grip,
.ohf-sb-row[data-state="hover"] .ohf-sb-grip,
.ohf-sb-row--dragging .ohf-sb-grip {
  color: var(--tx4);
}
.ohf-sb-text {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 3px;
  min-width: 0;
}
.ohf-sb-title {
  max-width: 100%;
  font-size: 13.5px;
  font-weight: var(--fw-bold);
  letter-spacing: var(--ls-tight);
  color: var(--tx);
  @include m.truncate;
}
.ohf-sb-sub {
  display: flex;
  align-items: center;
  gap: 6px;
  max-width: 100%;
  font-size: 12px;
  color: var(--tx3);
}
.ohf-sb-sub-text {
  @include m.truncate;
}
.ohf-sb-counter {
  flex-shrink: 0;
  @include m.tabular;
  &--over {
    color: var(--danger);
  }
}
.ohf-sb-side {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
}
.ohf-sb-prompt {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  height: 34px;
  padding: 0 10px;
  border-radius: var(--radius-md);
  background: var(--s1);
  border: 1px solid var(--line);
  color: var(--tx2);
  font-size: 12px;
}
.ohf-sb-row--selected .ohf-sb-prompt {
  background: var(--s2);
}
.ohf-sb-prompt-ic {
  display: flex;
  flex-shrink: 0;
  color: var(--tx4);
}
.ohf-sb-prompt-text {
  @include m.truncate;
}
.ohf-sb-status {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  font-size: 12px;
  color: var(--tx4);
  @include m.truncate;
  &--live {
    color: var(--tx3);
  }
  &--danger {
    color: var(--danger);
  }
}
.ohf-sb-lamp {
  flex-shrink: 0;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--accent);
  animation: ohf-pulse 2.4s ease-in-out infinite;
}
.ohf-sb-actions {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 2px;
}
```

`design/src/composites/StoryboardRow/index.ts`: `export * from "./StoryboardRow";`

`design/src/composites/ActionStrip/ActionStrip.tsx`:

```tsx
import type { ReactNode } from "react";

import { cx } from "@/lib/cx";

import "./ActionStrip.scss";

export interface ActionStripProps {
  status?: ReactNode;
  actions?: ReactNode;
  /* An Alert or UndoBar rides above the row, in the strip's own space —
     the studio gains no second floating layer. */
  notice?: ReactNode;
  className?: string;
}

export function ActionStrip({ status, actions, notice, className }: ActionStripProps) {
  return (
    <div className={cx("ohf-astrip", className)}>
      {notice !== undefined && <div className="ohf-astrip-notice">{notice}</div>}
      <div className="ohf-astrip-row">
        <div className="ohf-astrip-status">{status}</div>
        <span className="ohf-astrip-spacer" />
        {actions}
      </div>
    </div>
  );
}
```

`design/src/composites/ActionStrip/ActionStrip.scss`:

```scss
.ohf-astrip {
  flex-shrink: 0;
  padding: 0 20px;
  border-top: 1px solid var(--line);
  background: var(--rail);
}
.ohf-astrip-notice {
  padding-top: 10px;
}
.ohf-astrip-row {
  display: flex;
  align-items: center;
  gap: 10px;
  height: 60px;
}
.ohf-astrip-status {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  font-size: var(--fs-sm);
  color: var(--tx2);
}
.ohf-astrip-spacer {
  flex: 1 1 auto;
  min-width: 0;
}
```

`design/src/composites/ActionStrip/index.ts`: `export * from "./ActionStrip";`

- [ ] **Step 4: CanvasPanel, ProjectCard 구현**

`design/src/composites/CanvasPanel/CanvasPanel.tsx`:

```tsx
import type { ReactNode } from "react";

import { IconButton } from "@/components/IconButton";
import { Segment, type SegmentProps } from "@/components/Segment";
import { ChevronLeftIcon, ChevronRightIcon } from "@/icons";
import { cx } from "@/lib/cx";

import "./CanvasPanel.scss";

export interface CanvasPanelProps {
  mode: SegmentProps;
  index: number;
  total: number;
  onPrev: () => void;
  onNext: () => void;
  prevLabel: string;
  nextLabel: string;
  stage: ReactNode;
  templates?: { label: ReactNode; chips: ReactNode };
  options?: { label: ReactNode; pills: ReactNode };
  actions?: ReactNode;
  hint?: ReactNode;
  className?: string;
}

export function CanvasPanel({ mode, index, total, onPrev, onNext, prevLabel, nextLabel, stage, templates, options, actions, hint, className }: CanvasPanelProps) {
  return (
    <aside className={cx("ohf-canvas", className)}>
      <div className="ohf-canvas-head">
        <Segment {...mode} size="sm" plate />
        <span className="ohf-canvas-spacer" />
        <IconButton ghost size={30} icon={<ChevronLeftIcon />} aria-label={prevLabel} onClick={onPrev} disabled={index <= 1} />
        <span className="ohf-canvas-pager">
          {index} / {total}
        </span>
        <IconButton ghost size={30} icon={<ChevronRightIcon />} aria-label={nextLabel} onClick={onNext} disabled={index >= total} />
      </div>
      <div className="ohf-canvas-stage">{stage}</div>
      <div className="ohf-canvas-foot">
        {templates && (
          <div className="ohf-canvas-row">
            <span className="ohf-canvas-label">{templates.label}</span>
            {templates.chips}
          </div>
        )}
        {options && (
          <div className="ohf-canvas-row">
            <span className="ohf-canvas-label">{options.label}</span>
            {options.pills}
          </div>
        )}
        {actions !== undefined && <div className="ohf-canvas-actions">{actions}</div>}
        {hint !== undefined && <div className="ohf-canvas-hint">{hint}</div>}
      </div>
    </aside>
  );
}
```

`design/src/composites/CanvasPanel/CanvasPanel.scss`:

```scss
@use "@/styles/mixins" as m;

.ohf-canvas {
  position: relative;
  display: flex;
  flex-direction: column;
  gap: 14px;
  min-width: 0;
  padding: 16px 20px;
  background: var(--rail);
  border-left: 1px solid var(--line);
}
.ohf-canvas-head {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-shrink: 0;
}
.ohf-canvas-spacer {
  flex: 1 1 auto;
}
.ohf-canvas-pager {
  font-size: var(--fs-sm);
  color: var(--tx2);
  @include m.tabular;
}
/* The stage frames the slide with the app's radius and depth; the slide
   itself knows nothing of the app. */
.ohf-canvas-stage {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 0;
  .ohf-slide {
    width: min(100%, 448px);
    border-radius: var(--radius-ctl);
    box-shadow: var(--shadow-3);
  }
}
.ohf-canvas-foot {
  display: flex;
  flex-direction: column;
  gap: 10px;
  flex-shrink: 0;
}
.ohf-canvas-row {
  display: flex;
  align-items: center;
  gap: 6px;
  flex-wrap: wrap;
}
.ohf-canvas-label {
  width: 44px;
  font-size: var(--fs-xs);
  font-weight: var(--fw-strong);
  color: var(--tx3);
}
.ohf-canvas-actions {
  display: flex;
  gap: 8px;
  > * {
    flex: 1;
  }
}
.ohf-canvas-hint {
  font-size: var(--fs-xs);
  color: var(--tx4);
}
```

`design/src/composites/CanvasPanel/index.ts`: `export * from "./CanvasPanel";`

`design/src/composites/ProjectCard/ProjectCard.tsx`:

```tsx
import type { ReactNode } from "react";

import { CheckIcon } from "@/icons";
import { cx } from "@/lib/cx";

import "./ProjectCard.scss";

export interface ProjectCardProps {
  href?: string;
  onClick?: () => void;
  deck: ReactNode;
  title: ReactNode;
  meta: ReactNode;
  status?: ReactNode;
  statusTone?: "done" | "live" | "draft";
  className?: string;
}

export function ProjectCard({ href, onClick, deck, title, meta, status, statusTone = "done", className }: ProjectCardProps) {
  const body = (
    <>
      <div className="ohf-pcard-deck">{deck}</div>
      <div className="ohf-pcard-body">
        <div className="ohf-pcard-title">{title}</div>
        <div className="ohf-pcard-meta">
          <span>{meta}</span>
          <span className="ohf-pcard-spacer" />
          {status !== undefined && (
            <span className={cx("ohf-pcard-status", `ohf-pcard-status--${statusTone}`)}>
              {statusTone === "live" && <span className="ohf-pcard-lamp" aria-hidden="true" />}
              {statusTone === "done" && <CheckIcon size={13} />}
              {status}
            </span>
          )}
        </div>
      </div>
    </>
  );
  const cls = cx("ohf-pcard", className);
  return href !== undefined ? (
    <a className={cls} href={href}>
      {body}
    </a>
  ) : (
    <button type="button" className={cls} onClick={onClick}>
      {body}
    </button>
  );
}
```

`design/src/composites/ProjectCard/ProjectCard.scss`:

```scss
@use "@/styles/mixins" as m;

.ohf-pcard {
  display: flex;
  flex-direction: column;
  overflow: hidden;
  border-radius: var(--radius-lg);
  background: var(--s1);
  border: 1px solid var(--line);
  box-shadow: var(--shadow-1), var(--glint);
  color: var(--tx);
  text-decoration: none;
  text-align: left;
  transition:
    border-color var(--dur-base) ease,
    background var(--dur-base) ease;
  &:hover,
  &[data-state="hover"] {
    border-color: var(--line-2);
    background: var(--s2);
  }
}
.ohf-pcard-deck {
  display: flex;
  gap: 6px;
  padding: 12px 12px 0;
}
.ohf-pcard-body {
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding: 12px 14px 14px;
}
.ohf-pcard-title {
  font-size: var(--fs-base);
  font-weight: var(--fw-bold);
  letter-spacing: var(--ls-tight);
  @include m.truncate;
}
.ohf-pcard-meta {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 12px;
  color: var(--tx3);
  @include m.tabular;
}
.ohf-pcard-spacer {
  flex: 1;
}
.ohf-pcard-status {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  font-size: var(--fs-xs);
  color: var(--tx2);
  &--live {
    color: var(--accent);
  }
  &--draft {
    color: var(--tx3);
  }
}
.ohf-pcard-lamp {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--accent);
}
```

`design/src/composites/ProjectCard/index.ts`: `export * from "./ProjectCard";`

- [ ] **Step 5: FormatCard, StyleCard 구현**

`design/src/composites/FormatCard/FormatCard.tsx`:

```tsx
import type { ButtonHTMLAttributes, ReactNode } from "react";

import { Tag } from "@/components/Tag";
import { CheckIcon } from "@/icons";
import { cx } from "@/lib/cx";

import "./FormatCard.scss";

export interface FormatCardProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, "children"> {
  icon: ReactNode;
  name: ReactNode;
  description: ReactNode;
  pressed?: boolean;
  /* Copy for the "coming soon" tag; its presence disables the card. */
  soon?: ReactNode;
}

export function FormatCard({ icon, name, description, pressed = false, soon, className, type, disabled, ...rest }: FormatCardProps) {
  return (
    <button
      type={type ?? "button"}
      className={cx("ohf-fcard", soon !== undefined && "ohf-fcard--soon", className)}
      aria-pressed={pressed}
      disabled={disabled || soon !== undefined}
      {...rest}
    >
      <span className="ohf-fcard-head">
        <span className="ohf-fcard-icon">{icon}</span>
        <span className="ohf-fcard-name">{name}</span>
        <span className="ohf-fcard-spacer" />
        {soon !== undefined ? (
          <Tag tone="muted">{soon}</Tag>
        ) : pressed ? (
          <span className="ohf-fcard-check">
            <CheckIcon size={15} />
          </span>
        ) : null}
      </span>
      <span className="ohf-fcard-desc">{description}</span>
    </button>
  );
}
```

`design/src/composites/FormatCard/FormatCard.scss`:

```scss
.ohf-fcard {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 10px;
  flex: 1;
  padding: 14px;
  border-radius: 12px;
  text-align: left;
  background: var(--s1);
  border: 1px solid var(--line);
  color: var(--tx);
  transition:
    background var(--dur-base) ease,
    border-color var(--dur-base) ease;

  &:hover:not(:disabled),
  &[data-state="hover"] {
    background: var(--s2);
    border-color: var(--line-2);
  }
  &[aria-pressed="true"] {
    background: var(--accent-08);
    border-color: var(--accent-32);
    .ohf-fcard-icon {
      color: var(--accent);
    }
  }
  &:disabled {
    background: transparent;
    color: var(--tx-off);
    cursor: default;
    .ohf-fcard-icon,
    .ohf-fcard-desc {
      color: var(--tx-off);
    }
  }
}
.ohf-fcard-head {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
}
.ohf-fcard-icon {
  display: flex;
  color: var(--tx2);
}
.ohf-fcard-name {
  font-size: 13.5px;
  font-weight: var(--fw-bold);
}
.ohf-fcard-spacer {
  flex: 1;
}
.ohf-fcard-check {
  display: flex;
  color: var(--accent);
}
.ohf-fcard-desc {
  font-size: 12px;
  line-height: 1.45;
  color: var(--tx3);
}
```

`design/src/composites/FormatCard/index.ts`: `export * from "./FormatCard";`

`design/src/composites/StyleCard/StyleCard.tsx`:

```tsx
import type { ButtonHTMLAttributes, ReactNode } from "react";

import { CheckIcon } from "@/icons";
import { cx } from "@/lib/cx";

import "./StyleCard.scss";

export interface StyleCardProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, "children"> {
  /* Two mini slides (a cover over a photo and a flat CTA), drawn by the caller. */
  preview: ReactNode;
  name: ReactNode;
  description: ReactNode;
  pressed?: boolean;
}

export function StyleCard({ preview, name, description, pressed = false, className, type, ...rest }: StyleCardProps) {
  return (
    <button type={type ?? "button"} className={cx("ohf-scard", className)} aria-pressed={pressed} {...rest}>
      <span className="ohf-scard-preview">{preview}</span>
      <span className="ohf-scard-row">
        <span className="ohf-scard-name">{name}</span>
        <span className="ohf-scard-spacer" />
        {pressed && (
          <span className="ohf-scard-check">
            <CheckIcon size={14} />
          </span>
        )}
      </span>
      <span className="ohf-scard-desc">{description}</span>
    </button>
  );
}
```

`design/src/composites/StyleCard/StyleCard.scss`:

```scss
.ohf-scard {
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding: 8px;
  border-radius: 12px;
  text-align: left;
  background: var(--s1);
  border: 1px solid var(--line);
  color: var(--tx);
  transition:
    background var(--dur-base) ease,
    border-color var(--dur-base) ease;

  &:hover,
  &[data-state="hover"] {
    border-color: var(--line-2);
  }
  &[aria-pressed="true"] {
    background: var(--accent-08);
    border-color: var(--accent-32);
  }
}
.ohf-scard-preview {
  display: flex;
  gap: 6px;
  > * {
    flex: 1;
    min-width: 0;
  }
  .ohf-slide {
    border-radius: var(--radius-sm);
  }
}
.ohf-scard-row {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 0 2px;
}
.ohf-scard-name {
  font-size: var(--fs-sm);
  font-weight: var(--fw-bold);
}
.ohf-scard-spacer {
  flex: 1;
}
.ohf-scard-check {
  display: flex;
  color: var(--accent);
}
.ohf-scard-desc {
  padding: 0 2px;
  font-size: 11px;
  line-height: 1.4;
  color: var(--tx3);
}
```

`design/src/composites/StyleCard/index.ts`: `export * from "./StyleCard";`

- [ ] **Step 6: 공개 API와 검증**

`design/src/index.ts`에 추가:

```ts
export * from "./composites/ActionStrip";
export * from "./composites/BriefBar";
export * from "./composites/CanvasPanel";
export * from "./composites/FormatCard";
export * from "./composites/ProjectCard";
export * from "./composites/ProjectHeader";
export * from "./composites/StoryboardRow";
export * from "./composites/StyleCard";
export * from "./composites/TopBar";
```

Run: `corepack pnpm test && corepack pnpm typecheck && corepack pnpm build`
Expected: 전부 통과, `dist ok`. `grep -c "ohf-sb-row--selected" dist/ohf.css` ≥ 1.

---

