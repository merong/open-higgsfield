# Task 3 report — 스타일시트 1:1 이식과 parity 테스트

## Implemented

Followed the brief's steps in order, test-first where specified.

**Step 1–3 — flatten helper (test-first):**
- `test/lib/flatten.test.ts` written verbatim from the brief.
- Step 2: `corepack pnpm test test/lib/flatten.test.ts` → RED as expected (`Failed to resolve import "./flatten"`).
- `test/lib/flatten.ts` written verbatim from the brief.
- Re-run → GREEN, 8/8 tests pass.

**Step 4 — parity test (test-first):**
- `test/parity.test.ts` written per the brief, with one required fix (see Deviations).
- Step 2 check: `corepack pnpm test test/parity.test.ts` → first test (`has the original stylesheet to compare against`) passed; the other two failed with `Cannot open file: .../src/styles/index.scss` — matches the brief's expected RED ("첫 테스트는 통과").

**Step 5 — `src/styles/base/_reset.scss`:** written by hand, verbatim from the brief (original lines 1–136 minus the token block at 8–43). Cross-checked against `open-higgsfield/src/openhiggsfield/openhiggsfield.css` lines 44–136 — matches exactly.

**Step 6 — remaining partials via `sed`:** ran the brief's block verbatim (all 19 `studio/_*.scss` + `base/_keyframes.scss`). Section-boundary table cross-checked first via `grep -n "^/\* ---------- " openhiggsfield.css` — every line number in the brief's table matched the grep output exactly, so no adjustment was needed. `wc -l` total: 3,698 (base+studio partials, excluding hand-written `_reset.scss`), in the expected ~3,600+ range. `head -1` on every `studio/_*.scss` confirmed each starts with its `/* ---------- <name> ---------- */` banner. Per-partial line counts were individually verified against `end − start + 1` for all 20 ranges — every one matches exactly.
- `src/styles/index.scss` written verbatim from the brief (23 `@use` lines, tokens/emit → reset → keyframes → 19 studio partials in original order).

**Step 7 — parity:** `corepack pnpm test test/parity.test.ts` passed on the **first attempt** after Step 5/6 — 3/3 tests green. None of the brief's listed pitfalls (Sass parse errors, `a / b` division, `calc()`/`min()` evaluation) occurred; no partial needed hand-editing.

**Step 8 — entry point + build:**
- `src/index.ts` updated to import `"./styles/index.scss"` and re-export `cssVar`/`tokens`/`Token` from `./tokens`, verbatim from the brief.
- `corepack pnpm build && grep -c "ohf-generate" dist/ohf.css` → `dist ok`, then `1` (≥ 1, as expected).

**Step 9 — final verification:** `corepack pnpm test && corepack pnpm typecheck` — both pass, pristine output (5 test files / 19 tests; tsc silent).

**Controller ruling — `dist/ohf.css` must never be empty again:**
- In `scripts/check-dist.mjs`, removed the Task-1 fallback (`if (!existsSync(join(dist, "ohf.css"))) writeFileSync(join(dist, "ohf.css"), "")` and its comment).
- Replaced the existence loop's implicit "empty is OK" with an explicit size check: `if (statSync(join(dist, "ohf.css")).size === 0) throw new Error("dist/ohf.css is empty")`, placed right after the missing-file loop, with a `/* … */` comment explaining why (real SCSS ships from Task 3 on, so empty now means the CSS import was dropped from the bundle — a regression, not a legitimate state).
- Removed the now-unused `writeFileSync` import from `node:fs` (this file isn't in `tsconfig.json`'s `include`, so `noUnusedLocals` wouldn't have caught it, but left in place it would have been dead/misleading).
- `corepack pnpm build` still ends with `dist ok`.
- **`dist/ohf.css` size: 53,860 bytes** (53.86 kB per Vite's build summary, gzip 10.56 kB).
- Also ran `corepack pnpm build:showcase` as an extra sanity check (not required by the brief) — succeeds, 27 modules transformed.

## Deviations from the brief's literal text

1. **`test/parity.test.ts` — `new URL(relative, import.meta.url)` → `dirname`-based path resolution.** The brief's literal code uses `fileURLToPath(new URL("../../open-higgsfield/...", import.meta.url))` and `fileURLToPath(new URL("../src/styles/index.scss", import.meta.url))`. Run as written, both failed with `TypeError: The URL must be of scheme file` — Vitest statically pattern-matches `new URL(<relative>, import.meta.url)` and rewrites it into an asset URL, the same failure mode already recorded for `scripts/export-tokens.mjs` in Task 2's report. Fixed with the same pattern used there: `const here = dirname(fileURLToPath(import.meta.url)); const ORIGINAL = join(here, "../../open-higgsfield/src/openhiggsfield/openhiggsfield.css"); const ENTRY = join(here, "../src/styles/index.scss");`, with a `/* … */` comment recording why. Resolves to the identical paths; nothing else in the test changed. Confirmed this was necessary (not a pre-existing environment problem) by re-running with the brief's literal text first, which reproduced the `TypeError`.
2. **`scripts/check-dist.mjs`** — controller ruling, described above, not part of the brief's literal Task 3 text but given as an explicit small extra requirement for this task.

No other deviations. Section-boundary line numbers matched the brief's table exactly (confirmed by `grep -n "^/\* ---------- "` before cutting, per the brief's own instruction), so no `sed` range needed correcting, and the parity test passed without any partial requiring the documented workarounds (`#{"…"}` interpolation for division/calc, or fixing invalid SCSS-breaking syntax).

## Tests

```
corepack pnpm test test/lib/flatten.test.ts   # RED before flatten.ts existed: "Failed to resolve import ./flatten"
corepack pnpm test test/lib/flatten.test.ts   # GREEN after: 8 passed (8)
corepack pnpm test test/parity.test.ts        # RED before index.scss existed: 1 passed / 2 failed ("Cannot open file: .../src/styles/index.scss")
corepack pnpm test test/parity.test.ts        # GREEN after Steps 5–6: 3 passed (3)
corepack pnpm build                           # "dist ok"; grep -c ohf-generate dist/ohf.css → 1
corepack pnpm test                            # 5 test files, 19 tests, all passed
corepack pnpm typecheck                       # tsc --noEmit, no output, exit 0
corepack pnpm build:showcase                  # extra sanity check, succeeds (27 modules)
```

Final `corepack pnpm test` output:
```
 Test Files  5 passed (5)
      Tests  19 passed (19)
```

## Files created

- `design/test/lib/flatten.ts`
- `design/test/lib/flatten.test.ts`
- `design/test/parity.test.ts`
- `design/src/styles/base/_reset.scss`
- `design/src/styles/base/_keyframes.scss`
- `design/src/styles/studio/_shell.scss`
- `design/src/styles/studio/_topbar.scss`
- `design/src/styles/studio/_tabs.scss`
- `design/src/styles/studio/_lamp.scss`
- `design/src/styles/studio/_main.scss`
- `design/src/styles/studio/_gallery.scss`
- `design/src/styles/studio/_picking.scss`
- `design/src/styles/studio/_empty.scss`
- `design/src/styles/studio/_composer.scss`
- `design/src/styles/studio/_attached.scss`
- `design/src/styles/studio/_dock.scss`
- `design/src/styles/studio/_tooltips.scss`
- `design/src/styles/studio/_popovers.scss`
- `design/src/styles/studio/_asset-picker.scss`
- `design/src/styles/studio/_dialogs.scss`
- `design/src/styles/studio/_viewer.scss`
- `design/src/styles/studio/_entrance.scss`
- `design/src/styles/studio/_responsive.scss`
- `design/src/styles/studio/_reduced-motion.scss`
- `design/src/styles/index.scss`

## Files modified

- `design/src/index.ts` — added `import "./styles/index.scss"` and the `cssVar`/`tokens`/`Token` re-exports (brief's Step 8, verbatim).
- `design/scripts/check-dist.mjs` — controller ruling: removed the empty-CSS fallback, added the empty-file failure check, dropped the now-unused `writeFileSync` import.

## Self-review

- **Completeness:** every file the brief lists exists; every step's expected output was seen and matches (RED before, GREEN after, at each test-first checkpoint).
- **Quality:** no debug leftovers; comments are `/* … */` "why" blocks per the brief and per Global Constraints; identifiers in English. `dist ok`, tsc silent.
- **Discipline:** touched only the files the brief names, `src/index.ts`, and `scripts/check-dist.mjs` (the latter per the controller's explicit ruling for this task, not self-initiated scope). Did not touch Task 2's `tokens/_maps.scss`, `tokens/_emit.scss`, `tokens.json`, or `tokens/index.ts`.
- **Testing:** `flatten.test.ts` and `parity.test.ts` both exercise real behaviour — the parity test compiles both sheets through the same Dart Sass instance and diffs resolved declarations in original order, so it would catch a missing partial, a wrong `@use` order, a truncated `sed` range, or a resolved-value mismatch.
- **Verification of the boundary table:** re-ran `grep -n "^/\* ---------- " openhiggsfield.css` independently before cutting and diffed it mentally against the brief's table — identical, including the non-obvious ones (`_dock.scss` covering "the dock's second instrument" banner at 1425, `_main.scss` at only 9 lines).
- **No open concerns.** The dev server on port 5173 was left untouched; only `test`/`typecheck`/`build`/`build:showcase` were run, none of which start or touch that process.
