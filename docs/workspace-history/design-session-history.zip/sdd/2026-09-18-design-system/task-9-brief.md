### Task 9: 슬라이드 층

**Files:**
- Create: `design/src/slides/styles.ts`, `design/src/slides/SlideFrame.tsx`, `design/src/slides/templates.tsx`, `design/src/slides/slides.scss`, `design/src/slides/index.ts`, `design/src/slides/slides.test.tsx`
- Modify: `design/src/index.ts`

**Interfaces:**
- Consumes: `cx`, `ratioToCss`.
- Produces:
  - `SLIDE_STYLES: Record<SlidePreset, SlideStyle>`, `SLIDE_PRESETS`, `type SlidePreset = "basic"|"editorial"|"impact"|"soft"`, `type SlideStyle`
  - `SlideFrame({ preset, ratio?: "4:5"|"3:4"|"1:1"|"9:16", image?, dim?: number|"grad", handle?, page?, showFooter?, position?: "start"|"mid"|"end", children })` → `.ohf-slide[data-preset]`. 기획서는 `position`을 템플릿 props에 두었지만 세로 정렬은 프레임의 레이아웃이므로 프레임이 갖는다(README에 적는다).
  - 템플릿: `CoverSlide({ kicker?, title, sub?, titleSize?: "md"|"lg" })`, `BodySlide({ title, body })`, `ListSlide({ title, items: {label, value?}[], numbered? })`, `QuoteSlide({ quote, source? })`, `CtaSlide({ title, sub?, pill? })`
  - 슬라이드 토큰(`.ohf-slide` 인라인): `--sl-bg --sl-tx --sl-acc --sl-acc-ink --sl-head --sl-head-weight --sl-head-ls --sl-head-lh --sl-body --sl-dim`

- [ ] **Step 1: 실패하는 테스트 작성**

`design/src/slides/slides.test.tsx`:

```tsx
import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";

import { SlideFrame } from "./SlideFrame";
import { SLIDE_PRESETS, SLIDE_STYLES } from "./styles";
import { BodySlide, CoverSlide, CtaSlide, ListSlide, QuoteSlide } from "./templates";

describe("SlideFrame", () => {
  it("carries the preset as custom properties and the ratio as aspect-ratio", () => {
    const { container } = render(
      <SlideFrame preset="editorial" ratio="1:1" handle="@sunny" page="1 / 8">
        <CoverSlide title="제목" />
      </SlideFrame>,
    );
    const el = container.firstChild as HTMLElement;
    expect(el).toHaveClass("ohf-slide", "ohf-slide--end");
    expect(el.dataset.preset).toBe("editorial");
    expect(el.style.getPropertyValue("--sl-bg")).toBe(SLIDE_STYLES.editorial.bg);
    expect(el.style.getPropertyValue("--sl-head")).toBe(SLIDE_STYLES.editorial.head.family);
    expect(el.style.aspectRatio).toBe("1 / 1");
    expect(el.querySelector(".ohf-slide-foot")).toHaveTextContent("@sunny");
  });

  it("switches to white text over a picture and draws the dim layer", () => {
    const { container, rerender } = render(
      <SlideFrame preset="basic" image="/p.png" dim={0.58}>
        <BodySlide title="t" body="b" />
      </SlideFrame>,
    );
    const el = container.firstChild as HTMLElement;
    expect(el).toHaveClass("ohf-slide--photo");
    expect(el.style.getPropertyValue("--sl-tx")).toBe("#ffffff");
    expect(el.style.getPropertyValue("--sl-dim")).toBe("0.58");
    expect(container.querySelector(".ohf-slide-dim")).not.toHaveClass("ohf-slide-dim--grad");
    rerender(
      <SlideFrame preset="basic" image="/p.png" dim="grad">
        <BodySlide title="t" body="b" />
      </SlideFrame>,
    );
    expect(container.querySelector(".ohf-slide-dim")).toHaveClass("ohf-slide-dim--grad");
  });

  it("has four presets", () => {
    expect(SLIDE_PRESETS).toEqual(["basic", "editorial", "impact", "soft"]);
  });
});

describe("templates", () => {
  it("render their parts", () => {
    render(
      <SlideFrame preset="basic">
        <CoverSlide kicker="가이드" title="표지" sub="부제" />
        <ListSlide title="목록" items={[{ label: "출퇴근", value: "SPF30" }, { label: "야외" }]} numbered />
        <QuoteSlide quote="인용" source="출처" />
        <CtaSlide title="CTA" pill="팔로우" />
      </SlideFrame>,
    );
    expect(screen.getByText("가이드")).toHaveClass("ohf-slide-kicker");
    expect(screen.getByRole("heading", { name: "표지" })).toHaveClass("ohf-slide-title");
    expect(screen.getAllByRole("listitem")).toHaveLength(2);
    expect(screen.getByText("01")).toHaveClass("ohf-slide-num");
    expect(screen.getByText("인용").tagName).toBe("BLOCKQUOTE");
    expect(screen.getByText("팔로우")).toHaveClass("ohf-slide-pill");
  });
});
```

Run: `corepack pnpm test src/slides`
Expected: FAIL — 모듈 없음.

- [ ] **Step 2: 프리셋과 프레임 구현**

`design/src/slides/styles.ts`:

```ts
export type SlidePreset = "basic" | "editorial" | "impact" | "soft";

export interface SlideStyle {
  bg: string;
  tx: string;
  acc: string;
  /* Ink on the accent (kicker pill). */
  accInk: string;
  head: { family: string; weight: number; letterSpacing: string; lineHeight: number };
  body: { family: string };
}

/* The showcase loads Pretendard; the studio will map --font-ohf-inter to it at
   integration. Slides state the face by name because they are exported as
   pictures, not themed by the app. */
const SANS = '"Pretendard Variable", Pretendard, "Apple SD Gothic Neo", system-ui, sans-serif';

export const SLIDE_STYLES: Record<SlidePreset, SlideStyle> = {
  basic: {
    bg: "#1d2a44",
    tx: "#ffffff",
    acc: "#ffd54a",
    accInk: "#1a1a1a",
    head: { family: SANS, weight: 800, letterSpacing: "-0.02em", lineHeight: 1.22 },
    body: { family: SANS },
  },
  editorial: {
    bg: "#f3ece0",
    tx: "#2a2320",
    acc: "#b5482f",
    accInk: "#ffffff",
    head: { family: '"Noto Serif KR", serif', weight: 700, letterSpacing: "-0.03em", lineHeight: 1.26 },
    body: { family: SANS },
  },
  impact: {
    bg: "#0f0f10",
    tx: "#ffffff",
    acc: "#ff5a3c",
    accInk: "#1a1a1a",
    head: { family: `"Black Han Sans", ${SANS}`, weight: 400, letterSpacing: "0", lineHeight: 1.18 },
    body: { family: SANS },
  },
  soft: {
    bg: "#e6efe6",
    tx: "#22332b",
    acc: "#3f7d5d",
    accInk: "#1a1a1a",
    head: { family: `"Gowun Dodum", ${SANS}`, weight: 400, letterSpacing: "-0.01em", lineHeight: 1.26 },
    body: { family: `"Gowun Dodum", ${SANS}` },
  },
};

export const SLIDE_PRESETS = Object.keys(SLIDE_STYLES) as SlidePreset[];
```

`design/src/slides/SlideFrame.tsx`:

```tsx
import type { CSSProperties, HTMLAttributes, ReactNode } from "react";

import { cx } from "@/lib/cx";
import { ratioToCss } from "@/lib/ratio";

import { SLIDE_STYLES, type SlidePreset } from "./styles";

import "./slides.scss";

export type SlideRatio = "4:5" | "3:4" | "1:1" | "9:16";
export type SlidePosition = "start" | "mid" | "end";

export interface SlideFrameProps extends HTMLAttributes<HTMLDivElement> {
  preset: SlidePreset;
  ratio?: SlideRatio;
  image?: string;
  /* A number is a flat scrim (0–1); "grad" darkens toward the bottom. */
  dim?: number | "grad";
  handle?: ReactNode;
  page?: ReactNode;
  showFooter?: boolean;
  position?: SlidePosition;
  children: ReactNode;
}

export function SlideFrame({
  preset,
  ratio = "4:5",
  image,
  dim,
  handle,
  page,
  showFooter = true,
  position = "end",
  className,
  style,
  children,
  ...rest
}: SlideFrameProps) {
  const s = SLIDE_STYLES[preset];
  /* Over a picture the type is always white: the scrim, not the preset,
     carries the contrast. */
  const vars = {
    "--sl-bg": s.bg,
    "--sl-tx": image ? "#ffffff" : s.tx,
    "--sl-acc": s.acc,
    "--sl-acc-ink": s.accInk,
    "--sl-head": s.head.family,
    "--sl-head-weight": s.head.weight,
    "--sl-head-ls": s.head.letterSpacing,
    "--sl-head-lh": s.head.lineHeight,
    "--sl-body": s.body.family,
    ...(typeof dim === "number" ? { "--sl-dim": dim } : null),
  } as CSSProperties;
  return (
    <div
      className={cx("ohf-slide", `ohf-slide--${position}`, image && "ohf-slide--photo", className)}
      data-preset={preset}
      style={{ ...vars, aspectRatio: ratioToCss(ratio, "4 / 5"), ...style }}
      {...rest}
    >
      {image && <img className="ohf-slide-img" src={image} alt="" />}
      {image && dim !== undefined && (
        <div className={cx("ohf-slide-dim", dim === "grad" && "ohf-slide-dim--grad")} aria-hidden="true" />
      )}
      <div className="ohf-slide-body">{children}</div>
      {showFooter && (handle !== undefined || page !== undefined) && (
        <div className="ohf-slide-foot">
          <span>{handle}</span>
          <span>{page}</span>
        </div>
      )}
    </div>
  );
}
```

- [ ] **Step 3: 템플릿과 SCSS 구현**

`design/src/slides/templates.tsx`:

```tsx
import type { ReactNode } from "react";

import { cx } from "@/lib/cx";

export interface CoverSlideProps {
  kicker?: ReactNode;
  title: ReactNode;
  sub?: ReactNode;
  titleSize?: "md" | "lg";
}

export function CoverSlide({ kicker, title, sub, titleSize = "lg" }: CoverSlideProps) {
  return (
    <>
      {kicker !== undefined && <span className="ohf-slide-kicker">{kicker}</span>}
      <h2 className={cx("ohf-slide-title", titleSize === "md" && "ohf-slide-title--md")}>{title}</h2>
      {sub !== undefined && <p className="ohf-slide-sub">{sub}</p>}
    </>
  );
}

export interface BodySlideProps {
  title: ReactNode;
  body: ReactNode;
}

export function BodySlide({ title, body }: BodySlideProps) {
  return (
    <>
      <h2 className="ohf-slide-h">{title}</h2>
      <p className="ohf-slide-text">{body}</p>
    </>
  );
}

export interface ListSlideProps {
  title: ReactNode;
  items: readonly { label: ReactNode; value?: ReactNode }[];
  numbered?: boolean;
}

export function ListSlide({ title, items, numbered = true }: ListSlideProps) {
  return (
    <>
      <h2 className="ohf-slide-h">{title}</h2>
      <ol className="ohf-slide-list">
        {items.map((item, i) => (
          <li key={i} className="ohf-slide-item">
            {numbered && <em className="ohf-slide-num">{String(i + 1).padStart(2, "0")}</em>}
            <span className="ohf-slide-item-label">{item.label}</span>
            {item.value !== undefined && <span className="ohf-slide-item-value">{item.value}</span>}
          </li>
        ))}
      </ol>
    </>
  );
}

export interface QuoteSlideProps {
  quote: ReactNode;
  source?: ReactNode;
}

export function QuoteSlide({ quote, source }: QuoteSlideProps) {
  return (
    <>
      <span className="ohf-slide-qmark" aria-hidden="true">
        “
      </span>
      <blockquote className="ohf-slide-quote">{quote}</blockquote>
      {source !== undefined && <p className="ohf-slide-src">{source}</p>}
    </>
  );
}

export interface CtaSlideProps {
  title: ReactNode;
  sub?: ReactNode;
  pill?: ReactNode;
}

export function CtaSlide({ title, sub, pill }: CtaSlideProps) {
  return (
    <>
      <h2 className="ohf-slide-h">{title}</h2>
      {sub !== undefined && <p className="ohf-slide-sub">{sub}</p>}
      {pill !== undefined && <span className="ohf-slide-pill">{pill}</span>}
    </>
  );
}
```

`design/src/slides/slides.scss`(cqw는 1080px 원판 기준 비율. 앱 토큰을 쓰지 않는다):

```scss
// Slides are the customer's picture, not the app's chrome: every size is a
// fraction of the slide's own width (cqw) and every colour comes from the
// preset through --sl-*, never from the app palette.
.ohf-slide {
  --sl-rule: rgba(0, 0, 0, 0.15);
  position: relative;
  overflow: hidden;
  width: 100%;
  container-type: inline-size;
  background: var(--sl-bg);
  color: var(--sl-tx);
  font-family: var(--sl-body);
  word-break: keep-all;
  overflow-wrap: break-word;

  &--photo {
    --sl-rule: rgba(255, 255, 255, 0.22);
  }
}
.ohf-slide-img {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.ohf-slide-dim {
  position: absolute;
  inset: 0;
  background: rgba(12, 18, 32, var(--sl-dim, 0.5));
  &--grad {
    background: linear-gradient(180deg, rgba(0, 0, 0, 0.05) 35%, rgba(0, 0, 0, 0.72));
  }
}
.ohf-slide-body {
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
  padding: 8cqw 8cqw 12cqw;
}
.ohf-slide--start .ohf-slide-body {
  justify-content: flex-start;
}
.ohf-slide--mid .ohf-slide-body {
  justify-content: center;
}
.ohf-slide--end .ohf-slide-body {
  justify-content: flex-end;
}

.ohf-slide-kicker {
  align-self: flex-start;
  margin-bottom: 3.2cqw;
  padding: 1.1cqw 2.8cqw;
  border-radius: 100cqw;
  background: var(--sl-acc);
  color: var(--sl-acc-ink);
  font-size: 3.4cqw;
  font-weight: 700;
}
.ohf-slide-title,
.ohf-slide-h {
  font-family: var(--sl-head);
  font-weight: var(--sl-head-weight);
  letter-spacing: var(--sl-head-ls);
  line-height: var(--sl-head-lh);
  text-wrap: balance;
}
.ohf-slide-title {
  font-size: 10.4cqw;
  &--md {
    font-size: 8.4cqw;
  }
}
.ohf-slide-h {
  font-size: 7.4cqw;
}
.ohf-slide-sub {
  margin-top: 2.6cqw;
  font-size: 4.2cqw;
  font-weight: 500;
  opacity: 0.9;
}
.ohf-slide-text {
  margin-top: 4cqw;
  font-size: 4.5cqw;
  line-height: 1.6;
  font-weight: 500;
  opacity: 0.95;
}
.ohf-slide-list {
  margin-top: 5cqw;
}
.ohf-slide-item {
  display: flex;
  align-items: baseline;
  gap: 3.4cqw;
  padding: 3.3cqw 0;
  border-top: 0.3cqw solid var(--sl-rule);
  font-size: 4.5cqw;
  font-weight: 600;
  &:last-child {
    border-bottom: 0.3cqw solid var(--sl-rule);
  }
}
.ohf-slide-num {
  font-style: normal;
  font-weight: 800;
  font-variant-numeric: tabular-nums;
  color: var(--sl-acc);
}
.ohf-slide-item-label {
  flex: 1;
  min-width: 0;
}
.ohf-slide-item-value {
  margin-left: auto;
  font-size: 3.8cqw;
  font-weight: 500;
  opacity: 0.75;
}
.ohf-slide-qmark {
  display: block;
  height: 11cqw;
  font-family: var(--sl-head);
  font-size: 22cqw;
  font-weight: 800;
  line-height: 0.7;
  color: var(--sl-acc);
}
.ohf-slide-quote {
  font-family: var(--sl-head);
  font-size: 6.8cqw;
  font-weight: 700;
  line-height: 1.4;
  letter-spacing: -0.02em;
  text-wrap: balance;
}
.ohf-slide-src {
  margin-top: 4cqw;
  font-size: 3.8cqw;
  opacity: 0.8;
}
.ohf-slide-pill {
  align-self: flex-start;
  margin-top: 6cqw;
  padding: 1.8cqw 4.4cqw;
  border: 0.4cqw solid var(--sl-acc);
  border-radius: 100cqw;
  color: var(--sl-acc);
  font-size: 4cqw;
  font-weight: 700;
}
.ohf-slide-foot {
  position: absolute;
  left: 8cqw;
  right: 8cqw;
  bottom: 5cqw;
  display: flex;
  justify-content: space-between;
  font-size: 3.1cqw;
  font-weight: 500;
  font-variant-numeric: tabular-nums;
  opacity: 0.85;
}
```

`design/src/slides/index.ts`:

```ts
export * from "./SlideFrame";
export * from "./styles";
export * from "./templates";
```

`design/src/index.ts`에 추가: `export * from "./slides";`

- [ ] **Step 4: 검증**

Run: `corepack pnpm test && corepack pnpm typecheck && corepack pnpm build`
Expected: 전부 통과. token-rules의 슬라이드 검사가 이제 실제로 돌며 통과한다(앱 색 없음, `var(--sl-*)`만).

---

