### Task 11: 쇼케이스 — 뼈대, 토큰·컴포넌트·슬라이드 섹션

**Files:**
- Modify: `design/showcase/main.tsx`
- Create: `design/showcase/App.tsx`, `design/showcase/showcase.scss`, `design/showcase/data.ts`, `design/showcase/lib/contrast.ts`, `design/showcase/lib/slide.tsx`, `design/showcase/sections/Tokens.tsx`, `design/showcase/sections/Components.tsx`, `design/showcase/sections/Slides.tsx`, `design/showcase/sections/Screens.tsx`(자리만; Task 12에서 채움)
- Test: `design/test/contrast.test.ts`

**Interfaces:**
- Consumes: 공개 API `@/index` 전부.
- Produces: 해시 라우팅(`#tokens`, `#components`, `#slides`, `#screens/<id>`); `PHOTOS`, `DECK: DeckSlide[]`, `TOPIC`, `HANDLE`, `PROJECTS`, `PACKS`, `LEDGER`, `TEMPLATES`; `renderSlide(slide, page, preset, ratio?, withImage?, extra?)`; `contrast(fg, bg): number | null`.

- [ ] **Step 1: 대비비 도우미의 실패하는 테스트**

`design/test/contrast.test.ts`:

```ts
import { describe, expect, it } from "vitest";

import { contrast } from "../showcase/lib/contrast";
import tokens from "../src/tokens/tokens.json";

describe("contrast", () => {
  it("computes WCAG contrast for hex colours and refuses anything else", () => {
    expect(contrast("#ffffff", "#000000")).toBeCloseTo(21, 0);
    expect(contrast("rgba(0,0,0,0.5)", "#000000")).toBeNull();
  });

  /* The studio's own floor: small metadata type (tx4) holds 4.5:1 on the rail. */
  it("keeps the palette's body-text floor", () => {
    expect(contrast(tokens.tx4, tokens.rail)!).toBeGreaterThanOrEqual(4.5);
    expect(contrast(tokens.tx, tokens.bg)!).toBeGreaterThanOrEqual(7);
    expect(contrast(tokens["accent-ink"], tokens.accent)!).toBeGreaterThanOrEqual(7);
  });
});
```

Run: `corepack pnpm test test/contrast.test.ts`
Expected: FAIL — 모듈 없음.

`design/showcase/lib/contrast.ts`:

```ts
function channel(c: number): number {
  const s = c / 255;
  return s <= 0.03928 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4;
}

export function luminance(hex: string): number | null {
  const m = /^#([0-9a-f]{6})$/i.exec(hex.trim());
  if (!m) return null;
  const n = parseInt(m[1]!, 16);
  return 0.2126 * channel(n >> 16) + 0.7152 * channel((n >> 8) & 255) + 0.0722 * channel(n & 255);
}

/* WCAG 2 contrast ratio. Translucent tokens have no single ratio, so null. */
export function contrast(fg: string, bg: string): number | null {
  const a = luminance(fg);
  const b = luminance(bg);
  if (a === null || b === null) return null;
  const [hi, lo] = a > b ? [a, b] : [b, a];
  return (hi + 0.05) / (lo + 0.05);
}
```

Run: `corepack pnpm test test/contrast.test.ts`
Expected: PASS (2 tests).

- [ ] **Step 2: 표본 데이터와 슬라이드 도우미**

`design/showcase/data.ts`:

```ts
import type { SlidePosition, ThumbState } from "@/index";

/* Offline stand-ins for photographs: two-tone gradients as SVG data URLs, so
   the showcase needs no network and no binary assets. */
function svgPhoto(a: string, b: string): string {
  const svg =
    `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="1000">` +
    `<defs><linearGradient id="g" x1="0" y1="0" x2="0.4" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient></defs>` +
    `<rect width="800" height="1000" fill="url(#g)"/>` +
    `<circle cx="560" cy="300" r="180" fill="${a}" opacity="0.35"/>` +
    `<circle cx="220" cy="760" r="260" fill="${b}" opacity="0.45"/></svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

export const PHOTOS = {
  sand: svgPhoto("#f3c58f", "#7a4a2a"),
  bottle: svgPhoto("#dfe6ea", "#4f6b7a"),
  tile: svgPhoto("#c9d2c0", "#405040"),
  beach: svgPhoto("#8fc7e8", "#1f4b6e"),
  sunrise: svgPhoto("#f6a65b", "#5b2a4a"),
} as const;

export type PhotoKey = keyof typeof PHOTOS;

export interface DeckSlide {
  kind: "cover" | "body" | "list" | "quote" | "cta";
  label: string;
  title: string;
  sub?: string;
  kicker?: string;
  body?: string;
  items?: { label: string; value?: string }[];
  source?: string;
  prompt: string;
  photo?: PhotoKey;
  dim?: number | "grad";
  position: SlidePosition;
}

export const TOPIC = "여름 자외선 차단제 고르는 법";
export const HANDLE = "@sunny.skin.lab";
export const TEMPLATES = ["표지", "본문", "목록", "인용", "CTA"] as const;

export const DECK: DeckSlide[] = [
  { kind: "cover", label: "표지", title: "SPF 숫자, 높을수록 좋을까?", sub: "자외선 차단제 고르는 법", kicker: "여름 피부 가이드", prompt: "한여름 해변, 강한 역광, 파라솔 그림자, 필름 톤", photo: "sand", dim: "grad", position: "end" },
  { kind: "body", label: "본문", title: "SPF와 PA는 다른 것을 막아요", body: "SPF는 피부를 태우는 UVB를, PA는 노화를 부르는 UVA를 막아요. 숫자 하나만 보고 고르면 절반만 막는 셈이에요.", prompt: "화장대 위 선크림 두 개, 부드러운 창가 빛, 얕은 심도", photo: "bottle", dim: 0.58, position: "end" },
  { kind: "list", label: "목록", title: "상황별 추천 지수", items: [{ label: "출퇴근·실내", value: "SPF30 · PA++" }, { label: "야외 활동", value: "SPF50+ · PA+++" }, { label: "물놀이", value: "워터프루프" }, { label: "민감성 피부", value: "무기자차" }], prompt: "도심 출근길, 아침 햇살, 얕은 심도", photo: "tile", dim: 0.78, position: "mid" },
  { kind: "quote", label: "인용", title: "얼마나 센 걸 바르느냐보다, 2시간마다 덧바르느냐가 핵심입니다", source: "— 피부과 전문의 인터뷰 중", prompt: "손등에 선크림을 짜는 클로즈업, 따뜻한 빛", photo: "beach", dim: 0.6, position: "mid" },
  { kind: "body", label: "본문", title: "흐린 날에도 발라야 하는 이유", body: "구름은 UVA를 거의 막지 못해요. 흐린 날의 자외선은 맑은 날의 80%까지 피부에 닿습니다.", prompt: "흐린 하늘 아래 도심 옥상, 확산광", photo: "sunrise", dim: 0.55, position: "end" },
  { kind: "body", label: "본문", title: "덧바르기, 이렇게 하면 쉬워요", body: "외출 전 15분, 그리고 2시간마다. 스틱형이나 쿠션형은 화장 위에도 덧바를 수 있어요.", prompt: "가방 속 스틱 선크림, 밝은 카페 테이블", photo: "bottle", dim: 0.55, position: "end" },
  { kind: "list", label: "목록", title: "성분표에서 확인할 것", items: [{ label: "무기자차", value: "징크옥사이드" }, { label: "유기자차", value: "아보벤존" }, { label: "혼합", value: "둘 다 표기" }], prompt: "선크림 뒷면 성분표 클로즈업, 매크로", photo: "sand", dim: 0.75, position: "mid" },
  { kind: "cta", label: "CTA", title: "저장해 두고 여름 내내 꺼내 보세요", sub: "다음 편: 선크림, 제대로 지우는 법", prompt: "", position: "mid" },
];

export function subline(s: DeckSlide): string {
  if (s.kind === "body") return s.body ?? "";
  if (s.kind === "list") return (s.items ?? []).map((i) => i.label).join(" · ");
  if (s.kind === "quote") return s.source ?? "";
  return s.sub ?? "";
}

export interface ProjectSample {
  title: string;
  meta: string;
  status: string;
  tone: "done" | "live" | "draft";
  deck: { state: ThumbState; photo?: PhotoKey }[];
}

export const PROJECTS: ProjectSample[] = [
  { title: "여름 자외선 차단제 고르는 법", meta: "카드뉴스 · 4:5 · 8장 · 12분 전", status: "3장 생성 중", tone: "live", deck: [{ state: "image", photo: "sand" }, { state: "image", photo: "bottle" }, { state: "pending" }, { state: "empty" }] },
  { title: "아침 루틴 5가지", meta: "카드뉴스 · 1:1 · 6장 · 어제", status: "내보냄", tone: "done", deck: [{ state: "image", photo: "sunrise" }, { state: "image", photo: "tile" }, { state: "image", photo: "beach" }, { state: "flat" }] },
  { title: "카페 신메뉴 소개", meta: "카드뉴스 · 4:5 · 6장 · 2일 전", status: "구성안", tone: "draft", deck: [{ state: "flat" }, { state: "empty" }, { state: "empty" }, { state: "empty" }] },
  { title: "헬스장 첫 달 가이드", meta: "카드뉴스 · 4:5 · 10장 · 지난주", status: "완성", tone: "done", deck: [{ state: "image", photo: "tile" }, { state: "image", photo: "sand" }, { state: "image", photo: "bottle" }, { state: "flat" }] },
  { title: "제주 3박 4일 코스", meta: "카드뉴스 · 4:5 · 8장 · 2주 전", status: "내보냄", tone: "done", deck: [{ state: "image", photo: "beach" }, { state: "image", photo: "sunrise" }, { state: "image", photo: "sand" }, { state: "flat" }] },
];

export const PACKS = [
  { name: "스타터", credits: "1,000", price: "₩[가격]", best: false },
  { name: "크리에이터", credits: "3,000", price: "₩[가격] · 장당 [할인율] 저렴", best: true },
  { name: "스튜디오", credits: "10,000", price: "₩[가격]", best: false },
];

export const LEDGER: { when: string; what: string; detail: string; amount: string; tone: "minus" | "plus" | "refund" }[] = [
  { when: "오늘 14:02", what: "이미지 생성 4장", detail: "여름 자외선 차단제 고르는 법 · Flux 2", amount: "16", tone: "minus" },
  { when: "오늘 14:02", what: "실패 환불", detail: "슬라이드 5 · 생성 실패", amount: "4", tone: "refund" },
  { when: "오늘 13:51", what: "구성안 생성", detail: "여름 자외선 차단제 고르는 법", amount: "1", tone: "minus" },
  { when: "어제 21:10", what: "이미지 생성 6장", detail: "아침 루틴 5가지 · Flux 2", amount: "24", tone: "minus" },
  { when: "9월 15일", what: "크레딧 충전", detail: "스타터 · 카드 결제", amount: "1,000", tone: "plus" },
  { when: "9월 12일", what: "가입 보너스", detail: "", amount: "300", tone: "plus" },
];
```

`design/showcase/lib/slide.tsx`:

```tsx
import {
  BodySlide,
  CoverSlide,
  CtaSlide,
  ListSlide,
  QuoteSlide,
  SlideFrame,
  type SlideFrameProps,
  type SlidePreset,
  type SlideRatio,
} from "@/index";

import { DECK, HANDLE, PHOTOS, type DeckSlide } from "../data";

export function renderSlide(
  s: DeckSlide,
  page: number,
  preset: SlidePreset,
  ratio: SlideRatio = "4:5",
  withImage = true,
  extra?: Partial<Omit<SlideFrameProps, "children" | "preset">>,
) {
  const image = withImage && s.photo ? PHOTOS[s.photo] : undefined;
  return (
    <SlideFrame
      preset={preset}
      ratio={ratio}
      image={image}
      dim={image ? s.dim : undefined}
      position={s.position}
      handle={HANDLE}
      page={`${page} / ${DECK.length}`}
      {...extra}
    >
      {s.kind === "cover" && <CoverSlide kicker={s.kicker} title={s.title} sub={s.sub} />}
      {s.kind === "body" && <BodySlide title={s.title} body={s.body} />}
      {s.kind === "list" && <ListSlide title={s.title} items={s.items ?? []} />}
      {s.kind === "quote" && <QuoteSlide quote={s.title} source={s.source} />}
      {s.kind === "cta" && <CtaSlide title={s.title} sub={s.sub} pill={`${HANDLE} 팔로우`} />}
    </SlideFrame>
  );
}
```

- [ ] **Step 3: 앱 뼈대와 스타일**

`design/showcase/main.tsx`(교체):

```tsx
import { createRoot } from "react-dom/client";

import "pretendard/dist/web/variable/pretendardvariable.css";
import "./showcase.scss";

import { App } from "./App";

createRoot(document.getElementById("root")!).render(<App />);
```

`design/showcase/App.tsx`:

```tsx
import { useEffect, useState, type JSX } from "react";

import { Components } from "./sections/Components";
import { Screens } from "./sections/Screens";
import { Slides } from "./sections/Slides";
import { Tokens } from "./sections/Tokens";

const SECTIONS: { id: string; label: string; view: (props: { sub?: string }) => JSX.Element }[] = [
  { id: "tokens", label: "토큰", view: Tokens },
  { id: "components", label: "컴포넌트", view: Components },
  { id: "slides", label: "슬라이드", view: Slides },
  { id: "screens", label: "화면", view: Screens },
];

function useHash() {
  const read = () => location.hash.replace(/^#/, "");
  const [hash, setHash] = useState(read);
  useEffect(() => {
    const on = () => setHash(read());
    addEventListener("hashchange", on);
    return () => removeEventListener("hashchange", on);
  }, []);
  return hash;
}

export function App() {
  const [sectionId, sub] = useHash().split("/");
  const section = SECTIONS.find((s) => s.id === sectionId) ?? SECTIONS[0]!;
  const View = section.view;
  return (
    <div className="ohf sc-app">
      <nav className="sc-nav" aria-label="목차">
        <div className="sc-nav-brand">OpenHiggsfield Design</div>
        {SECTIONS.map((s) => (
          <a key={s.id} href={`#${s.id}`} className="sc-nav-link" aria-current={s.id === section.id ? "page" : undefined}>
            {s.label}
          </a>
        ))}
      </nav>
      <main className="sc-main">
        <View sub={sub} />
      </main>
    </div>
  );
}
```

`design/showcase/showcase.scss`(쇼케이스 전용 `sc-` 클래스. `.ohf` 스코프 안에서 토큰을 쓴다):

```scss
@use "@/styles/mixins" as m;

.sc-app {
  display: grid;
  grid-template-columns: 220px minmax(0, 1fr);
  min-height: 100dvh;
}
.sc-nav {
  position: sticky;
  top: 0;
  height: 100dvh;
  display: flex;
  flex-direction: column;
  gap: 4px;
  padding: 20px 14px;
  border-right: 1px solid var(--line);
  background: var(--rail);
}
.sc-nav-brand {
  padding: 6px 10px 14px;
  font-size: var(--fs-md);
  font-weight: var(--fw-display);
  letter-spacing: var(--ls-tight);
}
.sc-nav-link {
  display: flex;
  align-items: center;
  height: var(--h-md);
  padding: 0 10px;
  border-radius: var(--radius-ctl);
  color: var(--tx2);
  font-size: var(--fs-sm);
  font-weight: var(--fw-strong);
  text-decoration: none;
  &:hover {
    background: var(--s2);
    color: var(--tx);
  }
  &[aria-current="page"] {
    background: var(--s3);
    color: var(--tx);
  }
}
.sc-main {
  min-width: 0;
  padding: 32px 36px 80px;
}
.sc-h1 {
  margin-bottom: 6px;
  font-size: var(--fs-title);
  font-weight: var(--fw-display);
  letter-spacing: var(--ls-heading);
}
.sc-lead {
  margin-bottom: 28px;
  font-size: var(--fs-md);
  color: var(--tx3);
}
.sc-section {
  margin-bottom: 40px;
}
.sc-h2 {
  margin-bottom: 4px;
  font-size: var(--fs-lg);
  font-weight: var(--fw-bold);
  letter-spacing: var(--ls-tight);
}
.sc-note {
  margin-bottom: 14px;
  font-size: var(--fs-xs);
  color: var(--tx4);
}
.sc-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
  gap: 10px;
}
.sc-swatch {
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding: 10px;
  border-radius: var(--radius-md);
  background: var(--s1);
  border: 1px solid var(--line);
}
.sc-swatch-chip {
  height: 44px;
  border-radius: var(--radius-sm);
  border: 1px solid var(--line-2);
}
.sc-swatch-name {
  font-size: var(--fs-sm);
  font-weight: var(--fw-bold);
}
.sc-swatch-value,
.sc-swatch-ratio {
  font-size: var(--fs-2xs);
  color: var(--tx3);
  word-break: break-all;
  @include m.tabular;
}
.sc-swatch-ratio {
  color: var(--tx4);
}
.sc-row {
  display: flex;
  flex-wrap: wrap;
  align-items: flex-end;
  gap: 14px;
}
.sc-spec {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 6px;
  font-size: var(--fs-2xs);
  color: var(--tx3);
  @include m.tabular;
}
.sc-box {
  background: var(--s3);
  border: 1px solid var(--line-2);
}
.sc-motion {
  width: 64px;
  height: 24px;
  border-radius: var(--radius-sm);
  background: var(--s3);
  transition-property: translate, background;
  transition-timing-function: var(--ease);
  &:hover {
    translate: 40px 0;
    background: var(--accent-32);
  }
}
.sc-matrix {
  width: 100%;
  border-collapse: separate;
  border-spacing: 0;
  th,
  td {
    padding: 10px 12px;
    text-align: left;
    vertical-align: middle;
    border-bottom: 1px solid var(--line);
  }
  th {
    font-size: var(--fs-2xs);
    font-weight: var(--fw-strong);
    color: var(--tx4);
    letter-spacing: var(--ls-caps);
    text-transform: uppercase;
  }
  td:first-child {
    font-size: var(--fs-sm);
    color: var(--tx2);
    white-space: nowrap;
  }
}
.sc-cell {
  display: flex;
  align-items: center;
  gap: 8px;
}
.sc-panel {
  padding: 16px;
  border-radius: var(--radius-lg);
  background: var(--s1);
  border: 1px solid var(--line);
}
.sc-toolbar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px;
  margin-bottom: 16px;
}
.sc-slides {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 16px;
}
.sc-slide-col {
  display: flex;
  flex-direction: column;
  gap: 8px;
  font-size: var(--fs-xs);
  color: var(--tx3);
  .ohf-slide {
    border-radius: var(--radius-md);
  }
}

/* ---- screens ---- */
.sc-frame {
  overflow: auto;
  border-radius: var(--radius-lg);
  border: 1px solid var(--line-2);
  background: var(--bg);
  box-shadow: var(--shadow-2);
}
.sc-screen {
  position: relative;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  background: var(--bg);
  color: var(--tx);
  font-size: var(--fs-md);
  line-height: 1.4;
}
.sc-page {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 20px;
  min-height: 0;
  margin: 0 auto;
  padding: 32px 20px 28px;
  overflow: auto;
}
.sc-page-head {
  display: flex;
  align-items: center;
  gap: 12px;
}
.sc-page-title {
  font-size: var(--fs-title);
  font-weight: var(--fw-display);
  letter-spacing: var(--ls-heading);
}
.sc-page-count {
  font-size: var(--fs-md);
  color: var(--tx3);
  @include m.tabular;
}
.sc-page-lead {
  margin-top: 6px;
  font-size: var(--fs-md);
  color: var(--tx3);
}
.sc-spacer {
  flex: 1 1 auto;
  min-width: 0;
}
.sc-muted {
  font-size: 12px;
  line-height: 1.5;
  color: var(--tx3);
}
.sc-label {
  font-size: var(--fs-xs);
  font-weight: var(--fw-strong);
  color: var(--tx3);
}
.sc-stack {
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.sc-row-2 {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 16px;
}
.sc-row-3 {
  display: flex;
  gap: 10px;
  > * {
    flex: 1;
    min-width: 0;
  }
}
.sc-card {
  display: flex;
  flex-direction: column;
  gap: 16px;
  padding: 20px;
  border-radius: 16px;
  background: var(--s2);
  border: 1px solid var(--line);
  box-shadow: var(--shadow-2), var(--glint);
}
.sc-cards {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 20px;
}
.sc-new-card {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 10px;
  min-height: 236px;
  border-radius: var(--radius-lg);
  border: 1px dashed var(--line-2);
  color: var(--tx3);
  text-decoration: none;
  &:hover {
    border-color: var(--tx4);
  }
}
.sc-new-card-plus {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 40px;
  height: 40px;
  border-radius: 12px;
  background: var(--s1);
  border: 1px solid var(--line);
  color: var(--tx2);
}
.sc-new-card-title {
  font-size: var(--fs-md);
  font-weight: var(--fw-strong);
  color: var(--tx2);
}
.sc-back {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  align-self: flex-start;
  font-size: var(--fs-sm);
  color: var(--tx3);
  text-decoration: none;
}
.sc-account-grid {
  display: grid;
  grid-template-columns: 320px minmax(0, 1fr);
  gap: 20px;
}
.sc-big {
  font-size: 40px;
  font-weight: var(--fw-display);
  letter-spacing: -0.02em;
  line-height: 1;
  @include m.tabular;
}
.sc-pack {
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding: 16px;
  border-radius: var(--radius-lg);
  text-align: left;
  color: var(--tx);
  background: var(--s1);
  border: 1px solid var(--line);
  &[aria-pressed="true"] {
    background: var(--accent-08);
    border-color: var(--accent-32);
  }
}
.sc-pack-credits {
  font-size: var(--fs-title);
  font-weight: var(--fw-display);
  letter-spacing: -0.01em;
  @include m.tabular;
  small {
    font-size: var(--fs-md);
    font-weight: var(--fw-medium);
    color: var(--tx3);
  }
}
.sc-table {
  overflow: hidden;
  border-radius: var(--radius-lg);
  background: var(--s1);
  border: 1px solid var(--line);
}
.sc-table-head,
.sc-table-row {
  display: grid;
  grid-template-columns: 120px minmax(0, 1fr) minmax(0, 1.2fr) 100px;
  gap: 16px;
  align-items: center;
  padding: 0 16px;
  border-bottom: 1px solid var(--line);
  font-size: var(--fs-sm);
}
.sc-table-head {
  height: 36px;
  font-size: 11px;
  font-weight: var(--fw-strong);
  color: var(--tx4);
}
.sc-table-row {
  height: 48px;
  span {
    @include m.truncate;
  }
}
.sc-right {
  text-align: right;
}
.sc-amount {
  font-weight: var(--fw-bold);
  @include m.tabular;
  &--plus {
    color: var(--accent);
  }
  &--refund {
    color: var(--tx2);
  }
}
.sc-editor {
  display: flex;
  flex: 1;
  min-height: 0;
  .ohf-canvas {
    width: 634px;
  }
}
.sc-editor-left {
  display: flex;
  flex-direction: column;
  width: 806px;
  min-height: 0;
  border-right: 1px solid var(--line);
}
.sc-editor-brief {
  flex-shrink: 0;
  padding: 12px 20px 10px;
}
.sc-editor-rows {
  flex: 1;
  min-height: 0;
  overflow: hidden;
}
.sc-lamp {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--accent);
  flex-shrink: 0;
}
.sc-overlay-pop {
  position: absolute;
  top: 112px;
  right: 20px;
  width: 400px;
}
.sc-scrim {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(0, 0, 0, 0.62);
}
.sc-style-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 8px;
}
.sc-swatch-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  flex: 1;
  height: var(--h-lg);
  padding: 0 10px 0 8px;
  border-radius: var(--radius-ctl);
  border: 1px solid var(--line-2);
  color: var(--tx2);
  font-size: 12px;
  @include m.tabular;
  > i {
    width: 20px;
    height: 20px;
    border-radius: var(--radius-sm);
    border: 1px solid rgba(255, 255, 255, 0.15);
  }
}
.sc-hashtags {
  padding: 10px 12px;
  border-radius: var(--radius-ctl);
  background: var(--s1);
  border: 1px solid var(--line);
  font-size: var(--fs-sm);
  line-height: 1.6;
  color: var(--tx2);
}
.sc-stat {
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding: 12px;
  border-radius: var(--radius-ctl);
  background: var(--s1);
  border: 1px solid var(--line);
  &--danger {
    background: var(--danger-bg);
    border-color: var(--danger-line);
    color: var(--danger);
  }
  b {
    font-size: 18px;
    font-weight: var(--fw-display);
    @include m.tabular;
  }
}
.sc-phone-head,
.sc-phone-actions,
.sc-phone-foot {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-shrink: 0;
  padding: 0 14px;
}
.sc-phone-head {
  height: 54px;
}
.sc-phone-actions {
  height: 46px;
  gap: 14px;
}
.sc-phone-caption {
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding: 0 14px;
  font-size: var(--fs-md);
  line-height: 1.45;
}
.sc-phone-foot {
  justify-content: space-between;
  height: 56px;
  padding-bottom: 8px;
  border-top: 1px solid var(--line);
}
.sc-dots {
  flex: 1;
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 4px;
  > i {
    width: 5px;
    height: 5px;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.35);
    &:first-child {
      width: 6px;
      height: 6px;
      background: var(--tx);
    }
  }
}
.sc-badge {
  position: absolute;
  top: 12px;
  right: 12px;
  padding: 3px 8px;
  border-radius: var(--radius-pill);
  background: rgba(0, 0, 0, 0.6);
  color: #ffffff;
  font-size: 11px;
  font-weight: var(--fw-bold);
  @include m.tabular;
}
.sc-cols {
  display: flex;
  gap: 24px;
  > * {
    flex: 1;
    min-width: 0;
  }
}
.sc-col {
  display: flex;
  flex-direction: column;
  gap: 12px;
  .ohf-slide {
    border-radius: var(--radius-ctl);
  }
}
.sc-style-col {
  display: flex;
  flex-direction: column;
  gap: 12px;
  padding: 12px;
  border-radius: var(--radius-lg);
  background: var(--s1);
  border: 1px solid var(--line);
  &[data-default="true"] {
    border-color: var(--accent-32);
  }
  .ohf-slide {
    border-radius: var(--radius-md);
  }
}
.sc-style-pair {
  display: flex;
  gap: 12px;
  > * {
    flex: 1;
    min-width: 0;
  }
}
.sc-chips {
  display: flex;
  gap: 4px;
  > i {
    width: 14px;
    height: 14px;
    border-radius: var(--radius-xs);
    border: 1px solid rgba(255, 255, 255, 0.15);
  }
}
```

`design/showcase/sections/Screens.tsx`(자리. Task 12에서 교체):

```tsx
export function Screens() {
  return <h1 className="sc-h1">화면</h1>;
}
```

- [ ] **Step 4: 토큰 섹션**

`design/showcase/sections/Tokens.tsx`:

```tsx
import { tokens, type Token } from "@/index";

import { contrast } from "../lib/contrast";

const entries = Object.entries(tokens) as [Token, string][];
const pick = (re: RegExp) => entries.filter(([k]) => re.test(k));
const colors = entries.filter(([k]) => !/^(radius|h|fs|fw|ls|sp|dur|shadow)-/.test(k) && !["glint", "ease", "ease-slide", "font-ui"].includes(k));
const SAMPLE = "여름 자외선 차단제 고르는 법 · Sunscreen 0123";

export function Tokens() {
  return (
    <>
      <h1 className="sc-h1">토큰</h1>
      <p className="sc-lead">tokens.json에서 그린다. 기존 31개는 원본 값 그대로, 40개는 스튜디오의 리터럴에서 뽑았다.</p>

      <section className="sc-section">
        <h2 className="sc-h2">색</h2>
        <p className="sc-note">글자색은 --bg 위 대비비, 표면색은 그 위에 놓인 --tx의 대비비. 반투명 값은 비율을 적지 않는다.</p>
        <div className="sc-grid">
          {colors.map(([k, v]) => {
            const isText = /^(tx|accent$|accent-strong$|danger$)/.test(k);
            const ratio = isText ? contrast(v, tokens.bg) : contrast(tokens.tx, v);
            return (
              <div key={k} className="sc-swatch">
                <div className="sc-swatch-chip" style={{ background: v }} />
                <div className="sc-swatch-name">--{k}</div>
                <div className="sc-swatch-value">{v}</div>
                {ratio !== null && <div className="sc-swatch-ratio">{ratio.toFixed(2)}:1</div>}
              </div>
            );
          })}
        </div>
      </section>

      <section className="sc-section">
        <h2 className="sc-h2">반지름</h2>
        <div className="sc-row">
          {pick(/^radius-/).map(([k, v]) => (
            <div key={k} className="sc-spec">
              <div className="sc-box" style={{ width: 64, height: 48, borderRadius: v }} />
              <span>{k.slice(7)} · {v}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="sc-section">
        <h2 className="sc-h2">컨트롤 높이</h2>
        <div className="sc-row">
          {pick(/^h-/).map(([k, v]) => (
            <div key={k} className="sc-spec">
              <div className="sc-box" style={{ width: 96, height: v, borderRadius: "var(--radius-ctl)" }} />
              <span>{k.slice(2)} · {v}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="sc-section">
        <h2 className="sc-h2">글자 크기</h2>
        {pick(/^fs-/).map(([k, v]) => (
          <div key={k} className="sc-cell" style={{ marginBottom: 8 }}>
            <span className="sc-spec" style={{ width: 110, alignItems: "flex-start" }}>{k.slice(3)} · {v}</span>
            <span style={{ fontSize: v }}>{SAMPLE}</span>
          </div>
        ))}
      </section>

      <section className="sc-section">
        <h2 className="sc-h2">굵기와 자간</h2>
        {pick(/^fw-/).map(([k, v]) => (
          <div key={k} className="sc-cell" style={{ marginBottom: 8 }}>
            <span className="sc-spec" style={{ width: 110, alignItems: "flex-start" }}>{k.slice(3)} · {v}</span>
            <span style={{ fontWeight: v }}>{SAMPLE}</span>
          </div>
        ))}
        {pick(/^ls-/).map(([k, v]) => (
          <div key={k} className="sc-cell" style={{ marginBottom: 8 }}>
            <span className="sc-spec" style={{ width: 110, alignItems: "flex-start" }}>{k.slice(3)} · {v}</span>
            <span style={{ letterSpacing: v, textTransform: k === "ls-caps" ? "uppercase" : undefined }}>{SAMPLE}</span>
          </div>
        ))}
      </section>

      <section className="sc-section">
        <h2 className="sc-h2">간격</h2>
        <div className="sc-row">
          {pick(/^sp-/).map(([k, v]) => (
            <div key={k} className="sc-spec">
              <div className="sc-box" style={{ width: v, height: 24, background: "var(--accent-32)" }} />
              <span>{k.slice(3)} · {v}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="sc-section">
        <h2 className="sc-h2">그림자</h2>
        <div className="sc-row">
          {[...pick(/^shadow-/), ["glint", tokens.glint] as [Token, string]].map(([k, v]) => (
            <div key={k} className="sc-spec">
              <div style={{ width: 120, height: 72, borderRadius: "var(--radius-lg)", background: "var(--s2)", boxShadow: v }} />
              <span>{k}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="sc-section">
        <h2 className="sc-h2">모션</h2>
        <p className="sc-note">
          마우스를 올리면 각 지속 시간으로 움직인다. ease {tokens.ease} · ease-slide {tokens["ease-slide"]}
        </p>
        <div className="sc-row">
          {pick(/^dur-/).map(([k, v]) => (
            <div key={k} className="sc-spec">
              <div className="sc-motion" style={{ transitionDuration: v }} />
              <span>{k.slice(4)} · {v}</span>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
```

- [ ] **Step 5: 컴포넌트 섹션(상태 매트릭스)**

`design/showcase/sections/Components.tsx`:

```tsx
import { useState, type ReactNode } from "react";

import {
  Alert,
  Avatar,
  Button,
  Chip,
  CreditBadge,
  Dialog,
  Field,
  IconButton,
  Input,
  Kbd,
  Menu,
  MenuRow,
  OptionList,
  Pill,
  Popover,
  Segment,
  Skeleton,
  Slider,
  Spinner,
  Stepper,
  Switch,
  Tag,
  Textarea,
  Thumb,
  Tooltip,
  UndoBar,
  type ButtonSize,
  type ButtonVariant,
  type ThumbState,
} from "@/index";
import { ClockIcon, CopyIcon, DownloadIcon, FilmIcon, RetryIcon, SparkleIcon, TrashIcon } from "@/index";

import { PHOTOS } from "../data";

type State = "default" | "hover" | "active" | "disabled";
const STATES: State[] = ["default", "hover", "active", "disabled"];
/* Pins a state for the matrix: the SCSS pairs every :hover/:active with the
   same data-state attribute. */
const st = (s: State) => ({ "data-state": s === "default" ? undefined : s, disabled: s === "disabled" });

function Matrix({ title, note, cols, rows, cell }: { title: string; note?: string; cols: readonly string[]; rows: readonly string[]; cell: (row: string, col: string) => ReactNode }) {
  return (
    <section className="sc-section">
      <h2 className="sc-h2">{title}</h2>
      {note && <p className="sc-note">{note}</p>}
      <table className="sc-matrix">
        <thead>
          <tr>
            <th />
            {cols.map((c) => (
              <th key={c}>{c}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r}>
              <td>{r}</td>
              {cols.map((c) => (
                <td key={c}>
                  <div className="sc-cell">{cell(r, c)}</div>
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </section>
  );
}

function SegmentDemo({ size, plate }: { size: "sm" | "md"; plate: boolean }) {
  const [v, setV] = useState("projects");
  return (
    <Segment
      size={size}
      plate={plate}
      items={[{ id: "studio", label: "Studio" }, { id: "projects", label: "Projects" }, { id: "assets", label: "Assets" }]}
      value={v}
      onChange={setV}
      aria-label="구역"
    />
  );
}

function StepperDemo({ start }: { start: number }) {
  const [v, setV] = useState(start);
  return <Stepper value={v} min={4} max={10} onChange={setV} suffix="장" decrementLabel="한 장 줄이기" incrementLabel="한 장 늘리기" />;
}

function SwitchDemo({ on, disabled }: { on: boolean; disabled?: boolean }) {
  const [v, setV] = useState(on);
  return <Switch checked={v} onChange={setV} disabled={disabled} aria-label="쪽 번호 표시" />;
}

function SliderDemo({ start }: { start: number }) {
  const [v, setV] = useState(start);
  return (
    <div style={{ width: 200 }}>
      <Slider min={0} max={100} value={v} onChange={setV} aria-label="어둡게" />
    </div>
  );
}

function OptionsDemo() {
  const [v, setV] = useState("4:5");
  return (
    <div style={{ width: 200, height: 160, display: "flex" }}>
      <OptionList options={[{ value: "auto", label: "Auto" }, { value: "1:1", label: "1:1" }, { value: "4:5", label: "4:5" }, { value: "9:16", label: "9:16" }]} value={v} onChange={setV} ratio />
    </div>
  );
}

export function Components() {
  return (
    <>
      <h1 className="sc-h1">컴포넌트</h1>
      <p className="sc-lead">변형 × 상태. hover/active/disabled는 data-state로 고정했다. 문구는 모두 props다.</p>

      <Matrix
        title="Button"
        note="한 화면에 라임(primary)은 하나. busy는 생성 중, loading은 컨트롤 자신의 대기."
        cols={STATES}
        rows={["primary", "secondary", "model", "ghost", "danger", "busy", "loading"]}
        cell={(r, c) => {
          if (r === "busy") return c === "default" ? <Button variant="primary" busy icon={<SparkleIcon />}>7장 생성 중</Button> : null;
          if (r === "loading") return c === "default" ? <Button loading>저장</Button> : null;
          return (
            <Button variant={r as ButtonVariant} icon={<SparkleIcon />} kbd={r === "primary" ? "⌘↵" : undefined} {...st(c as State)}>
              {r === "primary" ? "7장 생성 · 28 크레딧" : "슬라이드 추가"}
            </Button>
          );
        }}
      />
      <Matrix
        title="Button · 크기"
        cols={["sm 32", "md 36", "lg 38"]}
        rows={["secondary", "primary"]}
        cell={(r, c) => (
          <Button variant={r as ButtonVariant} size={c.slice(0, 2) as ButtonSize} icon={<DownloadIcon />}>
            내보내기
          </Button>
        )}
      />
      <Matrix
        title="IconButton"
        cols={STATES}
        rows={["plate 30", "plate 36", "ghost 28"]}
        cell={(r, c) => (
          <IconButton icon={<CopyIcon />} aria-label="복제" size={Number(r.split(" ")[1]) as 28 | 30 | 36} ghost={r.startsWith("ghost")} {...st(c as State)} />
        )}
      />
      <Matrix
        title="Chip"
        cols={STATES}
        rows={["기본", "pressed", "dot", "ratio"]}
        cell={(r, c) => (
          <Chip pressed={r === "pressed" ? true : r === "기본" ? undefined : false} dot={r === "dot"} ratio={r === "ratio" ? "4:5" : undefined} {...st(c as State)}>
            {r === "ratio" ? "피드 4:5" : r === "dot" ? "생성 중" : "카드뉴스"}
          </Chip>
        )}
      />
      <Matrix
        title="Pill"
        cols={STATES}
        rows={["glyph + label", "expanded"]}
        cell={(r, c) => <Pill glyph={<FilmIcon />} label="장수" value="8" expanded={r === "expanded" ? true : undefined} {...st(c as State)} />}
      />
      <Matrix
        title="Segment"
        note="선택 판은 실제 폭을 재서 움직인다."
        cols={["interactive"]}
        rows={["md", "sm + plate"]}
        cell={(r) => <SegmentDemo size={r === "md" ? "md" : "sm"} plate={r !== "md"} />}
      />
      <Matrix title="Tag" cols={["default", "accent", "muted"]} rows={["tone"]} cell={(_, c) => <Tag tone={c as "default" | "accent" | "muted"}>{c === "accent" ? "기본값" : c === "muted" ? "준비 중" : "카드뉴스"}</Tag>} />
      <Matrix
        title="Field · Input · Textarea"
        cols={["default", "focus", "invalid", "disabled"]}
        rows={["input", "textarea", "counter", "error"]}
        cell={(r, c) => {
          const state = c === "focus" ? { "data-state": "focus" } : {};
          const common = { invalid: c === "invalid", disabled: c === "disabled", ...state };
          if (r === "textarea") return <div style={{ width: 240 }}><Field label="꼭 넣을 내용" optional="선택"><Textarea rows={2} defaultValue="2시간마다 덧바르기" {...common} /></Field></div>;
          if (r === "counter") return <div style={{ width: 240 }}><Field label="본문" counter={{ value: c === "invalid" ? 96 : 42, max: 90 }}><Input defaultValue="흐린 날에도 발라야 하는 이유" {...common} /></Field></div>;
          if (r === "error") return <div style={{ width: 240 }}><Field label="주제" required="필수" error={c === "invalid" ? "주제를 입력하세요" : undefined} hint="한 줄이면 됩니다"><Input placeholder="여름철 자외선 차단제 고르는 법" {...common} /></Field></div>;
          return <div style={{ width: 240 }}><Field label="대상 독자"><Input defaultValue="20대 직장인" {...common} /></Field></div>;
        }}
      />
      <Matrix title="Stepper" cols={["min", "mid", "max"]} rows={["4–10"]} cell={(_, c) => <StepperDemo start={c === "min" ? 4 : c === "max" ? 10 : 8} />} />
      <Matrix title="Switch" cols={["off", "on", "disabled"]} rows={["role=switch"]} cell={(_, c) => <SwitchDemo on={c !== "off"} disabled={c === "disabled"} />} />
      <Matrix title="Slider" cols={["0", "40", "100"]} rows={["--fill"]} cell={(_, c) => <SliderDemo start={Number(c)} />} />
      <Matrix title="OptionList" cols={["ratio"]} rows={["aria-pressed"]} cell={() => <OptionsDemo />} />
      <Matrix title="Avatar" cols={["28", "32", "44"]} rows={["initials"]} cell={(_, c) => <Avatar initials="BK" size={Number(c) as 28 | 32 | 44} />} />
      <Matrix title="CreditBadge" cols={["default"]} rows={["amount"]} cell={() => <CreditBadge amount={1240} unit="크레딧" />} />
      <Matrix title="Kbd · Spinner" cols={["default"]} rows={["kbd", "spinner"]} cell={(r) => (r === "kbd" ? <Kbd>⌘↵</Kbd> : <Spinner label="생성 중" />)} />
      <Matrix
        title="Skeleton"
        cols={["label + clock"]}
        rows={["4:5"]}
        cell={() => (
          <div style={{ width: 160 }}>
            <Skeleton label="생성 중" clock="0:42" ratio="4:5" />
          </div>
        )}
      />
      <Matrix
        title="Thumb"
        cols={["image", "pending", "failed", "empty", "flat"]}
        rows={["56", "80"]}
        cell={(r, c) => <Thumb state={c as ThumbState} src={PHOTOS.sand} size={Number(r)} />}
      />
      <Matrix
        title="Popover · Menu"
        note="placement=static으로 흐름 안에 그렸다."
        cols={["setting", "list", "menu"]}
        rows={["variant"]}
        cell={(_, c) => {
          if (c === "setting")
            return (
              <Popover variant="setting" placement="static">
                <Field label="어둡게" value="40%">
                  <SliderDemo start={40} />
                </Field>
              </Popover>
            );
          if (c === "list")
            return (
              <Popover variant="list" placement="static" style={{ height: 220 }}>
                <Field label="비율">
                  <OptionsDemo />
                </Field>
              </Popover>
            );
          return (
            <Popover variant="menu" placement="static" head="정렬">
              <Menu>
                <MenuRow icon={<ClockIcon />} label="최근 수정" count={5} />
                <MenuRow icon={<SparkleIcon />} label="최근 생성" />
                <MenuRow icon={<TrashIcon />} label="휴지통" disabled />
              </Menu>
            </Popover>
          );
        }}
      />
      <Matrix
        title="Dialog"
        note="inline: 페이지를 덮지 않고 패널만 그린다."
        cols={["inline"]}
        rows={["width 420"]}
        cell={() => (
          <Dialog open inline title="내보내기" onClose={() => {}} closeLabel="닫기" width={420} head={<span className="sc-muted">8장 · 1080×1350</span>}>
            <p className="sc-muted">01.png ~ 08.png와 caption.txt를 ZIP으로 묶습니다.</p>
            <div className="sc-cell">
              <Button icon={<CopyIcon />}>캡션 복사</Button>
              <Button variant="primary" icon={<DownloadIcon />}>ZIP 내려받기</Button>
            </div>
          </Dialog>
        )}
      />
      <Matrix
        title="Alert · UndoBar"
        cols={["default"]}
        rows={["alert", "alert + action", "undo"]}
        cell={(r) => (
          <div style={{ width: 520 }}>
            {r === "alert" && <Alert>생성에 실패했습니다 · 4 크레딧을 돌려드렸습니다</Alert>}
            {r === "alert + action" && <Alert action={<Button size="sm" icon={<RetryIcon />}>다시 시도</Button>}>슬라이드 5 생성 실패</Alert>}
            {r === "undo" && <UndoBar text="슬라이드 5를 지웠습니다" actionLabel="되돌리기" onAction={() => {}} durationMs={6000} />}
          </div>
        )}
      />
      <Matrix
        title="Tooltip"
        note="hover를 고정해 세 정렬을 보여 준다."
        cols={["center", "start", "end"]}
        rows={["data-tip"]}
        cell={(_, c) => (
          <div style={{ paddingTop: 36 }}>
            <Tooltip label="이 슬라이드 다시 쓰기" align={c === "center" ? undefined : (c as "start" | "end")} data-state="hover">
              <IconButton icon={<SparkleIcon />} aria-label="이 슬라이드 다시 쓰기" ghost size={28} />
            </Tooltip>
          </div>
        )}
      />
    </>
  );
}
```

- [ ] **Step 6: 슬라이드 섹션**

`design/showcase/sections/Slides.tsx`:

```tsx
import { useState } from "react";

import { SLIDE_PRESETS, Segment, Switch, type SlideRatio } from "@/index";

import { DECK } from "../data";
import { renderSlide } from "../lib/slide";

const RATIOS: SlideRatio[] = ["4:5", "3:4", "1:1", "9:16"];
const DIMS = ["0", "40", "75"] as const;
/* One slide per template: cover, body, list, quote, cta. */
const SAMPLES = [0, 1, 2, 3, 7];

export function Slides() {
  const [ratio, setRatio] = useState<SlideRatio>("4:5");
  const [dim, setDim] = useState<(typeof DIMS)[number]>("40");
  const [photo, setPhoto] = useState(true);
  return (
    <>
      <h1 className="sc-h1">슬라이드</h1>
      <p className="sc-lead">템플릿 5 × 프리셋 4. 글자는 cqw로 잰다. 앱 토큰을 쓰지 않는다.</p>
      <div className="sc-toolbar">
        <Segment size="sm" plate items={RATIOS.map((r) => ({ id: r, label: r }))} value={ratio} onChange={(v) => setRatio(v as SlideRatio)} aria-label="비율" />
        <Segment size="sm" plate items={DIMS.map((d) => ({ id: d, label: `어둡게 ${d}` }))} value={dim} onChange={(v) => setDim(v as (typeof DIMS)[number])} aria-label="어둡게" />
        <span className="sc-cell">
          <Switch checked={photo} onChange={setPhoto} aria-label="사진 위" />
          <span className="sc-muted">사진 위</span>
        </span>
      </div>
      {SAMPLES.map((i) => (
        <section key={i} className="sc-section">
          <h2 className="sc-h2">{DECK[i]!.label}</h2>
          <div className="sc-slides">
            {SLIDE_PRESETS.map((preset) => (
              <div key={preset} className="sc-slide-col">
                {renderSlide(DECK[i]!, i + 1, preset, ratio, photo, { dim: photo ? Number(dim) / 100 : undefined })}
                <span>{preset}</span>
              </div>
            ))}
          </div>
        </section>
      ))}
    </>
  );
}
```

- [ ] **Step 7: 검증**

Run: `corepack pnpm test && corepack pnpm typecheck && corepack pnpm build:showcase`
Expected: 전부 통과, `dist-showcase/` 생성.

Run: `corepack pnpm dev`(백그라운드) 후 브라우저로 `http://localhost:5173/#tokens`, `#components`, `#slides`를 연다.
Expected: 왼쪽 목차, 오른쪽 내용. 토큰 견본에 대비비, 컴포넌트 매트릭스의 hover 열이 hover 색으로 고정, 슬라이드 격자 20장. 콘솔 오류 없음. 확인 후 서버를 끈다. (브라우저를 쓸 수 없는 실행자는 이 단계를 건너뛰고 보고에 적는다. 검토자가 대신 본다.)

---

