# Task 9 review — 슬라이드 층 (SlideFrame, 4 style presets, 5 templates)

### Spec Compliance

✅ Spec compliant. All six brief files exist with the exact content the brief specified, `src/index.ts` gained the one required `export * from "./slides";` line (index.ts:30), and `README.md` gained the `position`-ownership note the brief's Interfaces section explicitly asked for (task-9-brief.md:11 → README.md new "## 슬라이드" section). No file in the brief's Files list is missing a hunk.

- `styles.ts` — `SlidePreset`, `SlideStyle`, `SLIDE_STYLES` (4 presets: basic/editorial/impact/soft, all fields present: bg/tx/acc/accInk/head/body), `SLIDE_PRESETS` derived via `Object.keys` → verified order `["basic","editorial","impact","soft"]` matches insertion order and the test's expectation (styles.ts:112-147; test at slides.test.tsx:62-64).
- `SlideFrame.tsx` — renders `.ohf-slide[data-preset]`, sets all ten `--sl-*` vars the brief's Interfaces section lists (`--sl-bg --sl-tx --sl-acc --sl-acc-ink --sl-head --sl-head-weight --sl-head-ls --sl-head-lh --sl-body --sl-dim`), uses `ratioToCss(ratio, "4 / 5")` for `aspect-ratio`, defaults `position="end"`, `showFooter=true`, forces white text over a photo (SlideFrame.tsx:96-105, 178-227). Confirmed against `src/lib/ratio.ts`'s actual signature (`ratioToCss(value, fallback)`, regex `^(\d+):(\d+)$`) and `src/lib/cx.ts` (`cx(...parts)` filters falsy) — both match the calls made here.
- `templates.tsx` — `CoverSlide`, `BodySlide`, `ListSlide`, `QuoteSlide`, `CtaSlide`, no hardcoded copy except a decorative glyph (see Minor #1), all text arrives via props (templates.tsx:239-325).
- `slides.scss` — sizes only in `cqw` (no app tokens/px literals for typographic scale), colors only via `var(--sl-*)` plus locally-scoped `--sl-rule`. Manually traced every declaration in the file against `token-rules.test.ts`'s `slideViolations` check (its actual t9 logic, read from `test/token-rules.test.ts:80-90`) and against `src/tokens/tokens.json`'s real 40 token values: no declaration's value contains a COLORS/SHADOWS token substring, and every `var(--...)` reference (`--sl-bg`, `--sl-tx`, `--sl-acc`, `--sl-acc-ink`, `--sl-head*`, `--sl-body`, `--sl-dim`, `--sl-rule`) is `sl-`-prefixed. This confirms the report's claim rather than just trusting it.
- `index.ts` — re-exports `SlideFrame`, `styles`, `templates` in one line each, matching the brief verbatim.
- `slides.test.tsx` — brief's test code used verbatim; traced all four `it` blocks by hand against the implementation (footer text-content substring match, `--sl-dim` string coercion via `typeof dim === "number"` correctly handling `dim === 0`, `.ohf-slide-dim--grad` cascade winning over the base rule via source-order tiebreak at equal specificity, multi-template render with unambiguous `getByRole`/`getByText` queries) — every assertion holds given the shipped code.

No ⚠️ items — everything the brief specifies is self-contained in this diff and directly checkable.

### Strengths

- Faithful, verifiable port of the brief's code with no unrequested deviations; the one documented deviation (`position` living on `SlideFrame`, not the templates) is exactly what the brief itself instructed to record in the README (task-9-brief.md:11).
- Correct handling of the `dim={0}` edge case: `typeof dim === "number"` (not a truthiness check) so a falsy-but-valid `0` scrim still sets `--sl-dim` (SlideFrame.tsx:205).
- Footer only renders when there's something to show (`handle !== undefined || page !== undefined` gate, SlideFrame.tsx:219) — avoids an empty `.ohf-slide-foot` in the common case where neither is passed.
- `slides.scss` cleanly respects the plan's "slides are the customer's picture" isolation: no app color/shadow value appears anywhere, confirmed by hand against the actual `tokens.json`, not just by trusting the report.

### Issues

#### Critical (Must Fix)
None.

#### Important (Should Fix)
None.

#### Minor (Nice to Have)

1. **`templates.tsx:301-303`** — `QuoteSlide` embeds a literal curly-quote glyph (`“`) directly in JSX rather than receiving it as a prop, which a strict reading of plan-header's "컴포넌트에 문구를 넣지 않는다. 모든 글자는 props." conflicts with. In practice it's `aria-hidden="true"` decorative punctuation (not localizable content, no other component in this diff embeds literal text this way — compare `Pill.tsx`'s `CaretDownIcon` used for its decorative glyph instead of a character). This is plan-mandated: the brief's Step 3 code (task-9-brief.md:300-303) is exactly what shipped. Low practical risk; flagging for awareness rather than blocking.
2. **`templates.tsx:264, 279, 319`** — `<h2 className="ohf-slide-h">{title}</h2>` is repeated identically in `BodySlide`, `ListSlide`, and `CtaSlide`. Single-line, plan-mandated (brief ships the same triplication), not worth a shared abstraction at this size.
3. **`slides.test.tsx`** only exercises the `basic` and `editorial` presets directly (bg/head assertions); `impact` and `soft` are covered solely by the `SLIDE_PRESETS` array-equality check, not by rendering. Brief-mandated test set — flagging so a later showcase task visually confirms the other two presets' distinct tokens actually render as intended.

### Assessment

**Task quality:** Approved

**Reasoning:** Every brief file and interface is present and correct, the slide-scoped token isolation was independently re-derived from the real `tokens.json` and `token-rules.test.ts` rather than taken on faith, and the test file's assertions were traced by hand against the shipped implementation with no discrepancies found. The only findings are Minor and plan-mandated.
