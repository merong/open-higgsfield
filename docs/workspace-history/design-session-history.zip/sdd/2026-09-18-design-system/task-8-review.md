# Task 8 Review — 기본 요소 3묶음 (Skeleton, Thumb, Popover/Menu/MenuRow, Dialog, Alert, UndoBar, Tooltip)

### Spec Compliance

❌ Issues found: the plan-header.md 공통 규약 "상태 고정" global constraint ("모든 인터랙티브 컴포넌트는 `:hover`와
`[data-state="hover"]`, `:active`와 `[data-state="active"]`를 같은 규칙으로 묶는다", plan-header.md:34) is not met
for `UndoBar`'s own action button — see Important #1 below. This is the same class of gap Task 7's review
already flagged for OptionList/Slider (task-7-review.md:36) and the controller "parked."

Everything else verified correct against `task-8-brief.md` Steps 1–6, file by file:
- All 7 component folders created exactly where specified (`t8/src/components/{Skeleton,Thumb,Popover,Dialog,Alert,UndoBar,Tooltip}/`), with the brief's scss-exception list honored precisely: `Skeleton`, `Alert`, `UndoBar` ship no `.scss` (the diff's "Files changed" list confirms exactly 4 `.scss` files — Thumb, Popover, Dialog, Tooltip — not 7).
- Every component's props/produced-class contract matches the brief's "Produces" list verbatim: `Skeleton`→`[role=status].ohf-skeleton`, `Thumb`→`.ohf-frame.ohf-frame--<state>`, `Popover`→`.ohf-popover.ohf-popover--<variant>` (+`Menu`→`[role=menu].ohf-menu`, `MenuRow`→`[role=menuitem].ohf-menu-row`), `Dialog`→`<dialog>`+`.ohf-dialog-panel`, `Alert`→`[role=alert].ohf-alert`, `UndoBar`→`.ohf-undo`, `Tooltip`→`.ohf-tip[data-tip]`.
- All 7 `.tsx`/`.scss` files are byte-for-byte identical to the brief's literal code (line-by-line diffed against `task-8-brief.md` for the three most complex files — `Dialog.tsx`, `Popover.tsx`, `Thumb.tsx` — plus manual read of the rest; no drift found).
- `src/index.ts` (diff lines 696–728) adds exactly the 7 export lines from Step 6, correctly merged alphabetically into the existing Task 1–7 list (`Alert` before `Avatar`, `Dialog` after `CreditBadge`, `Popover` after `Pill`, `Skeleton` after `Segment`, `Thumb`/`Tooltip`/`UndoBar` after `Textarea`).
- `Consumes` list honored: `cx`/`ratioToCss` (Skeleton, Thumb), `IconButton`/`CloseIcon` (Dialog), `WarningIcon` (Thumb, Alert), `UndoIcon` (UndoBar) — all imported and used exactly as named, no unused imports (consistent with `tsc --noEmit` passing per the report).
- Native-element/ARIA rule (plan-header.md "진짜 요소를 쓴다") honored: `<dialog>` for the modal path, `role="dialog"`+`aria-labelledby` for the inline path, `role="status"` (Skeleton, UndoBar), `role="alert"` (Alert), `role="menu"`/`role="menuitem"` (Menu/MenuRow), real `<button>` everywhere a control is drawn.
- `ref` is a plain destructurable prop on `Popover`/`MenuRow` (React 19 convention), never a `forwardRef` — matches plan-header.md:23.
- Studio class-reuse rule honored: `ohf-popover(--setting/--list/--picker/--menu/--assets)`, `ohf-pop-head`, `ohf-menu(-row/-ic/-label/-count)`, `ohf-dialog-panel`, `ohf-alert(-ic/-text)`, `ohf-undo(-drain/-text/-act)`, `ohf-tip(--start/--end)`, `ohf-skeleton(-label/-clock)` are all consumed as-is; only `ohf-frame` (Thumb) is a wholly new class, and it's on plan-header's pre-cleared "not in studio" list (plan-header.md:30).
- Token-literal ban: audited every literal numeric value in the 4 new `.scss` files (`Thumb.scss`, `Popover.scss`, `Dialog.scss`, `Tooltip.scss`) against `_maps.scss`'s `$radius`/`$height`/`$font-size`/`$font-weight`/`$letter-spacing`/`$duration` maps — none collide with a banned value (`Thumb.scss` border-radius 5px, `Dialog.scss` font-size 16px/letter-spacing -0.02em, etc. are all genuinely outside the token sets, mirroring the studio's own convention of one-off values like `_tooltips.scss`'s `letter-spacing: -0.003em`). All colors are `var()` except `Thumb.scss:70`'s `rgba(255, 255, 255, 0.85)`, which is a new decorative value that doesn't duplicate any of the 31 tokens' literal values (verified against `_maps.scss`) and matches the same already-accepted pattern in `Button.scss:44,49-50` and `Segment.scss:21` from earlier tasks — not a violation, see Minor #1 for the report's imprecise claim about this.
- Diff touches exactly the 26 files the brief's batch implies (7 components × {tsx,test.tsx,index.ts,+scss where applicable} + `src/index.ts`), nothing else — no studio partials, no earlier task's components touched.
- Test-count arithmetic checks out against the ledger: Task 7 finished at 56 passed/1 skipped; Task 8 adds 10 new test cases (1+2+2+2+1+1+1) across 7 files → 66 passed/1 skipped, exactly what the report's GREEN evidence shows.

### Strengths

- Every file matches the brief's exact specified code; the report's "no deviations" claim is accurate (independently re-diffed, not just trusted).
- `Popover`/`Menu`/`MenuRow` bundled in one file exactly as the brief's interface groups them, with the panel-vs-content separation (`ohf-pop-head` optional, `--ohf-pop-x/y` custom properties) kept clean.
- Real ARIA/semantics used throughout — `<dialog>` with `showModal()`/`aria-modal`/`aria-labelledby`, backdrop-click-to-close via the `target === currentTarget` trick, `onCancel` wired to `onClose` — no hand-rolled modal.
- `Popover.scss`/`Tooltip.scss` correctly limit themselves to the two state pins the underlying studio rules actually have (`.ohf-menu-row` has no `:active` anywhere in `_popovers.scss`; `.ohf-tip` has no `:active` anywhere in `_tooltips.scss`) rather than inventing an active pin that wouldn't mirror anything real — verified directly against the studio partials, not just the report's claim.
- Discipline: the diff's file list contains nothing outside the brief's batch; export merge is alphabetically correct.

### Issues

#### Critical (Must Fix)

None.

#### Important (Should Fix)

1. **`t8/src/components/UndoBar/` (no `.scss` file exists)** — `UndoBar` renders a real, interactive `<button className="ohf-undo-act">` (`UndoBar.tsx` diff lines 639/681), and the studio partial it reuses already defines meaningful hover/active feedback for that exact class: `.ohf-undo-act:hover { background: var(--s4); border-color: var(--line-2); }` and `.ohf-undo-act:active { transform: scale(0.97); }` (`src/styles/studio/_composer.scss:59-65`). Per the binding "상태 고정" constraint (plan-header.md:34), every interactive component must pair these with `[data-state="hover"]`/`[data-state="active"]` so the showcase can pin the state — but `UndoBar` ships with zero `.scss`, so this button has no data-state pin at all, and (unlike `Skeleton`/`Alert`, which really do add nothing) `UndoBarProps` doesn't even extend `HTMLAttributes`, so there is no prop path to reach the button with a `data-state` attribute even if a `.scss` file existed. This is plan-mandated: `plan-header.md`'s explicit "no `.scss` needed" list (line 32) and `task-8-brief.md`'s Step 5 code (lines 615-648) are exactly what shipped, unchanged. It is structurally the same gap Task 7's review already raised and the controller explicitly "parked" for `OptionList`/`Slider` (`task-7-review.md:36`, `progress.md` "Task 7: parked — ... 코드는 그대로 둔다... 닿게 하려면 기획서에 없는 옵션별 전달 props가 필요하다") — reachability here requires either a `data-state`-forwarding prop on `UndoBar` (out of the brief's interface) or accepting the same limitation. The implementer's own self-review (`task-8-report.md`, "State-pinning pairing check" note) checked `ohf-menu-row`/`ohf-tip`/`ohf-frame` but never checked `ohf-undo-act`, so this was missed rather than deliberately accepted. Flag for the controller: park consistently with the Task 7 ruling, or add a small `UndoBar.scss` + a `data-state` pass-through prop.

#### Minor (Nice to Have)

1. `task-8-report.md`'s "Deviations" section claims "every color/shadow is reached through `var()`" for the four new `.scss` files — `Thumb.scss:70` (`background: rgba(255, 255, 255, 0.85);`) is a literal, not a `var()`. Not a code defect (it doesn't duplicate any of the 31 tokens' actual values, and mirrors existing precedent in `Button.scss`/`Segment.scss`), but the report's blanket claim is inaccurate.
2. `Popover.test.tsx` never exercises `placement="down"` (only `"static"` and the default `"up"`), so `Popover.scss:1-5`'s `.ohf-popover--down` rule has no test coverage. Not required by the brief; worth a follow-up assertion if `Popover` gains more callers.

### Assessment

**Task quality:** Needs fixes

**Reasoning:** All seven components and the public API match the brief's specified interfaces exactly, with zero code drift from the literal brief text and no token-literal-ban violations — but the binding "상태 고정" global constraint is unmet for `UndoBar`'s own action button, a gap the implementer's self-review didn't catch and that is structurally identical to a finding the controller already had to rule on in Task 7, so it should be resolved (fixed or explicitly parked) the same way before sign-off.
