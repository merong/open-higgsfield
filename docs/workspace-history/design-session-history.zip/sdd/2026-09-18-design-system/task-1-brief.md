### Task 1: 스캐폴딩과 라이브러리 빌드

**Files:**
- Create: `design/package.json`, `design/pnpm-workspace.yaml`, `design/tsconfig.json`, `design/vite.config.ts`, `design/vitest.config.ts`, `design/index.html`, `design/.gitignore`, `design/README.md`
- Create: `design/src/index.ts`, `design/src/vite-env.d.ts`, `design/showcase/main.tsx`
- Create: `design/scripts/check-dist.mjs`
- Test: `design/test/setup.ts`, `design/test/package.test.ts`

**Interfaces:**
- Produces: 명령 `pnpm dev / build / build:showcase / tokens / test / typecheck`; 별칭 `@/*` → `src/*`(TS와 Vite 둘 다); `dist/index.js`, `dist/index.d.ts`, `dist/ohf.css`.

- [ ] **Step 1: 패키지 파일 작성**

`design/package.json`:

```json
{
  "name": "@openhiggsfield/design",
  "version": "0.1.0",
  "private": true,
  "type": "module",
  "packageManager": "pnpm@10.33.2",
  "files": ["dist"],
  "exports": {
    ".": { "types": "./dist/index.d.ts", "import": "./dist/index.js" },
    "./ohf.css": "./dist/ohf.css"
  },
  "scripts": {
    "dev": "vite",
    "build": "vite build --mode lib && node scripts/check-dist.mjs",
    "build:showcase": "vite build --outDir dist-showcase",
    "tokens": "node scripts/export-tokens.mjs",
    "test": "vitest run",
    "typecheck": "tsc --noEmit"
  },
  "peerDependencies": {
    "react": "^19.0.0",
    "react-dom": "^19.0.0"
  },
  "devDependencies": {
    "@testing-library/jest-dom": "^7.0.1",
    "@testing-library/react": "^16.3.3",
    "@types/node": "^24.0.0",
    "@types/react": "^19.3.0",
    "@types/react-dom": "^19.3.0",
    "@vitejs/plugin-react": "^5.2.0",
    "jsdom": "^30.1.0",
    "pretendard": "^1.3.9",
    "react": "^19.2.0",
    "react-dom": "^19.2.0",
    "sass-embedded": "^1.104.1",
    "typescript": "^5.9.2",
    "vite": "^7.3.6",
    "vite-plugin-dts": "^5.1.0",
    "vitest": "^5.0.1"
  }
}
```

`design/pnpm-workspace.yaml`(pnpm 10은 허용 목록에 없는 빌드 스크립트를 건너뛴다. esbuild만 허용):

```yaml
onlyBuiltDependencies:
  - esbuild
```

`design/.gitignore`:

```
node_modules
dist
dist-showcase
```

`design/tsconfig.json`:

```json
{
  "compilerOptions": {
    "target": "ES2022",
    "lib": ["ES2022", "DOM", "DOM.Iterable"],
    "module": "ESNext",
    "moduleResolution": "bundler",
    "jsx": "react-jsx",
    "strict": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "noEmit": true,
    "skipLibCheck": true,
    "isolatedModules": true,
    "resolveJsonModule": true,
    "esModuleInterop": true,
    "baseUrl": ".",
    "paths": { "@/*": ["src/*"] }
  },
  "include": ["src", "showcase", "test", "vite.config.ts", "vitest.config.ts"]
}
```

`design/vite.config.ts`:

```ts
import { fileURLToPath } from "node:url";

import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";
import dts from "vite-plugin-dts";

const src = fileURLToPath(new URL("./src", import.meta.url));

/* One config, two modes: `--mode lib` emits the package (index.js + index.d.ts
   + ohf.css), anything else serves or builds the showcase. */
export default defineConfig(({ mode }) => ({
  plugins: [
    react(),
    ...(mode === "lib"
      ? [dts({ include: ["src"], exclude: ["src/**/*.test.ts", "src/**/*.test.tsx"] })]
      : []),
  ],
  resolve: { alias: { "@": src } },
  build:
    mode === "lib"
      ? {
          lib: {
            entry: `${src}/index.ts`,
            formats: ["es"],
            fileName: "index",
            cssFileName: "ohf",
          },
          rollupOptions: { external: ["react", "react-dom", "react/jsx-runtime"] },
          cssCodeSplit: false,
          sourcemap: true,
        }
      : { outDir: "dist-showcase" },
}));
```

`design/vitest.config.ts`:

```ts
import { fileURLToPath } from "node:url";

import react from "@vitejs/plugin-react";
import { defineConfig } from "vitest/config";

export default defineConfig({
  plugins: [react()],
  resolve: { alias: { "@": fileURLToPath(new URL("./src", import.meta.url)) } },
  test: {
    environment: "jsdom",
    setupFiles: ["./test/setup.ts"],
    include: ["src/**/*.test.{ts,tsx}", "test/**/*.test.ts"],
    /* Component tests assert roles and classes, never computed style, so the
       SCSS is not compiled here; parity compiles it on its own. */
    css: false,
  },
});
```

`design/index.html`(쇼케이스 진입점. Pretendard는 `showcase/main.tsx`가 npm 패키지에서 import하고, Google Fonts 3종과 `--font-ohf-inter`는 여기서만 정의):

```html
<!doctype html>
<html lang="ko">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>OpenHiggsfield Design</title>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css2?family=Black+Han+Sans&family=Gowun+Dodum&family=Noto+Serif+KR:wght@700&display=swap"
    />
    <style>
      :root {
        --font-ohf-inter: "Pretendard Variable";
      }
      html,
      body {
        margin: 0;
        background: #0a0a0b;
        color-scheme: dark;
      }
    </style>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/showcase/main.tsx"></script>
  </body>
</html>
```

`design/src/vite-env.d.ts`:

```ts
/// <reference types="vite/client" />
```

`design/src/index.ts`(빈 진입점. Task 3부터 채운다):

```ts
export {};
```

`design/showcase/main.tsx`(임시. Task 11에서 교체):

```tsx
import { createRoot } from "react-dom/client";

createRoot(document.getElementById("root")!).render(<div className="ohf">OpenHiggsfield Design</div>);
```

`design/test/setup.ts`:

```ts
import "@testing-library/jest-dom/vitest";
```

`design/README.md`(뼈대. Task 13에서 완성):

```markdown
# @openhiggsfield/design

OpenHiggsfield 스튜디오의 디자인 시스템. React + Vite, SCSS → `ohf.css`.

- `corepack pnpm dev` — 쇼케이스
- `corepack pnpm build` — `dist/index.js`, `dist/index.d.ts`, `dist/ohf.css`
- `corepack pnpm test && corepack pnpm typecheck`
```

`design/scripts/check-dist.mjs`:

```js
import { cpSync, existsSync, readFileSync, readdirSync, statSync } from "node:fs";
import { join } from "node:path";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("..", import.meta.url));
const dist = join(root, "dist");

for (const name of ["index.js", "index.d.ts", "ohf.css"]) {
  if (!existsSync(join(dist, name))) throw new Error(`dist/${name} is missing`);
}

/* The consuming app ships its own React; a second copy would break hooks. */
const js = readFileSync(join(dist, "index.js"), "utf8");
if (js.includes("react-dom")) throw new Error("dist/index.js bundles react-dom");

/* Declarations must not leak the "@/" alias — consumers cannot resolve it. */
function walk(dir) {
  return readdirSync(dir).flatMap((name) => {
    const path = join(dir, name);
    return statSync(path).isDirectory() ? walk(path) : [path];
  });
}
for (const file of walk(dist).filter((f) => f.endsWith(".d.ts"))) {
  if (readFileSync(file, "utf8").includes('"@/')) throw new Error(`${file} references the @/ alias`);
}

/* tokens/index.d.ts imports the JSON by relative path; ship it next to it. */
const json = join(root, "src/tokens/tokens.json");
if (existsSync(json)) cpSync(json, join(dist, "tokens/tokens.json"));

console.log("dist ok");
```

- [ ] **Step 2: 실패하는 패키지 테스트 작성**

`design/test/package.test.ts`:

```ts
import { describe, expect, it } from "vitest";

import pkg from "../package.json";

describe("package.json", () => {
  it("exposes the library entry and the stylesheet", () => {
    expect(pkg.exports["."]).toEqual({ types: "./dist/index.d.ts", import: "./dist/index.js" });
    expect(pkg.exports["./ohf.css"]).toBe("./dist/ohf.css");
  });

  it("leaves React to the consuming app", () => {
    expect(Object.keys(pkg.peerDependencies)).toEqual(["react", "react-dom"]);
  });
});
```

- [ ] **Step 3: 설치하고 테스트가 (의존성 설치 전) 실패하는지 확인**

Run: `cd /Users/brian/works/agent/openhigsfield/design && corepack pnpm install`
Expected: 설치 성공. `Ignored build scripts` 경고가 esbuild 이외에 나오면 그 이름을 `pnpm-workspace.yaml`의 `onlyBuiltDependencies`에 추가한다. 최신 버전이 `minimumReleaseAge`에 걸려 조금 낮은 버전이 잡히는 것은 문제없다.

Run: `corepack pnpm test`
Expected: PASS (2 tests). 설치 전에는 `vitest`가 없어 실패했을 것이고, 이 시점에 통과해야 한다.

- [ ] **Step 4: 타입 검사와 라이브러리 빌드**

Run: `corepack pnpm typecheck`
Expected: 오류 없음.

Run: `corepack pnpm build`
Expected: `dist/index.js`, `dist/index.d.ts`, `dist/ohf.css`가 생기고 `dist ok`가 출력된다. 진입점이 비어 있어 `ohf.css`는 비어 있거나 매우 작다.

확인 항목(기획서 9장):
- `cssFileName: "ohf"`가 무시되어 `dist/design.css`나 `dist/style.css`가 나오면 `build.rollupOptions.output.assetFileNames = (info) => info.names?.[0]?.endsWith(".css") ? "ohf.css" : "[name][extname]"`로 대체한다.
- `vite-plugin-dts`가 Vite 7에서 실패하면 `dts()`를 빼고 `"build"` 스크립트를 `vite build --mode lib && tsc -p tsconfig.build.json && node scripts/check-dist.mjs`로 바꾼다. 이때 `tsconfig.build.json`은 `{"extends": "./tsconfig.json", "compilerOptions": {"noEmit": false, "emitDeclarationOnly": true, "declaration": true, "outDir": "dist", "rootDir": "src"}, "include": ["src"], "exclude": ["src/**/*.test.*"]}`.
- `sass-embedded`가 arm64 바이너리를 못 받으면 `sass`(JS)로 바꾼다(API 동일).

Run: `corepack pnpm build:showcase`
Expected: `dist-showcase/index.html` 생성.

- [ ] **Step 5: 마무리 검증**

Run: `corepack pnpm test && corepack pnpm typecheck`
Expected: 둘 다 통과.

---

