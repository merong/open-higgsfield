# Implementer instructions (shared by every task of this plan)

You build one task of a 13-task plan that creates the React + Vite + SCSS design-system package
`@openhiggsfield/design` in `/Users/brian/works/agent/openhigsfield/design/`.

## Ground rules

- Read `plan-header.md` (same folder as this file): Goal, Global Constraints, shared conventions, file tree. Every task implicitly includes them.
- Your task brief is your requirements, with exact values (file contents, names, commands) to use verbatim. Do the steps in order; follow the test-first steps where the brief has them (see the test fail, then make it pass).
- The package lives OUTSIDE any git repository. **No `git init`, no commits, no git command that writes.** Where a generic process says "commit", skip it. The controller snapshots the directory for review.
- `/Users/brian/works/agent/openhigsfield/open-higgsfield/` is READ-ONLY. Never read `.env*` files anywhere.
- Global `pnpm` is 9.10 and fails. Always run `corepack pnpm …` inside `design/` (10.33.2 via `packageManager`). Node is v25.
- A Vite dev server may be running on this directory (port 5173, HMR). Leave it alone: do not kill node/vite processes you did not start, do not start another dev server, do not leave long-running processes behind.
- The plan's code was written without being executed. If something as written does not work (a type error under strict tsc, a Sass error, a renamed option), first apply the fallback the brief lists; if there is none, make the smallest fix that keeps the brief's intent, and record exactly what you changed and why in your report. Do not redesign, do not add features.
- Only touch the files your brief names (plus `src/index.ts` export lines when it says so). Do not edit earlier tasks' files unless the brief says so or a verified defect in them blocks you — then report it explicitly.
- Comments are `/* … */` blocks that explain why, never what. Identifiers in English. No copy (UI strings) inside library components.
- Done means: `corepack pnpm test && corepack pnpm typecheck` pass with pristine output, plus whatever extra checks the brief lists.

## You do not dispatch subagents

Do all the work yourself. Never spawn a helper or a reviewer. Review is the controller's job after you report.

## When you are in over your head

Stop and report BLOCKED or NEEDS_CONTEXT with what you tried and what you need. Bad work is worse than no work. If a file grows beyond the brief's intent, report DONE_WITH_CONCERNS instead of splitting it on your own.

## Self-review before reporting

Completeness (every file/step done, every expected output seen), quality (clear names, no debug leftovers, pristine test output), discipline (nothing the brief did not ask for), testing (tests verify real behaviour). Fix what you find.

## After review findings

You may be resumed with findings. Fix them, re-run the covering tests, append a fix report (what changed, tests run, command, output) to the same report file, reply with the same short contract.

## Report

Write the full report to the report path given in your dispatch:
- what you implemented (or attempted, if blocked)
- every deviation from the brief's literal text, with the reason
- tests: commands + relevant output, RED/GREEN evidence where the brief is test-first
- files created/changed
- self-review findings, issues, concerns

Then reply with ONLY (under 15 lines): **Status:** DONE | DONE_WITH_CONCERNS | BLOCKED | NEEDS_CONTEXT; a one-line test summary; deviations (one line each); concerns; the report path. If BLOCKED/NEEDS_CONTEXT, put the specifics in the reply itself.
