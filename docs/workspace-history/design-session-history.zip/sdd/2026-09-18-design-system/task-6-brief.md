### Task 6: 기본 요소 1묶음 — cx, Spinner, Kbd, Tag, Button, IconButton, Chip, Pill, Segment

**Files:**
- Create: `design/src/lib/cx.ts`, `design/src/lib/cx.test.ts`, `design/src/lib/ratio.ts`, `design/src/lib/ratio.test.ts`
- Create: `design/src/components/{Spinner,Kbd,Tag,Button,IconButton,Chip,Pill,Segment}/…`
- Modify: `design/src/index.ts`

**Interfaces:**
- Consumes: Task 4 믹스인, Task 5 아이콘(`CaretDownIcon`).
- Produces:
  - `cx(...parts: Array<string | false | null | undefined>): string`
  - `ratioBox(value: string): { width: number; height: number } | null`, `ratioToCss(value: unknown, fallback: string): string`
  - `Spinner({ label?, className? })` → `.ohf-spinner`
  - `Kbd({ children })` → `<kbd class="ohf-kbd">`
  - `Tag({ tone?: "default"|"accent"|"muted" })` → `.ohf-tag`
  - `Button({ variant?: "primary"|"secondary"|"model"|"ghost"|"danger", size?: "sm"|"md"|"lg", icon?, kbd?, busy?, loading?, href?, disabled?, type?, ref? })` → `.ohf-btn.ohf-btn--<variant>.ohf-btn--<size>`; `href`가 있으면 `<a>`
  - `IconButton({ icon, "aria-label", size?: 28|30|36, ghost?, spin? })` → `.ohf-icon-btn.ohf-icon-btn--<size>`
  - `Chip({ pressed?, dot?, ratio?, disabled? })` → `.ohf-chip[aria-pressed]`
  - `Pill({ glyph?, label?, value, expanded?, caret? })` → `.ohf-ctl[aria-expanded]`
  - `Segment({ items: {id,label,icon?,"aria-label"?}[], value, onChange, size?: "sm"|"md", plate?, "aria-label" })` → `[role=tablist].ohf-tabs`, `SegmentItem`, `SegmentProps`

- [ ] **Step 1: 도우미 테스트와 구현**

`design/src/lib/cx.test.ts`:

```ts
import { expect, it } from "vitest";

import { cx } from "./cx";

it("joins truthy class names with one space", () => {
  expect(cx("a", false, "b", null, undefined, "c")).toBe("a b c");
  expect(cx()).toBe("");
});
```

`design/src/lib/cx.ts`:

```ts
export function cx(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(" ");
}
```

`design/src/lib/ratio.test.ts`:

```ts
import { expect, it } from "vitest";

import { ratioBox, ratioToCss } from "./ratio";

it("draws a ratio as a box that fits 14px on its long side", () => {
  expect(ratioBox("16:9")).toEqual({ width: 14, height: 8 });
  expect(ratioBox("1:1")).toEqual({ width: 14, height: 14 });
  expect(ratioBox("auto")).toBeNull();
});

it("turns a ratio into an aspect-ratio value", () => {
  expect(ratioToCss("4:5", "1 / 1")).toBe("4 / 5");
  expect(ratioToCss(undefined, "1 / 1")).toBe("1 / 1");
});
```

`design/src/lib/ratio.ts`(원본 `data.ts`의 `RATIO`, `ratioBox`, `ratioToCss` 그대로):

```ts
const RATIO = /^(\d+):(\d+)$/;

/* A fixed optical box: the long side is always 14px, so 21:9 and 1:1 leave
   their labels on the same rail. */
export function ratioBox(value: string): { width: number; height: number } | null {
  const match = RATIO.exec(value);
  if (!match) return null;
  const w = Number(match[1]);
  const h = Number(match[2]);
  const scale = 14 / Math.max(w, h);
  return { width: Math.max(5, Math.round(w * scale)), height: Math.max(5, Math.round(h * scale)) };
}

export function ratioToCss(value: unknown, fallback: string): string {
  const match = RATIO.exec(String(value ?? ""));
  return match ? `${match[1]} / ${match[2]}` : fallback;
}
```

Run: `corepack pnpm test src/lib`
Expected: PASS (3 tests).

- [ ] **Step 2: Spinner, Kbd, Tag — 실패하는 테스트**

`design/src/components/Spinner/Spinner.test.tsx`:

```tsx
import { render, screen } from "@testing-library/react";
import { expect, it } from "vitest";

import { Spinner } from "./Spinner";

it("is decorative unless given a label", () => {
  const { container } = render(<Spinner />);
  expect(container.firstChild).toHaveClass("ohf-spinner");
  expect(container.firstChild).toHaveAttribute("aria-hidden", "true");
});

it("announces itself when labelled", () => {
  render(<Spinner label="생성 중" />);
  expect(screen.getByRole("status", { name: "생성 중" })).toBeInTheDocument();
});
```

`design/src/components/Kbd/Kbd.test.tsx`:

```tsx
import { render } from "@testing-library/react";
import { expect, it } from "vitest";

import { Kbd } from "./Kbd";

it("renders a kbd element with the studio class", () => {
  const { container } = render(<Kbd>⌘↵</Kbd>);
  expect(container.querySelector("kbd")).toHaveClass("ohf-kbd");
  expect(container.querySelector("kbd")).toHaveTextContent("⌘↵");
});
```

`design/src/components/Tag/Tag.test.tsx`:

```tsx
import { render } from "@testing-library/react";
import { expect, it } from "vitest";

import { Tag } from "./Tag";

it("renders tones as modifiers", () => {
  const { container, rerender } = render(<Tag>카드뉴스</Tag>);
  expect(container.firstChild).toHaveClass("ohf-tag");
  expect(container.firstChild).not.toHaveClass("ohf-tag--accent");
  rerender(<Tag tone="accent">기본값</Tag>);
  expect(container.firstChild).toHaveClass("ohf-tag--accent");
});
```

Run: `corepack pnpm test src/components`
Expected: FAIL — 모듈 없음.

- [ ] **Step 3: Spinner, Kbd, Tag 구현**

`design/src/components/Spinner/Spinner.tsx`:

```tsx
import { cx } from "@/lib/cx";

export interface SpinnerProps {
  /* With a label the spinner is a live region; without one it is decoration
     next to text that already says what is happening. */
  label?: string;
  className?: string;
}

export function Spinner({ label, className }: SpinnerProps) {
  return label ? (
    <span className={cx("ohf-spinner", className)} role="status" aria-label={label} />
  ) : (
    <span className={cx("ohf-spinner", className)} aria-hidden="true" />
  );
}
```

`design/src/components/Spinner/index.ts`: `export * from "./Spinner";`

`design/src/components/Kbd/Kbd.tsx`:

```tsx
import type { HTMLAttributes } from "react";

import { cx } from "@/lib/cx";

export function Kbd({ className, ...rest }: HTMLAttributes<HTMLElement>) {
  return <kbd className={cx("ohf-kbd", className)} {...rest} />;
}
```

`design/src/components/Kbd/index.ts`: `export * from "./Kbd";`

`design/src/components/Tag/Tag.tsx`:

```tsx
import type { HTMLAttributes, ReactNode } from "react";

import { cx } from "@/lib/cx";

import "./Tag.scss";

export type TagTone = "default" | "accent" | "muted";

export interface TagProps extends HTMLAttributes<HTMLSpanElement> {
  tone?: TagTone;
  children: ReactNode;
}

export function Tag({ tone = "default", className, children, ...rest }: TagProps) {
  return (
    <span className={cx("ohf-tag", tone !== "default" && `ohf-tag--${tone}`, className)} {...rest}>
      {children}
    </span>
  );
}
```

`design/src/components/Tag/Tag.scss`:

```scss
.ohf-tag {
  display: inline-flex;
  align-items: center;
  height: 20px;
  padding: 0 7px;
  border-radius: var(--radius-sm);
  background: var(--s3);
  color: var(--tx3);
  font-size: 11px;
  font-weight: var(--fw-strong);
  white-space: nowrap;

  &--accent {
    background: var(--accent-14);
    color: var(--accent);
  }
  &--muted {
    background: var(--s2);
    color: var(--tx4);
  }
}
```

`design/src/components/Tag/index.ts`: `export * from "./Tag";`

Run: `corepack pnpm test src/components`
Expected: PASS (4 tests).

- [ ] **Step 4: Button — 실패하는 테스트**

`design/src/components/Button/Button.test.tsx`:

```tsx
import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";

import { Button } from "./Button";

describe("Button", () => {
  it("is a real button of type button by default", () => {
    render(<Button>생성</Button>);
    const el = screen.getByRole("button", { name: "생성" });
    expect(el).toHaveAttribute("type", "button");
    expect(el).toHaveClass("ohf-btn", "ohf-btn--secondary", "ohf-btn--md");
  });

  it("renders variant and size as modifiers", () => {
    render(<Button variant="primary" size="lg">생성</Button>);
    expect(screen.getByRole("button")).toHaveClass("ohf-btn--primary", "ohf-btn--lg");
  });

  it("becomes a link when given href", () => {
    render(<Button href="/projects">프로젝트</Button>);
    expect(screen.getByRole("link", { name: "프로젝트" })).toHaveAttribute("href", "/projects");
  });

  it("is disabled while busy and says so with data-busy", () => {
    render(<Button busy>생성 중</Button>);
    const el = screen.getByRole("button");
    expect(el).toBeDisabled();
    expect(el).toHaveAttribute("data-busy", "true");
  });

  it("swaps the icon for a spinner while loading", () => {
    const { container } = render(<Button loading icon={<svg data-testid="ic" />}>저장</Button>);
    expect(container.querySelector(".ohf-spinner")).not.toBeNull();
    expect(screen.queryByTestId("ic")).toBeNull();
    expect(screen.getByRole("button")).toBeDisabled();
  });

  it("shows a keyboard hint", () => {
    render(<Button kbd="⌘↵">생성</Button>);
    expect(screen.getByRole("button").querySelector("kbd")).toHaveTextContent("⌘↵");
  });
});
```

Run: `corepack pnpm test src/components/Button`
Expected: FAIL — 모듈 없음.

- [ ] **Step 5: Button 구현**

`design/src/components/Button/Button.tsx`:

```tsx
import type { AnchorHTMLAttributes, ButtonHTMLAttributes, HTMLAttributes, ReactNode, Ref } from "react";

import { Kbd } from "@/components/Kbd";
import { Spinner } from "@/components/Spinner";
import { cx } from "@/lib/cx";

import "./Button.scss";

export type ButtonVariant = "primary" | "secondary" | "model" | "ghost" | "danger";
export type ButtonSize = "sm" | "md" | "lg";

export interface ButtonProps extends Omit<HTMLAttributes<HTMLElement>, "children"> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  icon?: ReactNode;
  kbd?: string;
  /* Busy is a run in flight: still lime, still disabled. Loading is the
     control's own wait: the icon becomes a spinner. */
  busy?: boolean;
  loading?: boolean;
  disabled?: boolean;
  href?: string;
  type?: "button" | "submit" | "reset";
  children?: ReactNode;
  ref?: Ref<HTMLElement>;
}

export function Button({
  variant = "secondary",
  size = "md",
  icon,
  kbd,
  busy = false,
  loading = false,
  disabled = false,
  href,
  type,
  className,
  children,
  ref,
  ...rest
}: ButtonProps) {
  const cls = cx("ohf-btn", `ohf-btn--${variant}`, `ohf-btn--${size}`, className);
  const body = (
    <>
      {loading ? <Spinner /> : icon ? <span className="ohf-btn-icon">{icon}</span> : null}
      {children !== undefined && <span className="ohf-btn-label">{children}</span>}
      {kbd && <Kbd>{kbd}</Kbd>}
    </>
  );
  if (href !== undefined) {
    return (
      <a
        ref={ref as Ref<HTMLAnchorElement>}
        className={cls}
        href={href}
        aria-disabled={disabled || undefined}
        data-busy={busy || undefined}
        {...(rest as AnchorHTMLAttributes<HTMLAnchorElement>)}
      >
        {body}
      </a>
    );
  }
  return (
    <button
      ref={ref as Ref<HTMLButtonElement>}
      type={type ?? "button"}
      className={cls}
      disabled={disabled || busy || loading}
      data-busy={busy || undefined}
      data-loading={loading || undefined}
      {...(rest as ButtonHTMLAttributes<HTMLButtonElement>)}
    >
      {body}
    </button>
  );
}
```

`design/src/components/Button/Button.scss`(값은 `.ohf-generate`, `.ohf-ctl`, `.ohf-ctl--model`, `.ohf-btn-quiet`에서):

```scss
@use "@/styles/mixins" as m;

.ohf-btn {
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 7px;
  flex-shrink: 0;
  height: var(--h-md);
  padding: 0 13px;
  border: 1px solid var(--line-2);
  border-radius: var(--radius-ctl);
  background: transparent;
  color: var(--tx2);
  font-size: var(--fs-sm);
  font-weight: var(--fw-medium);
  letter-spacing: var(--ls-tight);
  white-space: nowrap;
  text-decoration: none;
  cursor: pointer;
  @include m.tabular;
  @include m.control-states(var(--s3), var(--tx));

  &[aria-expanded="true"] {
    background: var(--s3);
    border-color: var(--accent-32);
    color: var(--tx);
  }

  &--sm {
    height: var(--h-sm);
    padding: 0 12px;
    border-radius: var(--radius-md);
  }
  &--lg {
    height: var(--h-lg);
    padding: 0 14px;
  }

  /* The one lime button on a screen. Same face as .ohf-generate. */
  &--primary {
    border-color: transparent;
    background: linear-gradient(180deg, #d9fe3e, var(--accent));
    color: var(--accent-ink);
    font-size: var(--fs-md);
    font-weight: var(--fw-display);
    box-shadow:
      0 2px 8px rgba(0, 0, 0, 0.4),
      inset 0 1px 0 rgba(255, 255, 255, 0.4);
    @include m.hover {
      background: linear-gradient(180deg, #d9fe3e, var(--accent));
      color: var(--accent-ink);
      filter: brightness(1.06);
    }
    @include m.disabled {
      background: var(--s3);
      color: var(--tx4);
      box-shadow: var(--shadow-1);
    }
    /* Busy is not dead: a run in flight keeps the accent. */
    &[data-busy="true"] {
      background: var(--accent-14);
      color: var(--accent);
      box-shadow: inset 0 0 0 1px var(--accent-32);
    }
  }
  &--model {
    background: var(--s3);
    color: var(--tx);
    box-shadow: var(--shadow-1);
    @include m.hover {
      background: var(--s4);
    }
  }
  &--ghost {
    border-color: transparent;
  }
  &--danger {
    background: var(--danger-bg);
    border-color: var(--danger-line);
    color: var(--danger);
    @include m.hover {
      background: var(--danger-line);
      color: var(--danger);
    }
  }
}
.ohf-btn-icon {
  display: flex;
  flex-shrink: 0;
}
.ohf-btn-label {
  position: relative;
}
.ohf-btn[data-loading="true"] .ohf-btn-label {
  opacity: 0.7;
}
```

`design/src/components/Button/index.ts`: `export * from "./Button";`

Run: `corepack pnpm test src/components/Button`
Expected: PASS (6 tests).

- [ ] **Step 6: IconButton, Chip, Pill — 실패하는 테스트**

`design/src/components/IconButton/IconButton.test.tsx`:

```tsx
import { render, screen } from "@testing-library/react";
import { expect, it } from "vitest";

import { IconButton } from "./IconButton";

it("requires a name and renders size and ghost as modifiers", () => {
  render(<IconButton icon={<svg />} aria-label="닫기" size={28} ghost />);
  const el = screen.getByRole("button", { name: "닫기" });
  expect(el).toHaveClass("ohf-icon-btn", "ohf-icon-btn--28", "ohf-icon-btn--ghost");
  expect(el).toHaveAttribute("type", "button");
});

it("defaults to 30px", () => {
  render(<IconButton icon={<svg />} aria-label="복제" />);
  expect(screen.getByRole("button")).toHaveClass("ohf-icon-btn--30");
});
```

`design/src/components/Chip/Chip.test.tsx`:

```tsx
import { render, screen } from "@testing-library/react";
import { expect, it } from "vitest";

import { Chip } from "./Chip";

it("is a toggle when pressed is given", () => {
  const { rerender } = render(<Chip pressed>전체</Chip>);
  expect(screen.getByRole("button", { name: "전체", pressed: true })).toHaveClass("ohf-chip");
  rerender(<Chip pressed={false}>전체</Chip>);
  expect(screen.getByRole("button", { pressed: false })).toBeInTheDocument();
});

it("is a plain button without pressed", () => {
  render(<Chip>PNG</Chip>);
  expect(screen.getByRole("button")).not.toHaveAttribute("aria-pressed");
});

it("draws a dot or a ratio box before the label", () => {
  const { container, rerender } = render(<Chip dot>생성 중</Chip>);
  expect(container.querySelector(".ohf-chip-dot")).not.toBeNull();
  rerender(<Chip ratio="4:5">피드</Chip>);
  const box = container.querySelector<HTMLElement>(".ohf-chip-ratio");
  expect(box?.style.width).toBe("11px");
  expect(box?.style.height).toBe("14px");
});
```

`design/src/components/Pill/Pill.test.tsx`:

```tsx
import { render, screen } from "@testing-library/react";
import { expect, it } from "vitest";

import { Pill } from "./Pill";

it("shows label and value on the studio control pill", () => {
  render(<Pill label="장수" value="8" glyph={<svg data-testid="g" />} />);
  const el = screen.getByRole("button");
  expect(el).toHaveClass("ohf-ctl");
  expect(el.querySelector(".ohf-ctl-label")).toHaveTextContent("장수");
  expect(el.querySelector(".ohf-ctl-value")).toHaveTextContent("8");
  expect(screen.getByTestId("g").closest(".ohf-ctl-glyph")).not.toBeNull();
  expect(el).not.toHaveAttribute("aria-expanded");
});

it("reports an open panel", () => {
  render(<Pill value="최근 수정" expanded />);
  expect(screen.getByRole("button")).toHaveAttribute("aria-expanded", "true");
});
```

Run: `corepack pnpm test src/components`
Expected: FAIL — 세 모듈 없음.

- [ ] **Step 7: IconButton, Chip, Pill 구현**

`design/src/components/IconButton/IconButton.tsx`:

```tsx
import type { ButtonHTMLAttributes, ReactNode, Ref } from "react";

import { cx } from "@/lib/cx";

import "./IconButton.scss";

export type IconButtonSize = 28 | 30 | 36;

export interface IconButtonProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, "children" | "aria-label"> {
  icon: ReactNode;
  "aria-label": string;
  size?: IconButtonSize;
  ghost?: boolean;
  /* One turn of the glyph, fired from the press — the studio's retry mark. */
  spin?: boolean;
  ref?: Ref<HTMLButtonElement>;
}

export function IconButton({ icon, size = 30, ghost = false, spin = false, className, type, ...rest }: IconButtonProps) {
  return (
    <button
      type={type ?? "button"}
      className={cx("ohf-icon-btn", `ohf-icon-btn--${size}`, ghost && "ohf-icon-btn--ghost", className)}
      data-spin={spin || undefined}
      {...rest}
    >
      {icon}
    </button>
  );
}
```

`design/src/components/IconButton/IconButton.scss`:

```scss
@use "@/styles/mixins" as m;

/* Doubled class so a size wins over the studio's 34px default and over the
   28px the ghost modifier sets, whatever order the sheets land in. */
.ohf-icon-btn.ohf-icon-btn--28 {
  width: var(--h-xs);
  height: var(--h-xs);
}
.ohf-icon-btn.ohf-icon-btn--30 {
  width: 30px;
  height: 30px;
}
.ohf-icon-btn.ohf-icon-btn--36 {
  width: var(--h-md);
  height: var(--h-md);
}

.ohf-icon-btn {
  &[data-state="hover"] {
    background: var(--s3);
    color: var(--tx);
    border-color: var(--line-2);
  }
  &[data-state="active"] {
    transform: scale(0.96);
  }
  @include m.disabled {
    color: var(--tx-off);
    background: var(--s1);
    border-color: var(--line);
    transform: none;
  }
  &--ghost {
    @include m.hover {
      background: var(--s3);
      border-color: transparent;
    }
    @include m.disabled {
      background: transparent;
      border-color: transparent;
    }
  }
}
```

`design/src/components/IconButton/index.ts`: `export * from "./IconButton";`

`design/src/components/Chip/Chip.tsx`:

```tsx
import type { ButtonHTMLAttributes, ReactNode, Ref } from "react";

import { cx } from "@/lib/cx";
import { ratioBox } from "@/lib/ratio";

import "./Chip.scss";

export interface ChipProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, "children"> {
  /* Given (true or false) the chip is a toggle; left out it is a plain button. */
  pressed?: boolean;
  dot?: boolean;
  ratio?: string;
  children: ReactNode;
  ref?: Ref<HTMLButtonElement>;
}

export function Chip({ pressed, dot = false, ratio, className, type, children, ...rest }: ChipProps) {
  const box = ratio ? ratioBox(ratio) : null;
  return (
    <button type={type ?? "button"} className={cx("ohf-chip", className)} aria-pressed={pressed} {...rest}>
      {dot && <span className="ohf-chip-dot" aria-hidden="true" />}
      {ratio && <span className="ohf-chip-ratio" aria-hidden="true" style={box ?? undefined} />}
      <span className="ohf-chip-label">{children}</span>
    </button>
  );
}
```

`design/src/components/Chip/Chip.scss`:

```scss
@use "@/styles/mixins" as m;

.ohf-chip {
  &[data-state="hover"] {
    background: var(--s3);
    color: var(--tx);
  }
  &[data-state="active"] {
    transform: scale(0.96);
  }
  @include m.disabled {
    background: transparent;
    border-color: var(--line);
    color: var(--tx-off);
    transform: none;
  }
}
.ohf-chip-dot {
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background: var(--accent);
  flex-shrink: 0;
}
.ohf-chip-ratio {
  display: block;
  flex-shrink: 0;
  border: 1.5px solid currentColor;
  border-radius: 2px;
  opacity: 0.9;
}
```

`design/src/components/Chip/index.ts`: `export * from "./Chip";`

`design/src/components/Pill/Pill.tsx`:

```tsx
import type { ButtonHTMLAttributes, ReactNode, Ref } from "react";

import { CaretDownIcon } from "@/icons";
import { cx } from "@/lib/cx";

import "./Pill.scss";

export interface PillProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, "children" | "value"> {
  glyph?: ReactNode;
  label?: ReactNode;
  value: ReactNode;
  /* Given, the pill opens a panel and says whether it is open. */
  expanded?: boolean;
  caret?: boolean;
  ref?: Ref<HTMLButtonElement>;
}

export function Pill({ glyph, label, value, expanded, caret = true, className, type, ...rest }: PillProps) {
  return (
    <button type={type ?? "button"} className={cx("ohf-ctl", className)} aria-expanded={expanded} {...rest}>
      {glyph && <span className="ohf-ctl-glyph">{glyph}</span>}
      {label !== undefined && <span className="ohf-ctl-label">{label}</span>}
      <span className="ohf-ctl-value">{value}</span>
      {caret && (
        <span className="ohf-ctl-caret" aria-hidden="true">
          <CaretDownIcon />
        </span>
      )}
    </button>
  );
}
```

`design/src/components/Pill/Pill.scss`:

```scss
@use "@/styles/mixins" as m;

.ohf-ctl {
  &[data-state="hover"] {
    background: var(--s3);
    color: var(--tx);
  }
  &[data-state="active"] {
    transform: scale(0.96);
  }
  @include m.disabled {
    color: var(--tx-off);
    border-color: var(--line);
    background: transparent;
    transform: none;
  }
}
.ohf-ctl-label {
  color: var(--tx3);
}
.ohf-ctl-caret {
  display: flex;
  color: var(--tx3);
  margin-left: 1px;
}
```

`design/src/components/Pill/index.ts`: `export * from "./Pill";`

Run: `corepack pnpm test src/components`
Expected: PASS.

- [ ] **Step 8: Segment — 실패하는 테스트**

`design/src/components/Segment/Segment.test.tsx`:

```tsx
import { fireEvent, render, screen } from "@testing-library/react";
import { expect, it, vi } from "vitest";

import { Segment } from "./Segment";

const items = [
  { id: "studio", label: "Studio" },
  { id: "projects", label: "Projects" },
];

it("renders a tablist with one selected tab and a travelling thumb", () => {
  const { container } = render(<Segment items={items} value="projects" onChange={() => {}} aria-label="구역" />);
  expect(screen.getByRole("tablist", { name: "구역" })).toHaveClass("ohf-tabs");
  expect(screen.getByRole("tab", { name: "Projects" })).toHaveAttribute("aria-selected", "true");
  expect(screen.getByRole("tab", { name: "Studio" })).toHaveAttribute("aria-selected", "false");
  expect(container.querySelector(".ohf-thumb")).not.toBeNull();
});

it("changes on click and on arrow keys", () => {
  const onChange = vi.fn();
  render(<Segment items={items} value="studio" onChange={onChange} aria-label="구역" />);
  fireEvent.click(screen.getByRole("tab", { name: "Projects" }));
  expect(onChange).toHaveBeenCalledWith("projects");
  fireEvent.keyDown(screen.getByRole("tablist"), { key: "ArrowRight" });
  expect(onChange).toHaveBeenLastCalledWith("projects");
});

it("wraps in a plate and shrinks on request", () => {
  const { container } = render(<Segment items={items} value="studio" onChange={() => {}} size="sm" plate aria-label="구역" />);
  expect(container.firstChild).toHaveClass("ohf-tabs-plate");
  expect(screen.getByRole("tablist")).toHaveClass("ohf-tabs--sm");
});
```

Run: `corepack pnpm test src/components/Segment`
Expected: FAIL — 모듈 없음.

- [ ] **Step 9: Segment 구현**

`design/src/components/Segment/Segment.tsx`(측정 로직은 원본 `topbar.tsx`와 같다):

```tsx
import { useEffect, useRef, useState, type CSSProperties, type KeyboardEvent, type ReactNode } from "react";

import { cx } from "@/lib/cx";

import "./Segment.scss";

export interface SegmentItem {
  id: string;
  label: ReactNode;
  icon?: ReactNode;
  "aria-label"?: string;
}

export interface SegmentProps {
  items: readonly SegmentItem[];
  value: string;
  onChange: (id: string) => void;
  size?: "sm" | "md";
  /* A plate of its own for use outside the studio's floating bar. */
  plate?: boolean;
  "aria-label": string;
  className?: string;
}

export function Segment({ items, value, onChange, size = "md", plate = false, className, "aria-label": ariaLabel }: SegmentProps) {
  const tabsRef = useRef<HTMLDivElement>(null);
  const [thumb, setThumb] = useState<{ x: number; w: number } | null>(null);

  /* The indicator is measured rather than derived from equal columns, so it
     morphs to each label's real width instead of padding the short ones. */
  useEffect(() => {
    const tabs = tabsRef.current;
    if (!tabs) return;
    let live = true;
    const measure = () => {
      const active = tabs.querySelector<HTMLElement>('[aria-selected="true"]');
      if (live && active) setThumb({ x: active.offsetLeft, w: active.offsetWidth });
    };
    measure();
    const observer = typeof ResizeObserver === "undefined" ? null : new ResizeObserver(measure);
    observer?.observe(tabs);
    // The face swaps in after first paint and the labels resize under it.
    void document.fonts?.ready.then(measure);
    return () => {
      live = false;
      observer?.disconnect();
    };
  }, [value]);

  const onKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    const from = items.findIndex((item) => item.id === value);
    const to =
      event.key === "ArrowRight"
        ? (from + 1) % items.length
        : event.key === "ArrowLeft"
          ? (from - 1 + items.length) % items.length
          : event.key === "Home"
            ? 0
            : event.key === "End"
              ? items.length - 1
              : -1;
    if (to < 0) return;
    event.preventDefault();
    onChange(items[to]!.id);
    tabsRef.current?.querySelectorAll<HTMLElement>('[role="tab"]')[to]?.focus();
  };

  const list = (
    <div
      ref={tabsRef}
      role="tablist"
      aria-label={ariaLabel}
      className={cx("ohf-tabs", size === "sm" && "ohf-tabs--sm", !plate && className)}
      onKeyDown={onKeyDown}
    >
      <span
        className="ohf-thumb"
        data-ready={thumb !== null}
        aria-hidden="true"
        style={{ "--thumb-x": `${thumb?.x ?? 0}px`, "--thumb-w": `${thumb?.w ?? 0}px` } as CSSProperties}
      />
      {items.map((item) => {
        const selected = item.id === value;
        return (
          <button
            key={item.id}
            type="button"
            role="tab"
            aria-selected={selected}
            aria-label={item["aria-label"]}
            tabIndex={selected ? 0 : -1}
            className="ohf-tab"
            onClick={() => onChange(item.id)}
          >
            {item.icon}
            <span className="ohf-tab-label">{item.label}</span>
          </button>
        );
      })}
    </div>
  );
  return plate ? <div className={cx("ohf-tabs-plate", className)}>{list}</div> : list;
}
```

`design/src/components/Segment/Segment.scss`:

```scss
.ohf-tabs--sm .ohf-tab {
  height: var(--h-xs);
  padding: 0 12px;
  font-size: 12px;
  border-radius: 9px;
}
.ohf-tabs--sm .ohf-thumb {
  border-radius: 9px;
}
/* 13 = the tab's 10px radius plus the plate's 3px inset, so the corners stay
   concentric. */
.ohf-tabs-plate {
  display: inline-flex;
  padding: 3px;
  border-radius: 13px;
  background: var(--s1);
  border: 1px solid var(--line);
}
.ohf-tab[data-state="hover"] {
  color: var(--tx);
  background: rgba(255, 255, 255, 0.035);
}
.ohf-tab[data-state="hover"] svg {
  color: var(--tx2);
}
```

`design/src/components/Segment/index.ts`: `export * from "./Segment";`

Run: `corepack pnpm test src/components/Segment`
Expected: PASS (3 tests).

- [ ] **Step 10: 공개 API에 추가하고 검증**

`design/src/index.ts`에 추가:

```ts
export * from "./components/Button";
export * from "./components/Chip";
export * from "./components/IconButton";
export * from "./components/Kbd";
export * from "./components/Pill";
export * from "./components/Segment";
export * from "./components/Spinner";
export * from "./components/Tag";
export { cx } from "./lib/cx";
export { ratioBox, ratioToCss } from "./lib/ratio";
```

Run: `corepack pnpm test && corepack pnpm typecheck && corepack pnpm build`
Expected: 전부 통과. token-rules의 컴포넌트 검사가 이제 실제로 돌며 통과한다(skip이 아니다). `dist/ohf.css`에 `.ohf-btn--primary`가 있다(`grep -c "ohf-btn--primary" dist/ohf.css` ≥ 1).

알려진 처방:
- Vite가 `@use "@/styles/mixins"`를 못 찾으면 각 SCSS의 `@use` 경로를 `../../styles/mixins`로 바꾼다(모든 컴포넌트에 같은 규칙 적용, README에 기록).
- `check-dist.mjs`가 "references the @/ alias"로 실패하면 `vite.config.ts`의 `dts({ … })`에 `pathsToAliases: true`를 명시한다. 그래도 남으면 `src/` 안의 TS/TSX import를 상대 경로로 바꾼다(`@/`는 SCSS `@use`에만 남긴다).

---

