# Task 8 Report: 기본 요소 3묶음 — Skeleton, Thumb, Popover/Menu/MenuRow, Dialog, Alert, UndoBar, Tooltip

## Status: DONE

## What was implemented

Test-first, exactly per `task-8-brief.md`, component by component:

1. **RED**: wrote all 7 test files verbatim (`Skeleton/Skeleton.test.tsx`, `Thumb/Thumb.test.tsx`,
   `Popover/Popover.test.tsx`, `Dialog/Dialog.test.tsx`, `Alert/Alert.test.tsx`,
   `UndoBar/UndoBar.test.tsx`, `Tooltip/Tooltip.test.tsx`). Ran `corepack pnpm test src/components`:
   7 new files failed with "Failed to resolve import" (module not found), the 17 pre-existing
   component test files kept passing (30 passed). Confirmed RED.
2. Implemented `Skeleton` (no `.scss` — brief calls for none) and `Thumb` (+`Thumb.scss`) verbatim.
3. Implemented `Popover`, `Menu`, `MenuRow` (+`Popover.scss`) verbatim.
4. Implemented `Dialog` (+`Dialog.scss`) verbatim, including the `showModal()`-guard / `open`-attribute
   fallback for jsdom exactly as given.
5. Implemented `Alert` (no `.scss`), `UndoBar` (no `.scss`), `Tooltip` (+`Tooltip.scss`) verbatim.
6. Added the seven export lines to `design/src/index.ts`, merged alphabetically into the existing
   alphabetically-sorted export list (`Alert` after the tokens/icons exports and before `Avatar`,
   `Dialog` after `CreditBadge`, `Popover` after `Pill`, `Skeleton` after `OptionList`... — full final
   order: Alert, Avatar, Button, Chip, CreditBadge, Dialog, Field, IconButton, Input, Kbd, OptionList,
   Pill, Popover, Segment, Skeleton, Slider, Spinner, Stepper, Switch, Tag, Textarea, Thumb, Tooltip,
   UndoBar).
7. **GREEN**: ran the full verification chain.

## Deviations from the brief's literal text

None. Every file (`.tsx`, `.scss`, `.test.tsx`, `index.ts`) was used exactly as given in the brief.

Two things worth recording that were *not* deviations but are worth noting for the reviewer:

- **jsdom `showModal` fallback not needed.** The dispatch context flagged that jsdom lacks
  `HTMLDialogElement.showModal` and gave a fallback (`try { el.showModal(); } catch { /* jsdom */ }`)
  to use *if* the plain `typeof el.showModal === "function"` guard turned the console warning into a
  test failure. I implemented the brief's literal guard first, ran the Dialog tests, and both tests
  passed cleanly with no console warning surfacing as a failure (jsdom's `showModal` is present as a
  function but is a no-op that doesn't set `.open`, so the brief's own `if (!el.open) el.setAttribute("open", "")`
  fallback already covers it). I did not apply the try/catch fallback since it was not needed — kept
  the brief's literal code.
- **State-pinning pairing check (Task 6 finding) — not applicable here.** I checked every studio
  rule touched by this task's component SCSS (`ohf-menu-row`, `ohf-tip`, `ohf-frame` is a wholly-new
  class) for a paired `:hover`/`:active` pattern that the brief's SCSS might have only half-pinned.
  `.ohf-menu-row` in `_popovers.scss` has only a `:hover:not(:disabled)` rule (no `:active` rule
  anywhere in the studio partials), and `.ohf-tip` has no `:active` state at all (hover/focus only).
  So the brief's `Popover.scss` (`.ohf-menu-row[data-state="hover"]`) and `Tooltip.scss`
  (`[data-state="hover"]` pins) each already cover the only state the studio itself defines — no
  paired active pin was missing. Nothing to add; not reported as a deviation since no fix was made.
- `token-rules.test.ts` was checked against every literal value in the four new `.scss` files
  (`Thumb.scss`, `Popover.scss`, `Dialog.scss`, `Tooltip.scss`) by hand before running: none of the
  literal px/em values used (5px, 6px, 4px, 3px, 16px, -0.02em, 10px, 18px, 16px, etc.) match any
  token value in `src/styles/tokens/_maps.scss`, and every color/shadow is reached through `var()`.
  The test run below confirms this — the token-rules suite passed with no violations, so no literal
  needed replacing.

## Tests

RED (Step 1):
```
corepack pnpm test src/components
...
Test Files  7 failed | 17 passed (24)
      Tests  30 passed (30)
```
All 7 failures were "Failed to resolve import './X' — Does the file exist?" for the new component
modules; nothing else changed.

GREEN (Step 2–5, component tests only):
```
corepack pnpm test src/components
...
Test Files  24 passed (24)
      Tests  40 passed (40)
```

GREEN (Step 6, full suite):
```
corepack pnpm test
...
Test Files  33 passed (33)
      Tests  66 passed | 1 skipped (67)
```
(The 1 skipped test is the pre-existing `src/slides` token-rules check, skipped because `src/slides`
does not exist yet — unrelated to this task, unchanged from before.)

```
corepack pnpm typecheck
```
→ clean, no output, exit 0.

```
corepack pnpm build
...
dist/ohf.css   65.81 kB │ gzip: 12.11 kB
dist/index.js  31.27 kB │ gzip:  7.49 kB │ map: 70.55 kB
✓ built in 1.25s
dist ok
```

## Files created

- `design/src/components/Skeleton/{Skeleton.tsx,Skeleton.test.tsx,index.ts}`
- `design/src/components/Thumb/{Thumb.tsx,Thumb.scss,Thumb.test.tsx,index.ts}`
- `design/src/components/Popover/{Popover.tsx,Popover.scss,Popover.test.tsx,index.ts}`
- `design/src/components/Dialog/{Dialog.tsx,Dialog.scss,Dialog.test.tsx,index.ts}`
- `design/src/components/Alert/{Alert.tsx,Alert.test.tsx,index.ts}`
- `design/src/components/UndoBar/{UndoBar.tsx,UndoBar.test.tsx,index.ts}`
- `design/src/components/Tooltip/{Tooltip.tsx,Tooltip.scss,Tooltip.test.tsx,index.ts}`

## Files changed

- `design/src/index.ts` — added the 7 `export * from "./components/…"` lines (alphabetically merged).

## Self-review

- **Completeness**: all 21 files from the brief created, `index.ts` updated, all 6 steps of the brief
  done in order, RED then GREEN observed as instructed.
- **Quality**: no debug leftovers; identifiers and comments in English; comments only where the brief
  already had them (explaining *why* — e.g. the jsdom-fallback comment, the flat-state color comment).
  Pristine test/typecheck/build output.
- **Discipline**: touched only the files the brief named plus `src/index.ts`; did not touch any
  earlier task's component or studio SCSS; did not invent any token substitutions (none were needed);
  did not add the jsdom try/catch fallback since it was not required by the actual test run.
- **Testing**: all 7 new test files exercise real rendered behaviour (role queries, class assertions,
  inline-style assertions for ratio/width/position custom properties, click-driven callbacks for
  Dialog close and UndoBar action) — not shallow smoke tests.

No blocking issues, no concerns.
