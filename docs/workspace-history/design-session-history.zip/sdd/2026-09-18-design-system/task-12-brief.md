### Task 12: 쇼케이스 — 화면 11장

**Files:**
- Modify: `design/showcase/sections/Screens.tsx`
- Create: `design/showcase/screens/shell.tsx`, `design/showcase/screens/editor.tsx`, `design/showcase/screens/Projects.tsx`, `design/showcase/screens/NewProject.tsx`, `design/showcase/screens/Account.tsx`, `design/showcase/screens/Editors.tsx`, `design/showcase/screens/Phone.tsx`, `design/showcase/screens/Templates.tsx`, `design/showcase/screens/Styles.tsx`, `design/showcase/screens/CreditsModal.tsx`

**Interfaces:**
- Consumes: 공개 API, `data.ts`, `renderSlide`.
- Produces: `#screens/<id>`(projects, new, account, editor-outline, editor-generating, editor-style, editor-export, phone, templates, styles, credits).

- [ ] **Step 1: 공통 껍데기와 편집기 조각**

`design/showcase/screens/shell.tsx`:

```tsx
import type { ReactNode } from "react";

import { Avatar, BriefBar, Button, Pill, ProjectHeader, Tag, TopBar } from "@/index";
import { CheckIcon, DownloadIcon, FilmIcon, PaletteIcon, SparkleIcon, TextIcon, UserIcon } from "@/index";

import { TOPIC } from "../data";

export function AppBar({ active = "projects" }: { active?: string }) {
  return (
    <TopBar
      brand="OpenHiggsfield"
      brandLabel="OpenHiggsfield 홈"
      brandHref="#screens/projects"
      nav={{
        items: [{ id: "studio", label: "Studio" }, { id: "projects", label: "Projects" }],
        value: active,
        onChange: () => {},
        "aria-label": "구역",
      }}
      credits={1240}
      creditsUnit="크레딧"
      topUp={<Button variant="ghost" size="sm">충전</Button>}
      avatar={<Avatar initials="BK" size={32} aria-label="계정 메뉴" />}
    />
  );
}

export function Screen({ width, height, children }: { width: number; height: number; children: ReactNode }) {
  return (
    <div className="sc-screen" style={{ width, height }}>
      {children}
    </div>
  );
}

export function EditorShell({
  rows,
  strip,
  panel,
  exportPrimary = false,
  styleOpen = false,
  overlay,
}: {
  rows: ReactNode;
  strip: ReactNode;
  panel: ReactNode;
  exportPrimary?: boolean;
  styleOpen?: boolean;
  overlay?: ReactNode;
}) {
  return (
    <Screen width={1440} height={960}>
      <AppBar />
      <ProjectHeader
        back={{ href: "#screens/projects", label: "프로젝트 목록으로" }}
        title={TOPIC}
        tags={
          <>
            <Tag>카드뉴스</Tag>
            <Tag>4:5 · 1080×1350</Tag>
          </>
        }
        status={
          <>
            <CheckIcon size={13} />
            저장됨
          </>
        }
        actions={
          <>
            <Button icon={<PaletteIcon />} aria-expanded={styleOpen}>
              스타일
            </Button>
            <Button variant={exportPrimary ? "primary" : "secondary"} icon={<DownloadIcon />}>
              내보내기
            </Button>
          </>
        }
      />
      <div className="sc-editor">
        <div className="sc-editor-left">
          <div className="sc-editor-brief">
            <BriefBar
              label="주제"
              topic={TOPIC}
              pills={
                <>
                  <Pill glyph={<FilmIcon />} label="장수" value="8" />
                  <Pill glyph={<TextIcon />} label="톤" value="친근하게" />
                  <Pill glyph={<UserIcon />} label="대상" value="20대 직장인" />
                </>
              }
              action={<Button icon={<SparkleIcon />}>구성안 다시 뽑기 · 1 크레딧</Button>}
            />
          </div>
          <div className="sc-editor-rows">{rows}</div>
          {strip}
        </div>
        {panel}
      </div>
      {overlay}
    </Screen>
  );
}
```

`design/showcase/screens/editor.tsx`:

```tsx
import { Button, CanvasPanel, Chip, IconButton, Pill, StoryboardRow, type SlidePreset, type ThumbState } from "@/index";
import { CopyIcon, DownloadIcon, ImageIcon, RetryIcon, SparkleIcon, TrashIcon } from "@/index";

import { DECK, PHOTOS, TEMPLATES, subline } from "../data";
import { renderSlide } from "../lib/slide";

export function storyRows(states: ThumbState[], selected: number, warnAt?: number) {
  return DECK.map((s, i) => {
    const state = states[i]!;
    const failed = state === "failed";
    const pending = state === "pending";
    return (
      <StoryboardRow
        key={i}
        index={i + 1}
        thumb={{ state, src: s.photo ? PHOTOS[s.photo] : undefined, size: 56 }}
        tag={s.label}
        title={s.title}
        sub={subline(s)}
        counter={warnAt === i ? { value: 96, max: 90 } : undefined}
        prompt={!failed && !pending && s.prompt ? s.prompt : undefined}
        status={failed ? "생성 실패 · 4 크레딧 돌려드림" : pending ? "생성 중 · 0:42" : !s.prompt ? "단색 배경 · 이미지 없음" : undefined}
        statusTone={failed ? "danger" : pending ? "live" : "default"}
        statusAction={failed ? <Button size="sm" icon={<RetryIcon />}>다시 시도</Button> : undefined}
        selected={i === selected}
        actions={
          i === selected ? (
            <>
              <IconButton ghost size={28} icon={<SparkleIcon />} aria-label="이 슬라이드 다시 쓰기" />
              <IconButton ghost size={28} icon={<CopyIcon />} aria-label="복제" />
              <IconButton ghost size={28} icon={<TrashIcon />} aria-label="삭제" />
            </>
          ) : undefined
        }
      />
    );
  });
}

export function canvas({
  index,
  template,
  options,
  hint,
  withImage = true,
  preset = "basic",
}: {
  index: number;
  template: (typeof TEMPLATES)[number];
  options: [string, string][];
  hint: string;
  withImage?: boolean;
  preset?: SlidePreset;
}) {
  return (
    <CanvasPanel
      mode={{ items: [{ id: "slide", label: "슬라이드" }, { id: "phone", label: "휴대폰" }], value: "slide", onChange: () => {}, "aria-label": "보기" }}
      index={index}
      total={DECK.length}
      onPrev={() => {}}
      onNext={() => {}}
      prevLabel="이전 슬라이드"
      nextLabel="다음 슬라이드"
      stage={renderSlide(DECK[index - 1]!, index, preset, "4:5", withImage)}
      templates={{
        label: "템플릿",
        chips: TEMPLATES.map((t) => (
          <Chip key={t} pressed={t === template}>
            {t}
          </Chip>
        )),
      }}
      options={{ label: "옵션", pills: options.map(([l, v]) => <Pill key={l} label={l} value={v} />) }}
      actions={
        <>
          <Button icon={<RetryIcon />}>다시 생성 · 4 크레딧</Button>
          <Button icon={<ImageIcon size={14} />}>에셋에서 고르기</Button>
          <Button icon={<DownloadIcon />}>PNG</Button>
        </>
      }
      hint={hint}
    />
  );
}
```

- [ ] **Step 2: 프로젝트 목록, 새 프로젝트, 계정**

`design/showcase/screens/Projects.tsx`:

```tsx
import { Button, Chip, Pill, ProjectCard, Thumb } from "@/index";
import { ClockIcon, PlusIcon } from "@/index";

import { PHOTOS, PROJECTS } from "../data";
import { AppBar, Screen } from "./shell";

export function Projects() {
  return (
    <Screen width={1440} height={900}>
      <AppBar />
      <main className="sc-page" style={{ width: 1200 }}>
        <div className="sc-page-head">
          <h1 className="sc-page-title">프로젝트</h1>
          <span className="sc-page-count">{PROJECTS.length}개</span>
          <span className="sc-spacer" />
          <Button variant="primary" size="lg" icon={<PlusIcon />}>새 프로젝트</Button>
        </div>
        <div className="sc-toolbar" style={{ marginBottom: 0 }}>
          <Chip pressed>전체</Chip>
          <Chip pressed={false}>카드뉴스</Chip>
          <Chip disabled>릴스 · 준비 중</Chip>
          <Chip disabled>랜딩 페이지 · 준비 중</Chip>
          <span className="sc-spacer" />
          <Pill glyph={<ClockIcon />} label="정렬" value="최근 수정" />
        </div>
        <div className="sc-cards">
          <a className="sc-new-card" href="#screens/new">
            <span className="sc-new-card-plus"><PlusIcon size={18} /></span>
            <span className="sc-new-card-title">새 프로젝트</span>
            <span className="sc-muted">주제 한 줄로 시작합니다</span>
          </a>
          {PROJECTS.map((p) => (
            <ProjectCard
              key={p.title}
              href="#screens/editor-generating"
              title={p.title}
              meta={p.meta}
              status={p.status}
              statusTone={p.tone}
              deck={p.deck.map((d, i) => (
                <Thumb key={i} size={80} state={d.state} src={d.photo ? PHOTOS[d.photo] : undefined} />
              ))}
            />
          ))}
        </div>
      </main>
    </Screen>
  );
}
```

`design/showcase/screens/NewProject.tsx`:

```tsx
import { useState } from "react";

import { Button, Chip, Field, FormatCard, Input, Stepper, Textarea } from "@/index";
import { ChevronLeftIcon, FilmIcon, LayersIcon, LayoutIcon, SparkleIcon } from "@/index";

import { TOPIC } from "../data";
import { AppBar, Screen } from "./shell";

const TONES = ["친근하게", "전문가", "위트 있게", "차분하게"];
const RATIOS: [string, string][] = [["4:5", "피드 4:5"], ["3:4", "피드 3:4"], ["1:1", "정사각 1:1"], ["9:16", "스토리 9:16"]];

export function NewProject() {
  const [pages, setPages] = useState(8);
  const [tone, setTone] = useState("친근하게");
  const [ratio, setRatio] = useState("4:5");
  return (
    <Screen width={1440} height={900}>
      <AppBar />
      <main className="sc-page" style={{ width: 720, gap: 22 }}>
        <a className="sc-back" href="#screens/projects">
          <ChevronLeftIcon />
          프로젝트
        </a>
        <div>
          <h1 className="sc-page-title">새 프로젝트</h1>
          <p className="sc-page-lead">주제 한 줄이면 됩니다. 나머지는 기본값이 있고, 편집기에서 언제든 바꿀 수 있습니다.</p>
        </div>
        <section className="sc-stack">
          <span className="sc-label">포맷</span>
          <div className="sc-row-3">
            <FormatCard icon={<LayersIcon size={18} />} name="카드뉴스" description="인스타그램·쓰레드 캐러셀. 구성안 → 이미지 → PNG 묶음" pressed />
            <FormatCard icon={<FilmIcon size={18} />} name="릴스" description="장면 스토리보드에서 세로 영상으로" soon="준비 중" />
            <FormatCard icon={<LayoutIcon size={18} />} name="랜딩 페이지" description="링크 인 바이오와 캠페인 페이지" soon="준비 중" />
          </div>
        </section>
        <section className="sc-card">
          <Field label="주제" htmlFor="np-topic" required="필수" counter={{ value: TOPIC.length, max: 120 }}>
            <Textarea id="np-topic" defaultValue={TOPIC} rows={2} style={{ fontSize: 15 }} />
          </Field>
          <div className="sc-row-2">
            <Field label="대상 독자" htmlFor="np-aud">
              <Input id="np-aud" defaultValue="20대 직장인" />
            </Field>
            <Field label="장수">
              <Stepper value={pages} min={4} max={10} onChange={setPages} suffix="장" decrementLabel="한 장 줄이기" incrementLabel="한 장 늘리기" />
            </Field>
          </div>
          <Field label="톤">
            <div className="sc-toolbar" style={{ marginBottom: 0 }}>
              {TONES.map((t) => (
                <Chip key={t} pressed={t === tone} onClick={() => setTone(t)}>
                  {t}
                </Chip>
              ))}
            </div>
          </Field>
          <Field label="채널 규격" hint="1080×1350 · 프로필 그리드에서는 가운데가 잘려 보입니다">
            <div className="sc-toolbar" style={{ marginBottom: 0 }}>
              {RATIOS.map(([r, label]) => (
                <Chip key={r} ratio={r} pressed={r === ratio} onClick={() => setRatio(r)}>
                  {label}
                </Chip>
              ))}
            </div>
          </Field>
          <Field label="꼭 넣을 내용" htmlFor="np-must" optional="선택">
            <Textarea id="np-must" defaultValue="2시간마다 덧바르기, PA 등급 설명" rows={2} />
          </Field>
        </section>
        <div className="sc-cell" style={{ gap: 12 }}>
          <span className="sc-muted">구성안 1 크레딧 · 이미지 크레딧은 구성안을 확인한 뒤에 씁니다</span>
          <span className="sc-spacer" />
          <Button variant="primary" size="lg" icon={<SparkleIcon />}>구성안 만들기</Button>
        </div>
      </main>
    </Screen>
  );
}
```

`design/showcase/screens/Account.tsx`:

```tsx
import { Avatar, Button, Pill, Tag, cx } from "@/index";
import { ClockIcon, PlusIcon, WalletIcon } from "@/index";

import { LEDGER, PACKS } from "../data";
import { AppBar, Screen } from "./shell";

export function Account() {
  return (
    <Screen width={1440} height={900}>
      <AppBar />
      <main className="sc-page" style={{ width: 1040, gap: 24 }}>
        <div className="sc-cell" style={{ gap: 14 }}>
          <Avatar initials="BK" size={44} />
          <div>
            <h1 className="sc-page-title" style={{ fontSize: 20 }}>계정</h1>
            <span className="sc-muted">brian@example.com · 카카오로 로그인</span>
          </div>
          <span className="sc-spacer" />
          <Button variant="ghost">로그아웃</Button>
        </div>
        <div className="sc-account-grid">
          <section className="sc-card" style={{ gap: 14 }}>
            <span className="sc-muted sc-cell"><WalletIcon size={15} />크레딧 잔액</span>
            <div className="sc-big">1,240</div>
            <span className="sc-muted">이미지 1장 4 크레딧 · 구성안 1 크레딧<br />실패한 생성은 자동으로 돌려드립니다</span>
            <Button variant="primary" size="lg" icon={<PlusIcon />}>충전하기</Button>
          </section>
          <section className="sc-stack">
            <span className="sc-label">충전 패키지</span>
            <div className="sc-row-3">
              {PACKS.map((p) => (
                <button key={p.name} type="button" className="sc-pack" aria-pressed={p.best}>
                  <span className="sc-cell">
                    <span className="sc-muted">{p.name}</span>
                    <span className="sc-spacer" />
                    {p.best && <Tag tone="accent">인기</Tag>}
                  </span>
                  <span className="sc-pack-credits">{p.credits} <small>크레딧</small></span>
                  <span className="sc-muted">{p.price}</span>
                </button>
              ))}
            </div>
            <span className="sc-muted">가격과 단가는 서비스 기반 기획에서 정합니다 · 결제는 국내 PG로 진행합니다</span>
          </section>
        </div>
        <section className="sc-stack">
          <div className="sc-cell">
            <span className="sc-label">사용 내역</span>
            <span className="sc-spacer" />
            <Pill glyph={<ClockIcon />} label="기간" value="최근 30일" />
          </div>
          <div className="sc-table">
            <div className="sc-table-head"><span>일시</span><span>내용</span><span>프로젝트</span><span className="sc-right">크레딧</span></div>
            {LEDGER.map((r, i) => (
              <div key={i} className="sc-table-row">
                <span className="sc-muted">{r.when}</span>
                <span>{r.what}</span>
                <span className="sc-muted">{r.detail}</span>
                <span className={cx("sc-right sc-amount", r.tone === "plus" && "sc-amount--plus", r.tone === "refund" && "sc-amount--refund")}>
                  {r.tone === "minus" ? "−" : "+"}{r.amount}
                </span>
              </div>
            ))}
          </div>
        </section>
      </main>
    </Screen>
  );
}
```

- [ ] **Step 3: 편집기 4상태**

`design/showcase/screens/Editors.tsx`:

```tsx
import { ActionStrip, Button, Chip, Dialog, Field, IconButton, Input, Popover, StyleCard, Switch, Textarea, Thumb, SLIDE_PRESETS, SLIDE_STYLES, type ThumbState } from "@/index";
import { CaretDownIcon, CheckIcon, CloseIcon, CopyIcon, DownloadIcon, ImageIcon, PlusIcon, SparkleIcon } from "@/index";

import { DECK, PHOTOS } from "../data";
import { renderSlide } from "../lib/slide";
import { canvas, storyRows } from "./editor";
import { EditorShell } from "./shell";

const OPTIONS: [string, string][] = [["위치", "아래"], ["제목", "크게"], ["어둡게", "40%"]];
const PRESET_NAMES = { basic: ["기본 고딕", "Pretendard · 남색과 노랑"], editorial: ["에디토리얼", "Noto Serif KR 제목 · 크림과 벽돌색"], impact: ["임팩트", "Black Han Sans 제목 · 검정과 주홍"], soft: ["부드럽게", "Gowun Dodum · 세이지와 초록"] } as const;

export function EditorOutline() {
  const states = DECK.map((s): ThumbState => (s.kind === "cta" ? "flat" : "empty"));
  return (
    <EditorShell
      rows={storyRows(states, 0, 4)}
      strip={
        <ActionStrip
          status={<><ImageIcon size={15} />이미지가 없는 슬라이드 <b>7장</b> · 문구를 확정한 뒤 생성하세요</>}
          actions={<><Button icon={<PlusIcon />}>슬라이드 추가</Button><Button variant="primary" size="lg" icon={<SparkleIcon />}>7장 생성 · 28 크레딧</Button></>}
        />
      }
      panel={canvas({ index: 1, template: "표지", options: OPTIONS, hint: "이미지가 없는 동안에는 스타일의 단색 배경 위에 글만 얹어 보여 줍니다", withImage: false })}
    />
  );
}

export function EditorGenerating() {
  const states: ThumbState[] = ["image", "image", "image", "pending", "failed", "empty", "empty", "flat"];
  return (
    <EditorShell
      rows={storyRows(states, 0)}
      strip={
        <ActionStrip
          status={<><span className="sc-lamp" /><b>1장</b> 생성 중 · 문구는 계속 고칠 수 있습니다</>}
          actions={<><Button icon={<PlusIcon />}>슬라이드 추가</Button><Button variant="primary" size="lg" icon={<SparkleIcon />}>남은 3장 생성 · 12 크레딧</Button></>}
        />
      }
      panel={canvas({ index: 1, template: "표지", options: OPTIONS, hint: "캔버스에서 배경을 끌어 잘릴 위치를 맞춥니다 · ⌘Enter로 남은 슬라이드를 생성합니다" })}
    />
  );
}

function StylePanel() {
  return (
    <div className="sc-overlay-pop">
      <Popover variant="setting" placement="static" style={{ width: 400, maxHeight: "none", padding: 18, display: "flex", flexDirection: "column", gap: 16 }} role="dialog" aria-label="스타일">
        <div className="sc-cell">
          <span style={{ fontSize: 14, fontWeight: 620 }}>스타일</span>
          <span className="sc-muted">덱 전체에 적용됩니다</span>
          <span className="sc-spacer" />
          <IconButton ghost size={28} icon={<CloseIcon />} aria-label="닫기" />
        </div>
        <div className="sc-style-grid">
          {SLIDE_PRESETS.map((p) => (
            <StyleCard
              key={p}
              pressed={p === "basic"}
              name={PRESET_NAMES[p][0]}
              description={PRESET_NAMES[p][1]}
              preview={
                <>
                  {renderSlide(DECK[0]!, 1, p, "4:5", true, { showFooter: false })}
                  {renderSlide(DECK[7]!, 8, p, "4:5", false, { showFooter: false })}
                </>
              }
            />
          ))}
        </div>
        <div className="sc-stack" style={{ gap: 8 }}>
          <span className="sc-label">색</span>
          <div className="sc-cell" style={{ gap: 6 }}>
            {([["배경", SLIDE_STYLES.basic.bg], ["글자", SLIDE_STYLES.basic.tx], ["강조", SLIDE_STYLES.basic.acc]] as const).map(([n, c]) => (
              <button key={n} type="button" className="sc-swatch-btn" aria-label={`${n} 색 바꾸기`}>
                <i style={{ background: c }} />
                <span className="sc-muted">{n}</span>
                <span className="sc-spacer" />
                <span style={{ color: "var(--tx)" }}>{c.toUpperCase()}</span>
              </button>
            ))}
          </div>
        </div>
        <div className="sc-row-2" style={{ gridTemplateColumns: "1fr auto", alignItems: "end", gap: 12 }}>
          <Field label="계정 핸들" htmlFor="st-handle"><Input id="st-handle" defaultValue="@sunny.skin.lab" /></Field>
          <Field label="쪽 번호"><div style={{ height: 34, display: "flex", alignItems: "center" }}><Switch checked onChange={() => {}} aria-label="쪽 번호 표시" /></div></Field>
        </div>
        <Field label="이미지 스타일" htmlFor="st-img" hint="모든 슬라이드의 프롬프트 뒤에 붙습니다"><Textarea id="st-img" rows={2} defaultValue="따뜻한 필름 톤, 자연광, 여백 많은 구도" /></Field>
        <Field label="이미지 모델">
          <Button variant="model" icon={<span className="sc-cell" style={{ width: 18, height: 18, borderRadius: 5, background: "#e8e8ec", color: "#111", fontSize: 9, fontWeight: 800, justifyContent: "center" }}>F2</span>} style={{ justifyContent: "flex-start" }}>
            Flux 2 <span className="sc-muted">4 크레딧 / 장</span>
            <span className="sc-spacer" />
            <CaretDownIcon />
          </Button>
        </Field>
      </Popover>
    </div>
  );
}

export function EditorStyle() {
  const states: ThumbState[] = [...Array<ThumbState>(7).fill("image"), "flat"];
  return (
    <EditorShell
      rows={storyRows(states, 0)}
      strip={
        <ActionStrip
          status={<><CheckIcon size={15} />8장 모두 완성 · 내보낼 준비가 됐습니다</>}
          actions={<><Button icon={<PlusIcon />}>슬라이드 추가</Button><Button variant="primary" size="lg" icon={<SparkleIcon />} disabled>남은 슬라이드 없음</Button></>}
        />
      }
      panel={canvas({ index: 1, template: "표지", options: OPTIONS, hint: "스타일을 바꾸면 여덟 장이 모두 다시 그려집니다 · 이미지는 그대로입니다" })}
      exportPrimary
      styleOpen
      overlay={<StylePanel />}
    />
  );
}

function ExportDialog() {
  const caption = "SPF 50이면 하루 종일 안심일까요? 숫자보다 중요한 건 덧바르는 습관이에요. 출퇴근·야외·물놀이 상황별로 어떤 지수를 고르면 되는지, 성분표에서 무엇을 봐야 하는지 8장에 정리했어요. 저장해 두고 여름 내내 꺼내 보세요.";
  const tags = ["자외선차단제", "선크림추천", "여름피부관리", "스킨케어팁", "SPF", "PA등급", "덧바르기"].map((t) => `#${t}`).join(" ");
  return (
    <div className="sc-scrim">
      <Dialog open inline title="내보내기" onClose={() => {}} closeLabel="닫기" width={600} head={<span className="sc-muted">8장 · 1080×1350 · 크레딧을 쓰지 않습니다</span>}>
        <div className="sc-cell" style={{ gap: 6 }}>
          {DECK.map((s, i) => (
            <Thumb key={i} size={52} state={s.photo ? "image" : "flat"} src={s.photo ? PHOTOS[s.photo] : undefined} />
          ))}
        </div>
        <div className="sc-cell" style={{ gap: 6 }}>
          <span className="sc-label" style={{ width: 44 }}>형식</span>
          <Chip pressed>PNG</Chip>
          <Chip pressed={false}>JPG</Chip>
          <span className="sc-muted" style={{ marginLeft: 6 }}>01.png ~ 08.png와 caption.txt를 ZIP으로 묶습니다</span>
        </div>
        <Field label="캡션" htmlFor="ex-cap" counter={{ value: caption.length, max: 400 }}>
          <Textarea id="ex-cap" rows={3} defaultValue={caption} />
          <div className="sc-hashtags">{tags}</div>
        </Field>
        <div className="sc-cell">
          <Button size="lg" icon={<CopyIcon />} style={{ flex: 1 }}>캡션 복사</Button>
          <Button variant="primary" size="lg" icon={<DownloadIcon />} style={{ flex: 1 }}>ZIP 내려받기</Button>
        </div>
      </Dialog>
    </div>
  );
}

export function EditorExport() {
  const states: ThumbState[] = [...Array<ThumbState>(7).fill("image"), "flat"];
  return (
    <EditorShell
      rows={storyRows(states, 7)}
      strip={
        <ActionStrip
          status={<><CheckIcon size={15} />8장 모두 완성</>}
          actions={<><Button icon={<PlusIcon />}>슬라이드 추가</Button><Button variant="primary" size="lg" icon={<SparkleIcon />} disabled>남은 슬라이드 없음</Button></>}
        />
      }
      panel={canvas({ index: 8, template: "CTA", options: [["위치", "가운데"], ["어둡게", "60%"]], hint: "CTA는 기본이 단색 배경입니다 · 배경을 넣으려면 다시 생성을 누르세요" })}
      exportPrimary
      overlay={<ExportDialog />}
    />
  );
}
```

- [ ] **Step 4: 휴대폰, 템플릿, 스타일, 크레딧 모달**

`design/showcase/screens/Phone.tsx`:

```tsx
import { Avatar, HeartIcon, PhoneIcon } from "@/index";

import { DECK } from "../data";
import { renderSlide } from "../lib/slide";
import { Screen } from "./shell";

export function Phone() {
  return (
    <Screen width={390} height={844}>
      <div className="sc-phone-head">
        <Avatar initials="S" size={32} />
        <div style={{ display: "flex", flexDirection: "column" }}>
          <span style={{ fontWeight: 600 }}>sunny.skin.lab</span>
          <span className="sc-muted" style={{ fontSize: 11 }}>협찬 아님 · 원본 오디오</span>
        </div>
      </div>
      <div style={{ position: "relative", flexShrink: 0 }}>
        {renderSlide(DECK[0]!, 1, "basic", "4:5", true, { style: { borderRadius: 0 } })}
        <span className="sc-badge">1/8</span>
      </div>
      <div className="sc-phone-actions">
        <HeartIcon size={22} />
        <div className="sc-dots">{DECK.map((_, i) => <i key={i} />)}</div>
      </div>
      <div className="sc-phone-caption">
        <span style={{ fontWeight: 600 }}>좋아요 1,284개</span>
        <span><b style={{ fontWeight: 600 }}>sunny.skin.lab</b> SPF 50이면 하루 종일 안심일까요? 숫자보다 중요한 건 덧바르는 습관이에요… <span className="sc-muted">더 보기</span></span>
        <span className="sc-muted">댓글 36개 모두 보기</span>
      </div>
      <span className="sc-spacer" />
      <div className="sc-phone-foot">
        <span className="ohf-credit"><PhoneIcon size={13} />휴대폰 미리보기 · 인스타그램 피드</span>
        <span className="sc-muted">옆으로 넘겨 보세요</span>
      </div>
    </Screen>
  );
}
```

`design/showcase/screens/Templates.tsx`:

```tsx
import { Tag } from "@/index";

import { DECK } from "../data";
import { renderSlide } from "../lib/slide";
import { Screen } from "./shell";

const SPECS: [number, string, string][] = [
  [0, "제목 28자 · 부제 24자 · 꼬리표 12자(선택)", "위치 · 제목 크기 · 어둡게 40%"],
  [1, "제목 24자 · 본문 90자", "위치 · 어둡게 55%"],
  [2, "제목 20자 · 항목 3~5개, 항목당 24자", "번호 표시 · 어둡게 75%"],
  [3, "인용문 60자 · 출처 20자(선택)", "위치 · 어둡게 60%"],
  [7, "제목 24자 · 부제 30자(선택)", "위치 · 기본은 단색 배경"],
];

export function Templates() {
  return (
    <Screen width={1440} height={520}>
      <div className="sc-page" style={{ width: "100%", padding: "28px 32px" }}>
        <div className="sc-page-head" style={{ alignItems: "baseline" }}>
          <h1 className="sc-page-title" style={{ fontSize: 20 }}>템플릿 5종</h1>
          <span className="sc-muted">한 덱의 다섯 장 · 기본 고딕 스타일 · 1080×1350을 256px로 줄여 실제 글꼴로 조판</span>
        </div>
        <div className="sc-cols">
          {SPECS.map(([i, limits, opts]) => (
            <div key={i} className="sc-col">
              {renderSlide(DECK[i]!, i + 1, "basic")}
              <div className="sc-cell"><span style={{ fontSize: 14, fontWeight: 620 }}>{DECK[i]!.label}</span><Tag tone="muted">{DECK[i]!.kind}</Tag></div>
              <span className="sc-muted" style={{ color: "var(--tx2)" }}>{limits}</span>
              <span className="sc-muted">옵션: {opts}</span>
            </div>
          ))}
        </div>
      </div>
    </Screen>
  );
}
```

`design/showcase/screens/Styles.tsx`:

```tsx
import { SLIDE_PRESETS, SLIDE_STYLES, Tag } from "@/index";

import { DECK } from "../data";
import { renderSlide } from "../lib/slide";
import { Screen } from "./shell";

const INFO = {
  basic: ["기본 고딕", "Pretendard · 남색, 흰색, 노랑", "범용 · 기본값"],
  editorial: ["에디토리얼", "Noto Serif KR 제목 + Pretendard 본문 · 크림, 짙은 갈색, 벽돌색", "매거진, 뷰티, 라이프스타일"],
  impact: ["임팩트", "Black Han Sans 제목 + Pretendard 본문 · 검정, 흰색, 주홍", "정보성, 뉴스, 할인 공지"],
  soft: ["부드럽게", "Gowun Dodum · 세이지, 짙은 초록, 초록", "육아, 웰니스, 카페"],
} as const;

export function Styles() {
  return (
    <Screen width={1440} height={440}>
      <div className="sc-page" style={{ width: "100%", padding: "28px 32px" }}>
        <div className="sc-page-head" style={{ alignItems: "baseline" }}>
          <h1 className="sc-page-title" style={{ fontSize: 20 }}>스타일 4종</h1>
          <span className="sc-muted">글꼴 쌍 + 색 세 개(배경·글자·강조) · 왼쪽은 사진 위 표지, 오른쪽은 단색 CTA · 모두 OFL 글꼴</span>
        </div>
        <div className="sc-cols" style={{ gap: 16 }}>
          {SLIDE_PRESETS.map((p) => {
            const s = SLIDE_STYLES[p];
            return (
              <div key={p} className="sc-style-col" data-default={p === "basic"}>
                <div className="sc-style-pair">
                  {renderSlide(DECK[0]!, 1, p)}
                  {renderSlide(DECK[7]!, 8, p, "4:5", false)}
                </div>
                <div className="sc-cell">
                  <span style={{ fontSize: 14, fontWeight: 620 }}>{INFO[p][0]}</span>
                  {p === "basic" && <Tag tone="accent">기본값</Tag>}
                  <span className="sc-spacer" />
                  <span className="sc-chips">{[s.bg, s.tx, s.acc].map((c) => <i key={c} style={{ background: c }} />)}</span>
                </div>
                <span className="sc-muted" style={{ color: "var(--tx2)" }}>{INFO[p][1]}</span>
                <span className="sc-muted">{INFO[p][2]}</span>
              </div>
            );
          })}
        </div>
      </div>
    </Screen>
  );
}
```

`design/showcase/screens/CreditsModal.tsx`:

```tsx
import { Button, Dialog } from "@/index";
import { PlusIcon, SparkleIcon } from "@/index";

export function CreditsModal() {
  return (
    <div style={{ width: 520, padding: 20 }}>
      <Dialog open inline title="크레딧이 부족합니다" onClose={() => {}} closeLabel="닫기" width={480} head={<span className="sc-muted">남은 3장 · 12 크레딧 필요</span>}>
        <div className="sc-row-3" style={{ gap: 8 }}>
          <div className="sc-stat"><span className="sc-muted">필요</span><b>12</b></div>
          <div className="sc-stat"><span className="sc-muted">잔액</span><b>4</b></div>
          <div className="sc-stat sc-stat--danger"><span style={{ fontSize: 11 }}>부족</span><b>8</b></div>
        </div>
        <span className="sc-muted">지금은 1장만 생성할 수 있습니다. 나머지는 충전한 뒤 이어서 생성할 수 있고, 문구 편집과 내보내기는 계속 됩니다.</span>
        <div className="sc-cell">
          <Button size="lg" icon={<SparkleIcon />} style={{ flex: 1 }}>1장만 생성 · 4 크레딧</Button>
          <Button variant="primary" size="lg" icon={<PlusIcon />} style={{ flex: 1 }}>충전하기</Button>
        </div>
      </Dialog>
    </div>
  );
}
```

- [ ] **Step 5: 화면 섹션 연결**

`design/showcase/sections/Screens.tsx`(교체):

```tsx
import { Chip } from "@/index";

import { Account } from "../screens/Account";
import { CreditsModal } from "../screens/CreditsModal";
import { EditorExport, EditorGenerating, EditorOutline, EditorStyle } from "../screens/Editors";
import { NewProject } from "../screens/NewProject";
import { Phone } from "../screens/Phone";
import { Projects } from "../screens/Projects";
import { Styles } from "../screens/Styles";
import { Templates } from "../screens/Templates";

const SCREENS = [
  { id: "projects", label: "프로젝트 목록", view: Projects },
  { id: "new", label: "새 프로젝트", view: NewProject },
  { id: "account", label: "계정 · 크레딧", view: Account },
  { id: "editor-outline", label: "편집기 ① 구성안", view: EditorOutline },
  { id: "editor-generating", label: "편집기 ② 생성 중", view: EditorGenerating },
  { id: "editor-style", label: "편집기 ③ 스타일", view: EditorStyle },
  { id: "editor-export", label: "편집기 ④ 내보내기", view: EditorExport },
  { id: "phone", label: "휴대폰 미리보기", view: Phone },
  { id: "templates", label: "템플릿 5종", view: Templates },
  { id: "styles", label: "스타일 4종", view: Styles },
  { id: "credits", label: "크레딧 부족 모달", view: CreditsModal },
];

export function Screens({ sub }: { sub?: string }) {
  const screen = SCREENS.find((s) => s.id === sub) ?? SCREENS[0]!;
  const View = screen.view;
  return (
    <>
      <h1 className="sc-h1">화면</h1>
      <p className="sc-lead">시안 11장을 실제 컴포넌트로 조립했다. 라임 버튼은 한 화면에 하나.</p>
      <div className="sc-toolbar">
        {SCREENS.map((s) => (
          <Chip key={s.id} pressed={s.id === screen.id} onClick={() => { location.hash = `screens/${s.id}`; }}>
            {s.label}
          </Chip>
        ))}
      </div>
      <div className="sc-frame">
        <View />
      </div>
    </>
  );
}
```

- [ ] **Step 6: 검증**

Run: `corepack pnpm typecheck && corepack pnpm test && corepack pnpm build:showcase`
Expected: 전부 통과. 타입 오류가 나면 대개 `data-state`·`aria-*`를 받지 않는 컴포넌트에 넘긴 것이다 — 해당 컴포넌트의 props가 `HTMLAttributes`를 확장하는지 확인한다.

Run: `corepack pnpm dev` 후 `http://localhost:5173/#screens/projects` … `#screens/credits` 11개를 차례로 연다.
Expected: 각 화면이 시안(https://claude.ai/artifact/M7Fbz6EVzSkYpGYqsLMtLt)과 같은 구성으로 보인다. 확인 항목: 편집기 4상태의 스토리보드 행 상태(선택 라임 막대, 생성 중 점, 실패 빨강, 글자 수 초과 빨간 카운터), 스타일 패널의 StyleCard 4장, 내보내기 모달, 휴대폰 390px. 콘솔 오류 없음. 확인 후 서버를 끈다. (브라우저를 쓸 수 없는 실행자는 건너뛰고 보고에 적는다.)

---

