# Task 12 report — 쇼케이스: 화면 11장

## 구현 내용

브리프의 Step 1–5를 순서대로 구현했다.

- `design/showcase/screens/shell.tsx` (신규) — `AppBar`, `Screen`, `EditorShell` 공통 껍데기.
- `design/showcase/screens/editor.tsx` (신규) — `storyRows()`, `canvas()` 편집기 조각 헬퍼.
- `design/showcase/screens/Projects.tsx` (신규) — 프로젝트 목록.
- `design/showcase/screens/NewProject.tsx` (신규) — 새 프로젝트.
- `design/showcase/screens/Account.tsx` (신규) — 계정 · 크레딧.
- `design/showcase/screens/Editors.tsx` (신규) — 편집기 4상태(`EditorOutline`, `EditorGenerating`, `EditorStyle`, `EditorExport`) + 내부 `StylePanel`, `ExportDialog`.
- `design/showcase/screens/Phone.tsx` (신규) — 휴대폰 미리보기.
- `design/showcase/screens/Templates.tsx` (신규) — 템플릿 5종.
- `design/showcase/screens/Styles.tsx` (신규) — 스타일 4종.
- `design/showcase/screens/CreditsModal.tsx` (신규) — 크레딧 부족 모달.
- `design/showcase/sections/Screens.tsx` (교체) — 11개 화면을 해시 라우팅으로 연결.

브리프에 실린 코드를 값 그대로 옮겨 적었다. 구현 전 각 컴포넌트/컴포지트(TopBar, ProjectHeader, BriefBar, CanvasPanel, StoryboardRow, ProjectCard, FormatCard, StyleCard, ActionStrip, Button, Pill, Tag, Chip, IconButton, Avatar, Field, Input, Stepper, Textarea, Dialog, Popover, Switch, Thumb, SlideFrame/SLIDE_PRESETS/SLIDE_STYLES, Segment, cx)의 실제 `.tsx` prop 정의를 전부 읽고 브리프 사용부와 하나하나 대조했다 — 모두 실제 API와 정확히 일치해 시그니처 관련 수정은 필요 없었다.

## 브리프 대비 편차

1. **`editor.tsx`의 `storyRows()`에 `onSelect={() => {}}`를 추가.** 팀 리드가 준 컨텍스트대로, Task 12 브리프가 작성된 이후 `StoryboardRow`가 바뀌어 `onSelect`가 주어지고 `editing`이 false일 때만 제목이 실제 `<button class="ohf-sb-title ohf-sb-select">`(행 전체를 덮는 `::after`)로 렌더링된다. 브리프의 원래 `storyRows()` 호출에는 `onSelect`가 없어 제목이 그냥 `<div>`로 남아 행이 선택 가능한 컨트롤로 보이지 않았다. 쇼케이스는 정적 데모라 실제로 선택 상태를 바꿀 필요는 없으므로 no-op 콜백(`() => {}`)만 추가했다 — 라이브러리 코드는 건드리지 않았고, `StoryboardRow.scss`를 확인해 `.ohf-sb-actions`가 이미 `z-index: 1`로 select 버튼의 스트레치 히트영역 위에 있어 선택된 행의 IconButton(다시 쓰기/복제/삭제)들은 onSelect 추가와 무관하게 그대로 클릭 가능함을 확인했다.

그 외에는 브리프 코드를 수정 없이 그대로 옮겼다. `showcase.scss`의 `sc-*` 클래스(`.sc-screen`, `.sc-page`, `.sc-editor*`, `.sc-overlay-pop`, `.sc-scrim`, `.sc-style-grid`, `.sc-swatch-btn`, `.sc-hashtags`, `.sc-stat*`, `.sc-phone-*`, `.sc-badge`, `.sc-cols`, `.sc-col`, `.sc-style-col`, `.sc-style-pair`, `.sc-chips` 등)은 모두 Task 11에서 이미 정의돼 있었고, 빠진 것이 없어 `showcase.scss`는 손대지 않았다.

## 테스트

```
corepack pnpm typecheck   →  통과 (에러 없음)
corepack pnpm test        →  Test Files 44 passed (44), Tests 91 passed (91)
corepack pnpm build       →  dist ok (dist/index.js 45.40 kB, dist/ohf.css 78.65 kB)
corepack pnpm build:showcase → 통과 (dist-showcase 생성)
```

## 브라우저 검증

기존에 떠 있던 Vite dev 서버(http://127.0.0.1:5173/, 새로 띄우거나 끄지 않음)로 확인.

- `curl`로 `showcase/sections/Screens.tsx` 및 `showcase/screens/*.tsx` 10개 파일 전부 HTTP 200 확인(Vite 변환 에러 없음).
- Claude-in-Chrome으로 11개 화면(`#screens/projects`, `new`, `account`, `editor-outline`, `editor-generating`, `editor-style`, `editor-export`, `phone`, `templates`, `styles`, `credits`)을 전부 열어 스크린샷으로 확인:
  - 편집기 4상태의 스토리보드 행 상태 확인됨: 선택 행 라임 좌측 바(`editor-outline` 1행), 생성 중 점 애니메이션 + "생성 중 · 0:42"(`editor-generating` 4행), 실패 빨강 아이콘 + "생성 실패 · 4 크레딧 돌려드림" + 다시 시도 버튼(`editor-generating` 5행), 글자 수 초과 빨간 카운터 "96 / 90"(`editor-outline` 5행).
  - 스타일 패널의 `StyleCard` 4장(기본 고딕/에디토리얼/임팩트/부드럽게) 모두 렌더링, 기본 고딕에 체크 표시.
  - 내보내기 모달: 8장 썸네일, PNG/JPG 칩, 캡션 필드 + 해시태그, 캡션 복사/ZIP 내려받기 버튼 확인.
  - 휴대폰 미리보기 390px 폭, 인스타그램 피드 톤(아바타/좋아요/캡션/하단바) 확인.
  - `read_console_messages`(onlyErrors)로 세션 전체에서 콘솔 에러/예외 없음 확인.
- 확인 후 브라우저 탭은 닫았다(dev 서버 자체는 요청대로 끄지 않고 그대로 둠).

## 자체 점검

- 완전성: Files 목록의 10개 신규 파일 + 1개 교체 파일 전부 작성, Step 1–6 모두 수행.
- 품질: 디버그 잔재 없음, `corepack pnpm test`/`typecheck` 출력 모두 깨끗함.
- 규율: 브리프가 요구한 파일 외에는 손대지 않음(`showcase.scss`, `data.ts`, `lib/slide.tsx`, `src/` 모두 미변경). 라이브러리 API는 전부 그대로 사용, 어댑테이션은 위 1건뿐.
- 우려사항: 없음.

---

**Status:** DONE
테스트: `typecheck` 통과 · `test` 91/91 통과 · `build` dist ok · `build:showcase` 통과 · 브라우저 11개 화면 콘솔 에러 없음 확인
편차: `storyRows()`에 `onSelect={() => {}}` 추가(팀 리드 컨텍스트에 따른 StoryboardRow API 변경 반영, no-op)
우려: 없음
보고서: `/Users/brian/works/agent/openhigsfield/.superpowers/sdd/2026-09-18-design-system/task-12-report.md`
