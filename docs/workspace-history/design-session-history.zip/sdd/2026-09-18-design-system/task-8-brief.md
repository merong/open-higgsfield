### Task 8: 기본 요소 3묶음 — Skeleton, Thumb, Popover/Menu/MenuRow, Dialog, Alert, UndoBar, Tooltip

**Files:**
- Create: `design/src/components/{Skeleton,Thumb,Popover,Dialog,Alert,UndoBar,Tooltip}/…`
- Modify: `design/src/index.ts`

**Interfaces:**
- Consumes: `cx`, `ratioToCss`, `IconButton`, 아이콘 `WarningIcon`, `CloseIcon`, `UndoIcon`.
- Produces:
  - `Skeleton({ label?, clock?, ratio? })` → `[role=status].ohf-skeleton`
  - `Thumb({ state: "image"|"pending"|"failed"|"empty"|"flat", src?, alt?, size?, ratio?, flatColor?, flatAccent?, icon? })` → `.ohf-frame.ohf-frame--<state>`; `ThumbState`, `ThumbProps`
  - `Popover({ variant: "setting"|"list"|"picker"|"menu"|"assets", placement?: "up"|"down"|"static", head?, x?, y? })` → `.ohf-popover.ohf-popover--<variant>`; `Menu` → `[role=menu].ohf-menu`; `MenuRow({ icon?, label, count? })` → `[role=menuitem].ohf-menu-row`
  - `Dialog({ open, title, onClose, width?, closeLabel, head?, inline?, children })` → `<dialog>` + `.ohf-dialog-panel`
  - `Alert({ icon?, action?, children })` → `[role=alert].ohf-alert`
  - `UndoBar({ text, actionLabel, onAction, durationMs, icon? })` → `.ohf-undo`
  - `Tooltip({ label, align?: "start"|"end", children })` → `.ohf-tip[data-tip]`

- [ ] **Step 1: 실패하는 테스트 작성(7개 파일)**

`design/src/components/Skeleton/Skeleton.test.tsx`:

```tsx
import { render, screen } from "@testing-library/react";
import { expect, it } from "vitest";

import { Skeleton } from "./Skeleton";

it("is a status plate with a label and a clock", () => {
  render(<Skeleton label="생성 중" clock="0:42" ratio="4:5" />);
  const el = screen.getByRole("status");
  expect(el).toHaveClass("ohf-skeleton");
  expect(el.style.aspectRatio).toBe("4 / 5");
  expect(screen.getByText("생성 중")).toHaveClass("ohf-skeleton-label");
  expect(screen.getByText("0:42")).toHaveClass("ohf-skeleton-clock");
});
```

`design/src/components/Thumb/Thumb.test.tsx`:

```tsx
import { render } from "@testing-library/react";
import { expect, it } from "vitest";

import { Thumb } from "./Thumb";

it("renders each of the five states as a modifier", () => {
  for (const state of ["image", "pending", "failed", "empty", "flat"] as const) {
    const { container, unmount } = render(<Thumb state={state} src="/a.png" size={56} />);
    expect(container.firstChild).toHaveClass("ohf-frame", `ohf-frame--${state}`);
    unmount();
  }
});

it("shows the picture only in the image state and sizes itself by width and ratio", () => {
  const { container } = render(<Thumb state="image" src="/a.png" alt="표지" size={80} ratio="1:1" />);
  const el = container.firstChild as HTMLElement;
  expect(el.querySelector("img")).toHaveAttribute("alt", "표지");
  expect(el.style.width).toBe("80px");
  expect(el.style.aspectRatio).toBe("1 / 1");
});
```

`design/src/components/Popover/Popover.test.tsx`:

```tsx
import { render, screen } from "@testing-library/react";
import { expect, it } from "vitest";

import { Menu, MenuRow, Popover } from "./Popover";

it("wears the variant and placement as modifiers and a head", () => {
  const { container } = render(
    <Popover variant="menu" placement="static" head="정렬">
      <Menu>
        <MenuRow icon={<svg />} label="최근 수정" count={5} />
      </Menu>
    </Popover>,
  );
  expect(container.firstChild).toHaveClass("ohf-popover", "ohf-popover--menu", "ohf-popover--static");
  expect(container.querySelector(".ohf-pop-head")).toHaveTextContent("정렬");
  expect(screen.getByRole("menu")).toHaveClass("ohf-menu");
  expect(screen.getByRole("menuitem", { name: /최근 수정/ })).toHaveClass("ohf-menu-row");
  expect(container.querySelector(".ohf-menu-count")).toHaveTextContent("5");
});

it("positions itself through the studio's custom properties", () => {
  const { container } = render(<Popover variant="setting" x={120} y={48} />);
  const el = container.firstChild as HTMLElement;
  expect(el.style.getPropertyValue("--ohf-pop-x")).toBe("120px");
  expect(el.style.getPropertyValue("--ohf-pop-y")).toBe("48px");
});
```

`design/src/components/Dialog/Dialog.test.tsx`:

```tsx
import { fireEvent, render, screen } from "@testing-library/react";
import { expect, it, vi } from "vitest";

import { Dialog } from "./Dialog";

it("opens as a modal dialog with a title and a close button", () => {
  const onClose = vi.fn();
  render(
    <Dialog open title="내보내기" onClose={onClose} closeLabel="닫기" width={600}>
      <p>8장</p>
    </Dialog>,
  );
  const dialog = screen.getByRole("dialog", { name: "내보내기" });
  expect(dialog).toHaveAttribute("aria-modal", "true");
  expect(dialog.querySelector<HTMLElement>(".ohf-dialog-panel")?.style.width).toBe("600px");
  fireEvent.click(screen.getByRole("button", { name: "닫기" }));
  expect(onClose).toHaveBeenCalledTimes(1);
});

it("renders inline as a plain dialog box when asked", () => {
  const { container } = render(
    <Dialog open inline title="크레딧 부족" onClose={() => {}} closeLabel="닫기">
      <p>12</p>
    </Dialog>,
  );
  expect(container.querySelector("dialog")).toBeNull();
  expect(screen.getByRole("dialog", { name: "크레딧 부족" })).toHaveClass("ohf-dialog-panel");
});
```

`design/src/components/Alert/Alert.test.tsx`:

```tsx
import { render, screen } from "@testing-library/react";
import { expect, it } from "vitest";

import { Alert } from "./Alert";

it("is an alert strip with an icon, text and an optional action", () => {
  render(<Alert action={<button type="button">다시 시도</button>}>생성 실패</Alert>);
  const el = screen.getByRole("alert");
  expect(el).toHaveClass("ohf-alert");
  expect(el.querySelector(".ohf-alert-ic svg")).not.toBeNull();
  expect(el.querySelector(".ohf-alert-text")).toHaveTextContent("생성 실패");
  expect(screen.getByRole("button", { name: "다시 시도" })).toBeInTheDocument();
});
```

`design/src/components/UndoBar/UndoBar.test.tsx`:

```tsx
import { fireEvent, render, screen } from "@testing-library/react";
import { expect, it, vi } from "vitest";

import { UndoBar } from "./UndoBar";

it("drains over the given window and offers the undo", () => {
  const onAction = vi.fn();
  const { container } = render(<UndoBar text="슬라이드 5를 지웠습니다" actionLabel="되돌리기" onAction={onAction} durationMs={6000} />);
  expect(container.firstChild).toHaveClass("ohf-undo");
  expect(container.querySelector<HTMLElement>(".ohf-undo-drain")?.style.animationDuration).toBe("6000ms");
  fireEvent.click(screen.getByRole("button", { name: "되돌리기" }));
  expect(onAction).toHaveBeenCalledTimes(1);
});
```

`design/src/components/Tooltip/Tooltip.test.tsx`:

```tsx
import { render } from "@testing-library/react";
import { expect, it } from "vitest";

import { Tooltip } from "./Tooltip";

it("carries the label in data-tip and the alignment as a modifier", () => {
  const { container } = render(
    <Tooltip label="복제" align="end">
      <button type="button">c</button>
    </Tooltip>,
  );
  expect(container.firstChild).toHaveClass("ohf-tip", "ohf-tip--end");
  expect(container.firstChild).toHaveAttribute("data-tip", "복제");
});
```

Run: `corepack pnpm test src/components`
Expected: 새 7개 파일 FAIL(모듈 없음).

- [ ] **Step 2: Skeleton, Thumb 구현**

`design/src/components/Skeleton/Skeleton.tsx`:

```tsx
import type { HTMLAttributes, ReactNode } from "react";

import { cx } from "@/lib/cx";
import { ratioToCss } from "@/lib/ratio";

export interface SkeletonProps extends HTMLAttributes<HTMLDivElement> {
  label?: ReactNode;
  clock?: ReactNode;
  ratio?: string;
}

export function Skeleton({ label, clock, ratio, className, style, ...rest }: SkeletonProps) {
  return (
    <div
      className={cx("ohf-skeleton", className)}
      role="status"
      style={ratio ? { ...style, aspectRatio: ratioToCss(ratio, "4 / 3") } : style}
      {...rest}
    >
      {label !== undefined && <span className="ohf-skeleton-label">{label}</span>}
      {clock !== undefined && <span className="ohf-skeleton-clock">{clock}</span>}
    </div>
  );
}
```

`design/src/components/Skeleton/index.ts`: `export * from "./Skeleton";`

`design/src/components/Thumb/Thumb.tsx`:

```tsx
import type { HTMLAttributes, ReactNode } from "react";

import { WarningIcon } from "@/icons";
import { cx } from "@/lib/cx";
import { ratioToCss } from "@/lib/ratio";

import "./Thumb.scss";

export type ThumbState = "image" | "pending" | "failed" | "empty" | "flat";

export interface ThumbProps extends HTMLAttributes<HTMLDivElement> {
  state: ThumbState;
  src?: string;
  alt?: string;
  /* Width in px; the height follows the ratio. */
  size?: number;
  ratio?: string;
  /* The flat state stands in for a slide with no picture: the deck's own
     background and accent, so they arrive from the slide style, not from here. */
  flatColor?: string;
  flatAccent?: string;
  icon?: ReactNode;
}

export function Thumb({
  state,
  src,
  alt = "",
  size = 56,
  ratio = "4:5",
  flatColor = "#1d2a44",
  flatAccent = "#ffd54a",
  icon,
  className,
  style,
  ...rest
}: ThumbProps) {
  return (
    <div
      className={cx("ohf-frame", `ohf-frame--${state}`, className)}
      style={{
        ...style,
        width: size,
        aspectRatio: ratioToCss(ratio, "4 / 5"),
        ...(state === "flat" ? { background: flatColor, color: flatAccent } : null),
      }}
      {...rest}
    >
      {state === "image" && src && <img className="ohf-frame-img" src={src} alt={alt} />}
      {state === "pending" && (
        <>
          <span className="ohf-frame-lamp" aria-hidden="true" />
          <span className="ohf-frame-line ohf-frame-line--1" aria-hidden="true" />
          <span className="ohf-frame-line ohf-frame-line--2" aria-hidden="true" />
        </>
      )}
      {state === "failed" && <span className="ohf-frame-icon">{icon ?? <WarningIcon size={18} />}</span>}
      {state === "flat" && (
        <>
          <span className="ohf-frame-bar ohf-frame-bar--1" aria-hidden="true" />
          <span className="ohf-frame-bar ohf-frame-bar--2" aria-hidden="true" />
          <span className="ohf-frame-bar ohf-frame-bar--pill" aria-hidden="true" />
        </>
      )}
    </div>
  );
}
```

`design/src/components/Thumb/Thumb.scss`:

```scss
.ohf-frame {
  position: relative;
  overflow: hidden;
  flex-shrink: 0;
  border-radius: 5px;
  background: var(--s3);

  &--pending {
    background: var(--s2);
    border: 1px solid var(--line-2);
  }
  &--failed {
    display: flex;
    align-items: center;
    justify-content: center;
    background: var(--danger-bg);
    border: 1px solid var(--danger-line);
    color: var(--danger);
  }
  &--empty {
    background: transparent;
    border: 1px dashed var(--line-2);
  }
  &--flat {
    display: flex;
    flex-direction: column;
    justify-content: center;
    gap: 4px;
    padding: 18% 14%;
  }
}
.ohf-frame-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
/* The pending lamp is the same pulse the platform lamp carries. */
.ohf-frame-lamp {
  position: absolute;
  top: 5px;
  right: 5px;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--accent);
  box-shadow: 0 0 0 3px var(--accent-14);
  animation: ohf-pulse 2.4s ease-in-out infinite;
}
.ohf-frame-line {
  position: absolute;
  left: 14%;
  height: 5px;
  border-radius: 3px;
  background: var(--s4);
  &--1 {
    right: 14%;
    bottom: 20%;
  }
  &--2 {
    right: 40%;
    bottom: 36%;
  }
}
.ohf-frame-icon {
  display: flex;
}
.ohf-frame-bar {
  height: 4px;
  border-radius: 2px;
  background: rgba(255, 255, 255, 0.85);
  &--1 {
    width: 70%;
  }
  &--2 {
    width: 55%;
  }
  &--pill {
    width: 40%;
    height: 6px;
    margin-top: 2px;
    border-radius: 3px;
    background: transparent;
    border: 1px solid currentColor;
  }
}
```

`design/src/components/Thumb/index.ts`: `export * from "./Thumb";`

- [ ] **Step 3: Popover, Menu, MenuRow 구현**

`design/src/components/Popover/Popover.tsx`:

```tsx
import type { ButtonHTMLAttributes, CSSProperties, HTMLAttributes, ReactNode, Ref } from "react";

import { cx } from "@/lib/cx";

import "./Popover.scss";

export type PopoverVariant = "setting" | "list" | "picker" | "menu" | "assets";

export interface PopoverProps extends HTMLAttributes<HTMLDivElement> {
  variant: PopoverVariant;
  /* "up" is the studio's own (anchored above the composer). "static" takes the
     panel out of the flow of positioning, for previews. */
  placement?: "up" | "down" | "static";
  head?: ReactNode;
  x?: number;
  y?: number;
  ref?: Ref<HTMLDivElement>;
}

export function Popover({ variant, placement = "up", head, x, y, className, style, children, ...rest }: PopoverProps) {
  const pos = {
    ...(x !== undefined ? { "--ohf-pop-x": `${x}px` } : null),
    ...(y !== undefined ? { "--ohf-pop-y": `${y}px` } : null),
  } as CSSProperties;
  return (
    <div
      className={cx("ohf-popover", `ohf-popover--${variant}`, placement !== "up" && `ohf-popover--${placement}`, className)}
      style={{ ...pos, ...style }}
      {...rest}
    >
      {head !== undefined && <div className="ohf-pop-head">{head}</div>}
      {children}
    </div>
  );
}

export function Menu({ className, ...rest }: HTMLAttributes<HTMLDivElement>) {
  return <div role="menu" className={cx("ohf-menu", className)} {...rest} />;
}

export interface MenuRowProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, "children"> {
  icon?: ReactNode;
  label: ReactNode;
  count?: ReactNode;
  ref?: Ref<HTMLButtonElement>;
}

export function MenuRow({ icon, label, count, className, type, ...rest }: MenuRowProps) {
  return (
    <button type={type ?? "button"} role="menuitem" className={cx("ohf-menu-row", className)} {...rest}>
      {icon && <span className="ohf-menu-ic">{icon}</span>}
      <span className="ohf-menu-label">{label}</span>
      {count !== undefined && <span className="ohf-menu-count">{count}</span>}
    </button>
  );
}
```

`design/src/components/Popover/Popover.scss`:

```scss
.ohf-popover--down {
  bottom: auto;
  top: var(--ohf-pop-y, calc(100% + 10px));
  transform-origin: top left;
}
.ohf-popover--static {
  position: relative;
  top: auto;
  bottom: auto;
  left: auto;
  animation: none;
}
.ohf-menu-row[data-state="hover"] {
  background: var(--s3);
  color: var(--tx);
  .ohf-menu-ic {
    color: var(--accent);
  }
}
```

`design/src/components/Popover/index.ts`: `export * from "./Popover";`

- [ ] **Step 4: Dialog 구현**

`design/src/components/Dialog/Dialog.tsx`:

```tsx
import { useEffect, useId, useRef, type ReactNode } from "react";

import { IconButton } from "@/components/IconButton";
import { CloseIcon } from "@/icons";
import { cx } from "@/lib/cx";

import "./Dialog.scss";

export interface DialogProps {
  open: boolean;
  title: ReactNode;
  onClose: () => void;
  width?: number;
  closeLabel: string;
  /* Extra head content between the title and the close button. */
  head?: ReactNode;
  /* Inline draws the panel in the flow with no <dialog> around it — for
     previews and the showcase, where a modal would take over the page. */
  inline?: boolean;
  children: ReactNode;
  className?: string;
}

export function Dialog({ open, title, onClose, width = 480, closeLabel, head, inline = false, children, className }: DialogProps) {
  const ref = useRef<HTMLDialogElement>(null);
  const titleId = useId();

  /* The element owns its modality: showModal() traps focus and paints the
     backdrop. Where the runtime lacks it (jsdom), the open attribute stands in. */
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (open && !el.open) {
      if (typeof el.showModal === "function") el.showModal();
      if (!el.open) el.setAttribute("open", "");
    } else if (!open && el.open) {
      if (typeof el.close === "function") el.close();
      el.removeAttribute("open");
    }
  }, [open]);

  const panel = (
    <div
      className={cx("ohf-dialog-panel", inline && className)}
      style={{ width }}
      tabIndex={-1}
      role={inline ? "dialog" : undefined}
      aria-labelledby={inline ? titleId : undefined}
    >
      <div className="ohf-dialog-head">
        <div className="ohf-dialog-title" id={titleId}>
          {title}
        </div>
        {head}
        <IconButton ghost size={28} icon={<CloseIcon />} aria-label={closeLabel} onClick={onClose} />
      </div>
      <div className="ohf-dialog-body">{children}</div>
    </div>
  );

  if (inline) return open ? panel : null;
  return (
    <dialog
      ref={ref}
      className={className}
      aria-modal="true"
      aria-labelledby={titleId}
      onCancel={(event) => {
        event.preventDefault();
        onClose();
      }}
      onClick={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      {panel}
    </dialog>
  );
}
```

`design/src/components/Dialog/Dialog.scss`:

```scss
.ohf-dialog-panel {
  max-width: calc(100vw - 32px);
}
.ohf-dialog-head {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 18px 18px 0;
}
.ohf-dialog-title {
  flex: 1;
  min-width: 0;
  font-size: 16px;
  font-weight: var(--fw-display);
  letter-spacing: -0.02em;
}
.ohf-dialog-body {
  display: flex;
  flex-direction: column;
  gap: 16px;
  padding: 16px 18px 18px;
}
```

`design/src/components/Dialog/index.ts`: `export * from "./Dialog";`

- [ ] **Step 5: Alert, UndoBar, Tooltip 구현**

`design/src/components/Alert/Alert.tsx`:

```tsx
import type { HTMLAttributes, ReactNode } from "react";

import { WarningIcon } from "@/icons";
import { cx } from "@/lib/cx";

export interface AlertProps extends HTMLAttributes<HTMLDivElement> {
  icon?: ReactNode;
  action?: ReactNode;
  children: ReactNode;
}

export function Alert({ icon, action, className, children, ...rest }: AlertProps) {
  return (
    <div role="alert" className={cx("ohf-alert", className)} {...rest}>
      <span className="ohf-alert-ic">{icon ?? <WarningIcon />}</span>
      <div className="ohf-alert-text">{children}</div>
      {action}
    </div>
  );
}
```

`design/src/components/Alert/index.ts`: `export * from "./Alert";`

`design/src/components/UndoBar/UndoBar.tsx`:

```tsx
import type { ReactNode } from "react";

import { UndoIcon } from "@/icons";
import { cx } from "@/lib/cx";

export interface UndoBarProps {
  text: ReactNode;
  actionLabel: ReactNode;
  onAction: () => void;
  /* The window to change your mind, drawn by the drain bar from the same
     number that clears the record. */
  durationMs: number;
  icon?: ReactNode;
  className?: string;
}

export function UndoBar({ text, actionLabel, onAction, durationMs, icon, className }: UndoBarProps) {
  return (
    <div className={cx("ohf-undo", className)} role="status">
      <span className="ohf-undo-drain" style={{ animationDuration: `${durationMs}ms` }} aria-hidden="true" />
      <span className="ohf-undo-text">{text}</span>
      <button type="button" className="ohf-undo-act" onClick={onAction}>
        {icon ?? <UndoIcon />}
        {actionLabel}
      </button>
    </div>
  );
}
```

`design/src/components/UndoBar/index.ts`: `export * from "./UndoBar";`

`design/src/components/Tooltip/Tooltip.tsx`:

```tsx
import type { HTMLAttributes, ReactNode } from "react";

import { cx } from "@/lib/cx";

import "./Tooltip.scss";

export interface TooltipProps extends HTMLAttributes<HTMLSpanElement> {
  label: string;
  align?: "start" | "end";
  children: ReactNode;
}

export function Tooltip({ label, align, className, children, ...rest }: TooltipProps) {
  return (
    <span className={cx("ohf-tip", align && `ohf-tip--${align}`, className)} data-tip={label} {...rest}>
      {children}
    </span>
  );
}
```

`design/src/components/Tooltip/Tooltip.scss`:

```scss
.ohf-tip[data-state="hover"][data-tip]::after {
  opacity: 1;
  translate: -50% 0;
}
.ohf-tip--start[data-state="hover"][data-tip]::after,
.ohf-tip--end[data-state="hover"][data-tip]::after {
  translate: 0 0;
}
```

`design/src/components/Tooltip/index.ts`: `export * from "./Tooltip";`

- [ ] **Step 6: 공개 API와 검증**

`design/src/index.ts`에 추가:

```ts
export * from "./components/Alert";
export * from "./components/Dialog";
export * from "./components/Popover";
export * from "./components/Skeleton";
export * from "./components/Thumb";
export * from "./components/Tooltip";
export * from "./components/UndoBar";
```

Run: `corepack pnpm test && corepack pnpm typecheck && corepack pnpm build`
Expected: 전부 통과, `dist ok`. jsdom이 `HTMLDialogElement.showModal` 미구현 경고를 콘솔에 찍어도 테스트는 통과한다(`open` 속성 대체). 경고가 실패로 바뀌면 Dialog의 `typeof el.showModal === "function"` 분기를 `try { el.showModal(); } catch { /* jsdom */ }`로 바꾼다.

---

