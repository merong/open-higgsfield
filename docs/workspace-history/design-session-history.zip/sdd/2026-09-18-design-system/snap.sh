#!/usr/bin/env bash
# git 밖이라 커밋 대신 스냅샷을 BASE로 쓴다. Usage: snap.sh LABEL
set -euo pipefail
ws=$(cd "$(dirname "$0")" && pwd); root=$(cd "$ws/../../.." && pwd)
dst="$ws/snap/$1"; mkdir -p "$dst" "$root/design"
rsync -a --delete --exclude node_modules --exclude dist --exclude dist-showcase --exclude .vite --exclude pnpm-lock.yaml "$root/design/" "$dst/"
echo "snapshot $1: $(find "$dst" -type f | wc -l | tr -d ' ') files"
