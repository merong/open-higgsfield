# Task 6 Review — 기본 요소 1묶음 (cx, ratio, Spinner, Kbd, Tag, Button, IconButton, Chip, Pill, Segment)

### Spec Compliance

❌ Issues found: one binding global-convention violation (see Important), otherwise fully compliant.

- Every file the brief's "Files" list requires is present in the diff: `src/lib/{cx,ratio}.{ts,test.ts}`, all 8 component folders (`Spinner, Kbd, Tag, Button, IconButton, Chip, Pill, Segment`) each with `.tsx`/`index.ts`/`.test.tsx` (and `.scss` where the brief specifies one — correctly *absent* for Spinner and Kbd per the "no new rule needed" convention), and `src/index.ts`.
- Every component's props/return contract matches the brief's "Produces" list verbatim (`cx`, `ratioBox`/`ratioToCss`, `Spinner`, `Kbd`, `Tag`, `Button`, `IconButton`, `Chip`, `Pill`, `Segment`/`SegmentItem`/`SegmentProps`).
- `src/index.ts` (`t6/src/index.ts:5-14`) adds exactly the 10 export lines from the brief's Step 10, in the same order.
- Byte-for-byte diffed every `.tsx`/`.scss`/`.test.tsx` hunk in `review-t5..t6.diff` against the corresponding code block in `task-6-brief.md`: identical in every file. The report's claim "copied verbatim from the brief" checks out.
- Class-reuse claim verified independently (not just trusted): `.ohf-chip`, `.ohf-ctl(-glyph/-value)`, `.ohf-icon-btn`, `.ohf-tabs/.ohf-tab/.ohf-thumb`, `.ohf-kbd`, `.ohf-spinner` all have their base rule already defined in ported studio partials (`snap/t6/src/styles/studio/_popovers.scss:231`, `_dock.scss:303,314`, `_tabs.scss:3,13,34`, `_dock.scss:541`); Task 6's SCSS for those correctly adds only new modifiers/states. `.ohf-btn` and `.ohf-tag` are confirmed genuinely new (no exact `.ohf-btn`/`.ohf-tag` selector anywhere in `src/styles/studio/*.scss` — a loose grep for the substring matches only unrelated selectors like `.ohf-btn-quiet`), matching plan-header's "confirmed new class" list.
- Token-literal ban verified against `src/tokens/tokens.json`: none of this task's literal pixel/weight/duration values (20px, 11px, 30px, 5px, 7px, 9px, 12px, 13px, `#d9fe3e`) collide with an actual token value (`h-*` = 28/32/36/38/46, `radius-*` = 4/6/8/10/14/15/24/999, `fs-*` = 10.5/11.5/12.5/13/14/15/22, accent `#d1fe17`), so `test/token-rules.test.ts`'s strict check plausibly passes as reported, not just by luck of a skipped suite.
- `IconButtonProps` re-declares `"aria-label": string` after omitting it from `ButtonHTMLAttributes`, correctly type-enforcing the plan-header's "icon-only buttons require aria-label" rule (`t6/src/components/IconButton/IconButton.tsx:8`).

⚠️ Cannot verify from diff: the report's full-suite counts (17 files / 46 passed / 1 skipped), `tsc --noEmit` clean output, and the three `grep` checks on `dist/` are trusted per the reviewer instructions' testing policy (not re-run); no reason found in the code to doubt them.

### Strengths

- Diff matches the brief exactly, and independent verification (not just trusting the report) confirms the class-reuse and token-literal claims are actually true, not just asserted.
- `IconButton.scss`'s doubled-class selectors (`.ohf-icon-btn.ohf-icon-btn--28/30/36`, `t6/src/components/IconButton/IconButton.scss:5-15`) are a deliberate, well-reasoned fix for a real cascade conflict: `_composer.scss:99` sets `.ohf-icon-btn--ghost { width: 28px; height: 28px; }` at specificity (0,1,0), which would otherwise beat a `36`/`30` size modifier of equal specificity depending on stylesheet order. Raising to (0,2,0) makes the override deterministic regardless of import order — the comment correctly explains why.
- Tri-state ARIA props (`Chip`'s `aria-pressed`, `Pill`'s `aria-expanded`) correctly rely on React omitting the attribute for `undefined` vs. rendering `"false"`/`"true"` explicitly — matches both test files' assertions precisely.
- The `test/setup.ts` deviation is real, correctly diagnosed, minimally scoped, and disclosed with technical evidence: `vitest.config.ts` (`t6/vitest.config.ts`) indeed has no `test.globals: true`, which is exactly the condition under which `@testing-library/react`'s implicit auto-cleanup never registers. Every brief-provided test file for this task renders 2+ times per file, so this was a real, blocking, and correctly-fixed gap in shared scaffolding rather than scope creep.
- `Segment`'s keyboard handling (roving `tabIndex`, Arrow/Home/End, `event.preventDefault()`, refocus after change) is a correct ARIA APG tablist pattern — and it's brief-mandated, not an unrequested addition.

### Issues

#### Critical (Must Fix)
None.

#### Important (Should Fix)

- **`t6/src/components/Segment/Segment.scss:19-25` (plan-mandated) — missing `.ohf-tab[data-state="active"]` pin.** The base studio partial already defines `.ohf-tab:active { transform: scale(0.97); }` (`snap/t6/src/styles/studio/_tabs.scss:66`). Plan-header's binding "상태 고정" convention requires every interactive component to bind `:active` and `[data-state="active"]` in the same rule, and this task's own three sibling components (`Chip.scss:6-8`, `Pill.scss:6-8`, `IconButton.scss:20-22`) all correctly add that pin next to their `[data-state="hover"]` pin — only `Segment.scss` adds the hover pin (`:19-22`) and skips the paired active pin. This is present verbatim in the brief's own Step 9 code block, so it's a plan-mandated gap, not an implementer slip. Practical effect: the showcase (a later task) has no way to visually pin `.ohf-tab`'s pressed/active state via `data-state`, unlike every other component this task touches. Fix: add
  ```scss
  .ohf-tab[data-state="active"] {
    transform: scale(0.97);
  }
  ```

#### Minor (Nice to Have)

- **`t6/src/components/Button/Button.tsx:348-361` — `disabled` has no effect on the `href` (anchor) branch beyond `aria-disabled`.** `aria-disabled="true"` alone does not stop a real `<a href>` from being clicked or activated by keyboard; there's no `onClick`/`preventDefault` guard. Not brief-mandated or tested (no test exercises `disabled` together with `href`), so this is a latent a11y gap rather than a task defect — worth a note for whichever later task first uses `Button` as a disabled link.
- **`t6/src/components/IconButton/IconButton.test.tsx` — the `spin`/`data-spin` prop is untested.** It's a one-line pass-through (`data-spin={spin || undefined}`) wired correctly to the existing `[data-spin="true"] svg { animation: ohf-spin-once ... }` rule in `_popovers.scss:368-369`, so risk is low; flagging only because it's the one prop in this task's public surface with zero test coverage. Matches the brief's own test file exactly, so this is brief-mandated coverage, not an implementer gap.

### Assessment

**Task quality:** Approved

**Reasoning:** The implementation is a verified-exact match to the brief with no undisclosed deviations, and independent checks (class-reuse grep, token-value comparison, mixin/base-CSS inspection) confirm the report's claims rather than merely repeating them. The one Important finding is a small, pre-existing gap in the brief's own Segment.scss (missing an active-state pin that its three sibling components in the same task correctly include) — worth a quick follow-up but not a reason to block this task.
