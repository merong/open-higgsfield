# Task 7 report — 기본 요소 2묶음 (Field, Input, Textarea, Stepper, Switch, Slider, OptionList, Avatar, CreditBadge)

## Implemented

All 6 steps of `task-7-brief.md`, verbatim except the one deviation noted below.

- `src/components/Field/{Field.tsx, Field.scss, Field.test.tsx, index.ts}`
- `src/components/Input/{Input.tsx, Input.scss, Input.test.tsx, index.ts}`
- `src/components/Textarea/{Textarea.tsx, Textarea.test.tsx, index.ts}` — no `.scss` of its own; imports `../Input/Input.scss` as the brief specifies
- `src/components/Stepper/{Stepper.tsx, Stepper.scss, Stepper.test.tsx, index.ts}`
- `src/components/Switch/{Switch.tsx, Switch.scss, Switch.test.tsx, index.ts}`
- `src/components/Slider/{Slider.tsx, Slider.test.tsx, index.ts}` — no `.scss` (base already fully drawn by the ported studio partial, per plan-header's no-new-rule list)
- `src/components/OptionList/{OptionList.tsx, OptionList.test.tsx, index.ts}` — no `.scss`, same reason; ported verbatim from the original `open-higgsfield/src/openhiggsfield/ui.tsx` (read-only), confirmed line-for-line identical apart from prop destructuring style
- `src/components/Avatar/{Avatar.tsx, Avatar.scss, Avatar.test.tsx, index.ts}`
- `src/components/CreditBadge/{CreditBadge.tsx, CreditBadge.scss, CreditBadge.test.tsx, index.ts}`
- `src/index.ts` — added the 9 export lines from Step 6, merged alphabetically into the existing list (Avatar, Button, Chip, CreditBadge, Field, IconButton, Input, Kbd, OptionList, Pill, Segment, Slider, Spinner, Stepper, Switch, Tag, Textarea).

All file contents (tsx/scss/test) are copied verbatim from the brief except the one fix below.

Before writing each `.scss` file I checked every literal value against `src/styles/tokens/_maps.scss`'s exhaustive lists (radius 4/6/8/10/14/15/24/999px, heights 28/32/36/38/46px, font sizes 10.5/11.5/12.5/13/14/15/22px, font weights 500/550/600/620, letter-spacing −0.005/−0.015/0.16em, durations 0.12/0.15/0.2/0.34s). The brief's literals that look close to a token value are deliberately off it (`font-size: 11px` vs. `--fs-xs: 11.5px`; `letter-spacing: 0.02em` vs. the three `ls-*` tokens; `height: 20px`/`16px` vs. the five `h-*` tokens; `font-size: 12px` vs. any `fs-*`), so none collide — `test/token-rules.test.ts`'s strict component check ran for real and passed with zero violations, no substitution needed.

## Deviation: one strict-tsc type error in `Field.tsx`

**What:** `(error || over) && "ohf-field--error"` (brief's literal text, Step 2) fails
`tsc --noEmit`:

```
src/components/Field/Field.tsx(25,37): error TS2345: Argument of type 'false | "" | 0 | 0n | "ohf-field--error"' is not assignable to parameter of type 'string | false | null | undefined'.
  Type '0' is not assignable to type 'string | false | null | undefined'.
```

**Why:** `error` is typed `ReactNode | undefined`, which includes `string | number | bigint | ...`. `error || over` therefore widens to include falsy non-boolean literals (`0`, `0n`, `""`), which `cx()`'s parameter type (`string | false | null | undefined`) rejects.

**Fix (smallest, keeps the brief's intent — show the error style when `error` is truthy or the counter is over):**

```tsx
<div className={cx("ohf-field", (Boolean(error) || over) && "ohf-field--error", className)}>
```

Only that one line changed from the brief's text; the rest of `Field.tsx` is verbatim.

No other deviations. Slider/OptionList needed no fallback — the original `ui.tsx` port matched the brief exactly.

## Tests — RED/GREEN evidence

Step 1 (`corepack pnpm test src/components`), before implementing: RED — all 9 new test files failed with `Failed to resolve import "./<Name>"` (module not found); the 8 pre-existing component test files (Task 6) still passed, confirming isolated failure. Full run: `9 failed | 8 passed (17)`, `20 passed (20)` tests (only the pre-existing tests ran to completion).

Steps 2–5, after implementing all nine components: GREEN.

```
corepack pnpm test
 Test Files  26 passed (26)
      Tests  56 passed | 1 skipped (57)
```

(The 1 skip is `test/token-rules.test.ts`'s slide-file check — `src/slides` doesn't exist until a later task, same as reported in Task 6.)

Step 6 final validation:

```
corepack pnpm typecheck
> tsc --noEmit
(clean, no output — after the Field.tsx fix above; first run failed with the TS2345 shown)
```

```
corepack pnpm build
✓ 53 modules transformed.
dist/ohf.css   63.74 kB │ gzip: 11.74 kB
dist/index.js  25.41 kB │ gzip:  6.22 kB │ map: 55.21 kB
✓ built in 1.14s
dist ok
```

## Files created

- `design/src/components/Field/{Field.tsx,Field.scss,Field.test.tsx,index.ts}`
- `design/src/components/Input/{Input.tsx,Input.scss,Input.test.tsx,index.ts}`
- `design/src/components/Textarea/{Textarea.tsx,Textarea.test.tsx,index.ts}`
- `design/src/components/Stepper/{Stepper.tsx,Stepper.scss,Stepper.test.tsx,index.ts}`
- `design/src/components/Switch/{Switch.tsx,Switch.scss,Switch.test.tsx,index.ts}`
- `design/src/components/Slider/{Slider.tsx,Slider.test.tsx,index.ts}`
- `design/src/components/OptionList/{OptionList.tsx,OptionList.test.tsx,index.ts}`
- `design/src/components/Avatar/{Avatar.tsx,Avatar.scss,Avatar.test.tsx,index.ts}`
- `design/src/components/CreditBadge/{CreditBadge.tsx,CreditBadge.scss,CreditBadge.test.tsx,index.ts}`

## Files changed

- `design/src/index.ts` — added the 9 export lines from Step 6 (merged alphabetically with the existing Task 6 exports).

## Self-review

- **Completeness:** all 6 steps done in order; RED seen before GREEN; final `test && typecheck && build` all pass with `dist ok`.
- **Quality:** no debug leftovers (`grep -rn "console\.\|TODO\|FIXME"` over the 9 new folders returns nothing); component SCSS confirmed against `test/token-rules.test.ts`, which ran for real (not skipped) and passed with zero violations.
- **Discipline:** touched only the files the brief names, plus the one-line `Field.tsx` type fix (reported above, required because the brief's code as literally written does not type-check). No earlier task's files were touched.
- **Reuse verified:** confirmed by grep that `.ohf-field(-row/-label/-value)`, `.ohf-input`, `.ohf-batch(-step/-value/-max)`, `.ohf-slider`, `.ohf-opts`/`.ohf-opt(-label/-check/-ratio/-box)` already have their full base rules in the ported studio partials (`_popovers.scss`, `_dock.scss`), so this task's SCSS for those only adds new modifiers/states (error tint, counter color, hover/active backgrounds) — never redefines studio-drawn geometry. `.ohf-switch`, `.ohf-avatar(-img)`, `.ohf-credit(-icon/-amount/-unit)` are confirmed new (not present anywhere in `src/styles/studio/*.scss`), so their SCSS defines the full component, per plan-header's rule for things not in the studio.
- **Testing:** every test renders, asserts through role/text/class/attribute, and (Field, Stepper, Switch, Slider, OptionList) exercises interaction via `fireEvent`; no test was weakened to pass.
- **Concerns:** none outstanding.

## Fix round 1 (post-review)

**Finding (reviewer, Important):** `Switch.scss:1-35` had no `:hover`/`[data-state="hover"]` or
`:active`/`[data-state="active"]` rules at all — the toggle shipped with zero interactive
feedback. Switch has no studio precedent (it must define everything itself, per plan-header's
rule for controls not in the studio), unlike Button (Task 6), which correctly uses the
`m.hover`/`m.active` mixins. Controller ruling: the brief's Step 3 SCSS has this gap, but the
repo's "every control ships all its states" principle and the binding 상태 고정 convention win,
so fix `Switch.scss` only (a second writer had since finished Tasks 8–9 in the tree; nothing
else was touched).

**Change — `design/src/components/Switch/Switch.scss`:**

- Added `@use "@/styles/mixins" as m;` at the top (same form as `Button.scss`).
- Hover, via `@include m.hover { &:not([aria-checked="true"]) { background: var(--line-2); } }`.
  Token choice: the neutral surface scale in `src/styles/tokens/_maps.scss` tops out at `s4`
  (`bg → rail → s1 → s2 → s3 → s4`, monotonically lighter, no `s5`), and the switch's off-track
  already rests at `var(--s4)`, so there is no lighter surface token left to step to. The `line`
  family is the next token group in the same map (`line` → `line-2`) and is the pairing the
  studio itself already uses whenever a control's hover treatment needs a "one step up" beyond
  what a flat surface fill gives it (`_viewer.scss` `.ohf-btn-solid:hover` and `_composer.scss`
  `.ohf-undo-act:hover` both pair `background: var(--s4)` with `border-color: var(--line-2)` as
  the matched "next step" for a control already moving onto `s4`). No new token was invented —
  `line-2` is used exactly as it already exists. The rule is scoped with
  `:not([aria-checked="true"])` (guard, not just source order) so a checked+hovered switch
  cannot have its `background: var(--accent)` overridden — the two selectors have equal
  specificity, so order alone would not have been safe.
- Active, via `@include m.active { .ohf-switch-knob { scale: 0.92; } }`, so both `:active` and
  `[data-state="active"]` press the knob together, matching the plan's state-pinning
  convention. Added `scale var(--dur-base) var(--ease)` to the knob's `transition` list so the
  press animates instead of snapping.
- Left the existing `&:disabled` rule untouched — the mixins already exclude `:disabled`/
  `[aria-disabled="true"]` from matching `:hover`/`:active`, so no interaction was needed there.
- Did not act on the reviewer's second finding (OptionList/Slider state-pin coverage) — parked
  by controller ruling.

**Tests:**

```
corepack pnpm test
 Test Files  34 passed (34)
      Tests  71 passed (71)
```

(0 skipped now, vs. 1 skipped when this task was first reported — Tasks 8/9 since added
`src/composites` and `src/slides`, so `token-rules.test.ts`'s previously-skipped checks now run
for real too; still zero violations, confirming `var(--line-2)` and the bare `scale: 0.92`
declaration don't trip the literal-token ban.)

```
corepack pnpm typecheck
> tsc --noEmit
(clean, no output)
```

```
corepack pnpm build
✓ 76 modules transformed.
dist/ohf.css   68.75 kB │ gzip: 12.76 kB
dist/index.js  35.88 kB │ gzip:  8.55 kB │ map: 81.38 kB
✓ built in 1.35s
dist ok
```

**Files changed:** `design/src/components/Switch/Switch.scss` only.
