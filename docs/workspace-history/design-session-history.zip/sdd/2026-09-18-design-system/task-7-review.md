# Task 7 Review — 기본 요소 2묶음 (Field, Input, Textarea, Stepper, Switch, Slider, OptionList, Avatar, CreditBadge)

### Spec Compliance

❌ Issues found: the plan-header.md 공통 규약 "상태 고정" global constraint ("모든 인터랙티브 컴포넌트는 :hover와
[data-state="hover"], :active와 [data-state="active"]를 같은 규칙으로 묶는다", plan-header.md:34) is not met for
two of the nine components — see Important #1 (Switch) and #2 (OptionList/Slider) below.

Everything else verified correct against `task-7-brief.md` Steps 1–6, file by file:
- All 9 component folders created exactly where specified (`t7/src/components/{Field,Input,Textarea,Stepper,Switch,Slider,OptionList,Avatar,CreditBadge}/`), with the brief's own scss-exception list honored precisely: Textarea, Slider, OptionList have no `.scss` (diff's "Files changed" list confirms exactly 6 `.scss` files, not 9).
- Every component's props/produced-class contract matches the brief's "Produces" list verbatim (`Field`→`.ohf-field(.ohf-field--error)`, `Input`→`.ohf-input[aria-invalid]`, `Textarea`→`.ohf-input.ohf-input--area`, `Stepper`→`.ohf-batch`, `Switch`→`[role=switch].ohf-switch`, `Slider`→`.ohf-slider`, `OptionList`→`.ohf-opts`, `Avatar`→`.ohf-avatar`, `CreditBadge`→`.ohf-credit`).
- `src/index.ts` (diff lines 782–806) adds exactly the 9 export lines from Step 6, correctly merged alphabetically into the existing Task 6 list.
- Slider/OptionList are a verified line-for-line port of `open-higgsfield/src/openhiggsfield/ui.tsx:115-144` and `:35-113` respectively (only cosmetic differences: named vs. inline prop types, `cx()` used for Slider's extra `className`).
- Token-literal ban: audited every literal numeric/color value in the 6 new `.scss` files against `design/src/styles/tokens/_maps.scss`'s `$radius`/`$height`/`$font-size`/`$letter-spacing` maps — none collide with a banned value (e.g. Avatar's `44px`/`11px`/`10px`/`0.02em`, Field's `11px`, CreditBadge's `12px`, Switch's `20px`/`16px` are all genuinely outside the token sets). No raw colors/shadows anywhere — all go through `var()`.
- Field.tsx's one documented deviation (`Boolean(error) || over` instead of the brief's `error || over`) is a pure type-narrowing fix for `tsc --noEmit`; traced through both branches, it does not change runtime behavior from the brief's literal code (both reduce to the same truthiness the `cx()` call receives).
- Diff touches exactly the 34 files the brief's batch implies (9 components × {tsx,test.tsx,index.ts,+scss where applicable} + `src/index.ts`), nothing else.

### Strengths

- Every file matches the brief's exact specified code, with the single Field.tsx type-fix being the only departure, and it's transparently reported and technically justified.
- Slider/OptionList port fidelity against the read-only original `ui.tsx` verified directly — genuinely line-for-line.
- Zero token-literal or raw-color/shadow violations across all 6 new `.scss` files (independently re-audited against `_maps.scss`, not just trusted from the report).
- Test files are copied verbatim from the brief, assert through role/text/class/attribute as the plan-header's "테스트" convention requires, and none were weakened.
- Discipline: the diff's file list contains nothing outside the brief's batch.

### Issues

#### Critical (Must Fix)

None.

#### Important (Should Fix)

1. **`t7/src/components/Switch/Switch.scss:1-35`** — `.ohf-switch`/`.ohf-switch-knob` have no `:hover`/`[data-state="hover"]` or `:active`/`[data-state="active"]` rule at all (only `[aria-checked="true"]` and `:disabled` are styled). Switch is explicitly in plan-header's "스튜디오에 없는 것" list (plan-header.md:30 — "컴포넌트 SCSS가 전부를 정의한다"), so unlike the studio-reused classes there is no base partial anywhere supplying a real `:hover`/`:active` for it (confirmed: no switch/toggle rule exists anywhere in the original `openhiggsfield.css`). As shipped the toggle gives zero visual feedback on hover or press, and the showcase cannot pin a "hovered"/"pressed" example for it. Compare `t7/src/components/Button/Button.scss:22-23` (same "not in studio" category, Task 6), which correctly wires `@include m.control-states(...)` (→ `m.hover`/`m.active` from `src/styles/_mixins.scss:6-18`). This is plan-mandated — the brief's Step 3 code (task-7-brief.md:477-515) is exactly what shipped, unchanged. Fix: add a hover/active treatment to `.ohf-switch`/`.ohf-switch-knob` via the `m.hover`/`m.active` mixins.

2. **`t7/src/components/OptionList/index.ts`, `t7/src/components/Slider/index.ts`** (no `.scss` files) — the underlying studio classes `.ohf-opt` (`src/styles/studio/_popovers.scss:180`) and `.ohf-slider::-webkit-slider-thumb` (`_popovers.scss:286`) have a real `:hover` rule but no `[data-state="hover"]`/`[data-state="active"]` pin anywhere in the codebase (verified by grep across `src/styles/studio/*.scss` and the new component folders — none exists). Every other studio-reused interactive class touched by Tasks 6–7 gets its data-state pin added in the consuming component's own `.scss` — `.ohf-chip` (`Chip.scss:4,8`), `.ohf-ctl` (`Pill.scss:4,8`), `.ohf-icon-btn` (`IconButton.scss:19,24`), and this same task's `.ohf-batch`/`.ohf-batch-step` (`Stepper.scss:1,4,8`). OptionList/Slider skip it only because plan-header.md:32 and task-7-brief.md (Step 4 preamble) both list them under "no `.scss` needed … 이미 완전히 그려짐" — a premise that holds for the real `:hover` but not for the showcase's `data-state` pinning mechanism, which is what the global constraint at plan-header.md:34 actually asks every interactive component to have. Plan-mandated. Flag for the controller: either this task needs a small addendum adding the two missing selectors, or a later (showcase) task must explicitly account for OptionList/Slider never supporting a pinned-hover/active example.

#### Minor (Nice to Have)

1. **`t7/src/components/Field/Field.tsx`** — hint/counter text isn't wired to the control via `aria-describedby`; only the error path gets a live region (`role="alert"`). A screen-reader user focusing the field won't hear the hint or the character counter. Not required by the brief or global constraints, but worth a follow-up pass across `Field` consumers.
2. `task-7-report.md`'s self-review states "(Field, Stepper, Switch, Slider, OptionList) exercises interaction via fireEvent" — `Field.test.tsx` (diff lines 237–269) never imports or calls `fireEvent`, only `rerender`. A small inaccuracy in the report; no code impact, tests are fine as written.

### Assessment

**Task quality:** Needs fixes

**Reasoning:** All nine components and the public API precisely match the brief's specified interfaces, every literal style value stays clear of the token-literal ban, and the one code deviation (Field.tsx) is minimal, correct, and transparently justified — but the binding "상태 고정" global constraint is unmet for Switch (no interactive feedback at all) and only half-met for OptionList/Slider (real `:hover` works, the showcase's `data-state` pin does not), so the task should not be signed off until those are fixed or the controller explicitly defers them.
